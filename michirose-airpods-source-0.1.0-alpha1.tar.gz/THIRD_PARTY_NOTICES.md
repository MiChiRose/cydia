# Attribution

Based on [DaneBentley/ios6-airpods-fix](https://github.com/DaneBentley/ios6-airpods-fix),
commit `f64733f8f9b7ed1e1839e30153735d63840b35f6`.
Copyright (c) 2026 Dane Bentley, MIT license, reproduced in LICENSE.
MiChiRose changes: build compatibility, verified-build gating, Substrate path
fallback, narrower battery-command handling and packaging. Those changes are MIT.
This is an independent adaptation, not an official upstream release.
