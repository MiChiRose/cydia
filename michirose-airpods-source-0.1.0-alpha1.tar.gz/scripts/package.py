#!/usr/bin/env python3
import gzip,hashlib,io,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'dist';OUT.mkdir(exist_ok=True)
control=(ROOT/'packaging/control').read_text()
version=next(l.split(': ',1)[1] for l in control.splitlines() if l.startswith('Version: '))
def archive(files):
    output=io.BytesIO()
    with tarfile.open(fileobj=output,mode='w',format=tarfile.USTAR_FORMAT) as tf:
        directories={Path('.')}
        for name,_,_ in files:directories.update(Path(name).parents)
        for name in sorted(directories,key=lambda p:(len(p.parts),str(p))):
            t=tarfile.TarInfo('./' if name==Path('.') else './'+str(name)+'/');t.type=tarfile.DIRTYPE;t.mode=0o755;t.uname=t.gname='root';tf.addfile(t)
        for name,data,mode in sorted(files):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            t=tarfile.TarInfo('./'+name);t.size=len(data);t.mode=mode;t.uname=t.gname='root';tf.addfile(t,io.BytesIO(data))
    return gzip.compress(output.getvalue(),mtime=0)
source=archive([(str(p.relative_to(ROOT)),p.read_bytes(),0o755 if p.suffix=='.sh' else 0o644) for p in ROOT.rglob('*') if p.is_file() and not any(part in ('.git','build','dist','__pycache__') for part in p.relative_to(ROOT).parts)])
(OUT/f'michirose-airpods-source-{version.replace("~","-")}.tar.gz').write_bytes(source)
data=[]
for binary,name in [('A2DPClock','MiChiRoseAirPodsClock'),('ATLineEnd','MiChiRoseAirPodsAT')]:
    data.append((f'Library/MobileSubstrate/DynamicLibraries/{name}.dylib',(ROOT/'build'/f'{binary}.dylib').read_bytes(),0o755))
    data.append((f'Library/MobileSubstrate/DynamicLibraries/{name}.plist',(ROOT/'packaging'/f'{name}.plist').read_bytes(),0o644))
for name in ['README.md','LICENSE','THIRD_PARTY_NOTICES.md']:
    data.append((f'usr/share/doc/com.michirose.airpodsfix/{name}',(ROOT/name).read_bytes(),0o644))
data.append(('usr/share/doc/com.michirose.airpodsfix/source.tar.gz',source,0o644))
assert not any('.app/' in name or name.startswith('Applications/') for name,_,_ in data)
control+=f'Installed-Size: {(sum(len(d) for _,d,_ in data)+1023)//1024}\n'
metadata=[('control',control.encode(),0o644),('preinst',(ROOT/'packaging/preinst').read_bytes(),0o755),('md5sums',''.join(hashlib.md5(d).hexdigest()+'  '+n+'\n' for n,d,_ in data).encode(),0o644)]
deb=bytearray(b'!<arch>\n')
for name,payload in [('debian-binary',b'2.0\n'),('control.tar.gz',archive(metadata)),('data.tar.gz',archive(data))]:
    header=f'{name+"/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(payload):<10}`\n'.encode();assert len(header)==60
    deb+=header+payload+(b'\n' if len(payload)%2 else b'')
path=OUT/f'michirose-airpods_{version}_iphoneos-arm.deb';path.write_bytes(deb)
with tarfile.open(fileobj=io.BytesIO(archive(data))) as tf:
    seen={Path('.')}
    for member in tf:
        p=Path(member.name);assert all(parent in seen for parent in p.parents)
        if member.isdir():seen.add(p)
print(f'Built {path.name}: {len(deb)} bytes; no application; full MIT source included.')
