# Sources and attribution

MiChiRose Weather is an independent compatibility implementation by MiChiRose.

- Yahoo XML response field layout was researched from
  [TestOrig/YQL-X-Server-New](https://github.com/TestOrig/YQL-X-Server-New),
  revision `f236e98a3f4a4d4f855933ca5ad4decae78eeb83`, by Electimon and
  ObscureMosquito. The project is GPL-3.0; this project is also GPL-3.0-only.
- The original-host interception approach was researched from
  [Notdbrand/NDBWeather](https://github.com/Notdbrand/NDBWeather). No NDBWeather
  source code or binary is included.
- Weather data: [Open-Meteo](https://open-meteo.com/),
  [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
  The adapter rounds temperatures, translates WMO condition codes into Yahoo
  condition codes, and converts responses to XML; these changes are ours.
- City names and locations: [GeoNames](https://www.geonames.org/) through
  [Open-Meteo Geocoding](https://open-meteo.com/en/docs/geocoding-api),
  [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

The free Open-Meteo service is for noncommercial use and subject to its
[usage limits](https://open-meteo.com/en/terms). No API key is bundled.
This alpha is intended for personal testing, not a commercial weather service.

The Apple SDK and ldid are build tools and are not redistributed here. Tested
with Theos SDK revision `0222fd5413cf4b9af096f37b4621afa2688572f7`
(`iPhoneOS9.3.sdk`) and Procursus ldid `v2.1.5-procursus7`.
