// SPDX-License-Identifier: GPL-3.0-only
#import <Foundation/Foundation.h>
NSString *MWRunWeatherDiagnostics(NSString *city);
NSString *MWWeatherRuntimeSummary(void);
NSString *MWErrorSummary(NSError *error);
