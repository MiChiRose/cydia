// SPDX-License-Identifier: GPL-3.0-only
#import <Foundation/Foundation.h>
@interface MWWeatherProtocol : NSURLProtocol {
    BOOL _stopped;
    NSOperation *_operation;
}
@end
