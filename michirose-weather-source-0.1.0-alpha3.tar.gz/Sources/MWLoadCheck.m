// SPDX-License-Identifier: GPL-3.0-only
// Isolate dlopen from the UI process so duplicate ObjC classes cannot interfere.
#import <Foundation/Foundation.h>
#include <dlfcn.h>
int main(void) {
    @autoreleasepool {
        const char *path = "/Library/MobileSubstrate/DynamicLibraries/MiChiRoseWeather.dylib";
        void *handle = dlopen(path, RTLD_NOW | RTLD_LOCAL);
        if (!handle) { fprintf(stdout, "LOAD FAIL: %s\n", dlerror()); return 1; }
        fprintf(stdout, "LOAD OK: library linked successfully in a separate process.\n");
        // This is a loader check, not proof that Substrate injected Weather.
        return 0;
    }
}
