// SPDX-License-Identifier: GPL-3.0-only
// Yahoo XML field layout informed by TestOrig/YQL-X-Server-New (GPL-3.0).
#import "MWWeatherEngine.h"
#import <math.h>

static const long long MWIDOffset = 1000000000LL;

static void MWError(NSError **error, NSInteger code, NSString *message) {
    if (error) *error = [NSError errorWithDomain:@"com.michirose.weather" code:code
        userInfo:[NSDictionary dictionaryWithObject:message forKey:NSLocalizedDescriptionKey]];
}

static NSString *MWCapture(NSString *text, NSString *pattern) {
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern
        options:NSRegularExpressionCaseInsensitive error:NULL];
    NSTextCheckingResult *result = [regex firstMatchInString:text options:0
        range:NSMakeRange(0, [text length])];
    return result && [result numberOfRanges] > 1 ? [text substringWithRange:[result rangeAtIndex:1]] : nil;
}

static NSString *MWDecode(NSString *value) {
    return [[value stringByReplacingOccurrencesOfString:@"+" withString:@" "]
        stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
}

static NSString *MWQueryValue(NSURL *url, NSString *key) {
    for (NSString *part in [[url query] componentsSeparatedByString:@"&"]) {
        NSRange separator = [part rangeOfString:@"="];
        if (separator.location == NSNotFound) continue;
        if ([MWDecode([part substringToIndex:separator.location]) isEqualToString:key])
            return MWDecode([part substringFromIndex:separator.location + 1]);
    }
    return nil;
}

NSString *MWEncodeQuery(NSDictionary *parameters) {
    NSMutableArray *parts = [NSMutableArray array];
    for (NSString *key in [[parameters allKeys] sortedArrayUsingSelector:@selector(compare:)]) {
        NSString *value = [[parameters objectForKey:key] description];
        NSString *escaped = [(NSString *)CFURLCreateStringByAddingPercentEscapes(NULL,
            (CFStringRef)value, NULL, CFSTR("!*'();:@&=+$,/?%#[]\" "), kCFStringEncodingUTF8) autorelease];
        [parts addObject:[NSString stringWithFormat:@"%@=%@", key, escaped]];
    }
    return [parts componentsJoinedByString:@"&"];
}

BOOL MWIsWeatherRequest(NSURLRequest *request) {
    NSURL *url = [request URL];
    NSString *host = [[url host] lowercaseString];
    if (![[request HTTPMethod] isEqualToString:@"GET"]) return NO;
    if (![host isEqualToString:@"apple-mobile.query.yahooapis.com"] &&
        ![host isEqualToString:@"query.yahooapis.com"]) return NO;
    if (![[url path] isEqualToString:@"/v1/yql"] && ![[url path] isEqualToString:@"/yql/weather"]) return NO;
    NSString *query = MWQueryValue(url, @"q");
    return query && [query rangeOfString:@"partner.weather." options:NSCaseInsensitiveSearch].location != NSNotFound;
}

NSDictionary *MWParseQuery(NSURL *url, NSError **error) {
    NSString *q = MWQueryValue(url, @"q");
    if (![q length] || [q length] > 8192) {
        MWError(error, 1, @"Missing or oversized Yahoo weather query."); return nil;
    }
    NSString *language = MWCapture(q, @"lang\\s*=\\s*['\"]([^'\"]+)['\"]") ?: @"en-US";
    language = [[[language componentsSeparatedByCharactersInSet:
        [NSCharacterSet characterSetWithCharactersInString:@"-_"]] objectAtIndex:0] lowercaseString];
    if ([language length] != 2) language = @"en";
    NSMutableDictionary *result = [NSMutableDictionary dictionaryWithObject:language forKey:@"language"];
    if ([q rangeOfString:@"partner.weather.locations" options:NSCaseInsensitiveSearch].location != NSNotFound &&
        [q rangeOfString:@"yql.query.multi" options:NSCaseInsensitiveSearch].location == NSNotFound) {
        NSString *term = MWCapture(q, @"query\\s*=\\s*['\"]([^'\"]{1,120})['\"]");
        if (![term length]) { MWError(error, 1, @"Missing city search text."); return nil; }
        [result setObject:@"search" forKey:@"action"];
        [result setObject:term forKey:@"term"];
        return result;
    }
    NSString *lat = MWCapture(q, @"\\blat\\s*=\\s*([-+]?[0-9]+(?:\\.[0-9]+)?)");
    NSString *lon = MWCapture(q, @"\\blon\\s*=\\s*([-+]?[0-9]+(?:\\.[0-9]+)?)");
    [result setObject:@"forecast" forKey:@"action"];
    if (lat || lon) {
        if (!lat || !lon || fabs([lat doubleValue]) > 90 || fabs([lon doubleValue]) > 180) {
            MWError(error, 1, @"Invalid weather coordinates."); return nil;
        }
        [result setObject:lat forKey:@"latitude"];
        [result setObject:lon forKey:@"longitude"];
        return result;
    }
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:
        @"\\bwoeid\\s*=\\s*['\"]?([0-9]{1,10})\\b" options:NSRegularExpressionCaseInsensitive error:NULL];
    NSMutableArray *ids = [NSMutableArray array];
    for (NSTextCheckingResult *match in [regex matchesInString:q options:0 range:NSMakeRange(0, [q length])]) {
        NSString *identifier = [q substringWithRange:[match rangeAtIndex:1]];
        if (![ids containsObject:identifier]) [ids addObject:identifier];
    }
    if (![ids count] || [ids count] > 8) {
        MWError(error, 1, @"Unsupported weather query; expected at most eight city IDs."); return nil;
    }
    [result setObject:ids forKey:@"ids"];
    return result;
}

NSInteger MWYahooCode(NSInteger wmo, BOOL day) {
    switch (wmo) {
        case 0: return day ? 32 : 31;
        case 1: return day ? 34 : 33;
        case 2: return day ? 30 : 29;
        case 3: return 26;
        case 45: case 48: return 20;
        case 51: case 53: case 55: return 9;
        case 56: case 57: return 8;
        case 61: case 80: case 81: case 82: return 11;
        case 63: case 65: return 12;
        case 66: case 67: return 10;
        case 71: case 85: return 14;
        case 73: case 75: case 86: return 16;
        case 77: return 13;
        case 95: return 4;
        case 96: case 99: return 17;
        default: return 3200;
    }
}

static NSString *MWXML(id value) {
    NSString *s = value && value != [NSNull null] ? [value description] : @"";
    s = [s stringByReplacingOccurrencesOfString:@"&" withString:@"&amp;"];
    s = [s stringByReplacingOccurrencesOfString:@"<" withString:@"&lt;"];
    s = [s stringByReplacingOccurrencesOfString:@">" withString:@"&gt;"];
    s = [s stringByReplacingOccurrencesOfString:@"\"" withString:@"&quot;"];
    return [s stringByReplacingOccurrencesOfString:@"'" withString:@"&apos;"];
}

static NSString *MWAttrs(NSDictionary *attributes) {
    NSMutableString *result = [NSMutableString string];
    for (NSString *key in [[attributes allKeys] sortedArrayUsingSelector:@selector(compare:)])
        [result appendFormat:@" %@=\"%@\"", key, MWXML([attributes objectForKey:key])];
    return result;
}

static id MWValue(NSDictionary *dict, NSString *key, NSUInteger index) {
    id array = [dict objectForKey:key];
    if (![array isKindOfClass:[NSArray class]] || index >= [array count]) return nil;
    id value = [array objectAtIndex:index];
    return value == [NSNull null] ? nil : value;
}

static NSString *MWNumber(id value) {
    if (![value respondsToSelector:@selector(doubleValue)] || value == [NSNull null]) return nil;
    double n = [value doubleValue];
    if (!isfinite(n)) return nil;
    return [NSString stringWithFormat:@"%.0f", round(n)];
}

static void MWSetNumber(NSMutableDictionary *out, NSString *key, id value) {
    NSString *number = MWNumber(value);
    if (number) [out setObject:number forKey:key];
}

static NSDate *MWDate(NSString *text) {
    if (![text isKindOfClass:[NSString class]]) return nil;
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease]];
    [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    [formatter setDateFormat:[text length] == 10 ? @"yyyy-MM-dd" : @"yyyy-MM-dd'T'HH:mm"];
    return [formatter dateFromString:text];
}

static NSString *MWTime(NSString *text, BOOL twelve) {
    NSDate *date = MWDate(text);
    if (!date) return @"";
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease]];
    [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    [formatter setDateFormat:twelve ? @"h:mm a" : @"HH:mm"];
    return [formatter stringFromDate:date];
}

static NSString *MWRoot(NSUInteger count, NSString *language) {
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    [formatter setLocale:[[[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"] autorelease]];
    [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    [formatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss'Z'"];
    return [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
        "<query xmlns:yahoo=\"http://www.yahooapis.com/v1/base.rng\" yahoo:count=\"%lu\" yahoo:created=\"%@\" yahoo:lang=\"%@\">",
        (unsigned long)count, [formatter stringFromDate:[NSDate date]], MWXML(language)];
}

@implementation MWWeatherEngine
- (id)initWithFetcher:(MWJSONFetcher)fetcher {
    if ((self = [super init])) { _fetcher = [fetcher copy]; _cache = [[NSCache alloc] init]; [_cache setCountLimit:128]; }
    return self;
}
- (void)dealloc { [_fetcher release]; [_cache release]; [super dealloc]; }

+ (MWWeatherEngine *)sharedEngine {
    static MWWeatherEngine *engine = nil;
    @synchronized(self) {
        if (!engine) engine = [[self alloc] initWithFetcher:^NSDictionary *(NSString *host, NSString *path, NSDictionary *params, NSError **error) {
            // Only these fixed providers are reachable; Yahoo input never becomes a destination URL.
            if (![host isEqualToString:@"api.open-meteo.com"] && ![host isEqualToString:@"geocoding-api.open-meteo.com"]) {
                MWError(error, 2, @"Unexpected weather provider."); return nil;
            }
            NSString *url = [NSString stringWithFormat:@"https://%@%@?%@", host, path, MWEncodeQuery(params)];
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]
                cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:15];
            [request setValue:@"MiChiRoseWeather/0.1 (iOS 6 compatibility)" forHTTPHeaderField:@"User-Agent"];
            NSURLResponse *response = nil;
            NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:error];
            if (!data) return nil;
            if (![response isKindOfClass:[NSHTTPURLResponse class]] || [(NSHTTPURLResponse *)response statusCode] != 200 || [data length] > 2 * 1024 * 1024) {
                MWError(error, 2, @"Weather provider returned an HTTP error or oversized response."); return nil;
            }
            id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:error];
            if (![json isKindOfClass:[NSDictionary class]] || [[json objectForKey:@"error"] boolValue]) {
                MWError(error, 2, @"Weather provider returned invalid data."); return nil;
            }
            return json;
        }];
    }
    return engine;
}

- (NSDictionary *)fetch:(NSString *)host path:(NSString *)path parameters:(NSDictionary *)params ttl:(NSTimeInterval)ttl error:(NSError **)error {
    NSString *key = [NSString stringWithFormat:@"%@%@?%@", host, path, MWEncodeQuery(params)];
    NSDictionary *entry = [_cache objectForKey:key];
    if (entry && -[[entry objectForKey:@"time"] timeIntervalSinceNow] < ttl) return [entry objectForKey:@"data"];
    NSDictionary *data = _fetcher(host, path, params, error);
    if (data) [_cache setObject:[NSDictionary dictionaryWithObjectsAndKeys:data, @"data", [NSDate date], @"time", nil] forKey:key];
    return data;
}

- (NSData *)search:(NSDictionary *)query error:(NSError **)error {
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:[query objectForKey:@"term"], @"name",
        [query objectForKey:@"language"], @"language", @10, @"count", nil];
    NSDictionary *data = [self fetch:@"geocoding-api.open-meteo.com" path:@"/v1/search" parameters:params ttl:600 error:error];
    if (!data) return nil;
    id results = [data objectForKey:@"results"] ?: [NSArray array];
    if (![results isKindOfClass:[NSArray class]]) { MWError(error, 3, @"Invalid city search results."); return nil; }
    NSMutableArray *locations = [NSMutableArray array];
    for (id place in results) {
        if (![place isKindOfClass:[NSDictionary class]] || ![[place objectForKey:@"id"] respondsToSelector:@selector(longLongValue)] || ![[place objectForKey:@"name"] isKindOfClass:[NSString class]]) continue;
        long long geoID = [[place objectForKey:@"id"] longLongValue];
        if (geoID <= 0 || geoID >= 1000000000LL) continue;
        NSString *identifier = [NSString stringWithFormat:@"%lld", MWIDOffset + geoID];
        NSDictionary *attrs = [NSDictionary dictionaryWithObjectsAndKeys:[place objectForKey:@"name"], @"city",
            [place objectForKey:@"country"] ?: @"", @"country", [place objectForKey:@"country_code"] ?: @"", @"countryAbbr",
            identifier, @"woeid", [@"MW" stringByAppendingString:identifier], @"locationID", nil];
        [locations addObject:[NSString stringWithFormat:@"<location%@/>", MWAttrs(attrs)]];
    }
    NSString *xml = [NSString stringWithFormat:@"%@<results>%@</results></query>",
        MWRoot([locations count], [query objectForKey:@"language"]), [locations componentsJoinedByString:@""]];
    return [xml dataUsingEncoding:NSUTF8StringEncoding];
}

- (NSDictionary *)placeForID:(NSString *)identifier language:(NSString *)language error:(NSError **)error {
    long long geoID = [identifier longLongValue] - MWIDOffset;
    if (geoID <= 0 || geoID >= 1000000000LL) {
        MWError(error, 4, @"This city uses an old Yahoo ID. Remove that city in Weather and add it again."); return nil;
    }
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
        [NSNumber numberWithLongLong:geoID], @"id", language, @"language", nil];
    NSDictionary *place = [self fetch:@"geocoding-api.open-meteo.com" path:@"/v1/get" parameters:params ttl:86400 error:error];
    // /v1/get returns a single object, unlike /v1/search.
    if (place && (![place objectForKey:@"latitude"] || ![place objectForKey:@"longitude"] || ![place objectForKey:@"name"])) {
        MWError(error, 3, @"City lookup has no coordinates."); return nil;
    }
    return place;
}

- (NSString *)forecastForPlace:(NSDictionary *)place identifier:(NSString *)identifier error:(NSError **)error {
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
        [place objectForKey:@"latitude"], @"latitude", [place objectForKey:@"longitude"], @"longitude",
        @"temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,pressure_msl,wind_speed_10m,wind_direction_10m", @"current",
        @"temperature_2m,weather_code,precipitation_probability,is_day,visibility,dew_point_2m", @"hourly",
        @"weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max", @"daily",
        @"auto", @"timezone", @"celsius", @"temperature_unit", @"kmh", @"wind_speed_unit", @7, @"forecast_days", nil];
    NSDictionary *data = [self fetch:@"api.open-meteo.com" path:@"/v1/forecast" parameters:params ttl:600 error:error];
    if (!data) return nil;
    NSDictionary *current = [data objectForKey:@"current"], *daily = [data objectForKey:@"daily"], *hourly = [data objectForKey:@"hourly"];
    if (![current isKindOfClass:[NSDictionary class]] || ![daily isKindOfClass:[NSDictionary class]] || ![hourly isKindOfClass:[NSDictionary class]] ||
        !MWNumber([current objectForKey:@"temperature_2m"]) || !MWNumber([current objectForKey:@"weather_code"]) || !MWDate([current objectForKey:@"time"])) {
        MWError(error, 3, @"Forecast is missing required current conditions."); return nil;
    }
    NSString *now = [current objectForKey:@"time"];
    NSMutableDictionary *attrs = [NSMutableDictionary dictionaryWithObjectsAndKeys:
        [place objectForKey:@"name"] ?: @"Current location", @"city", [place objectForKey:@"country_code"] ?: @"", @"country",
        [place objectForKey:@"latitude"], @"latitude", [place objectForKey:@"longitude"], @"longitude",
        [place objectForKey:@"admin1"] ?: @"", @"state", identifier, @"woeid", [@"MW" stringByAppendingString:identifier], @"locationID", nil];
    NSMutableString *xml = [NSMutableString stringWithFormat:@"<results><location%@>", MWAttrs(attrs)];
    NSMutableDictionary *conditions = [NSMutableDictionary dictionaryWithObjectsAndKeys:
        MWTime(now, NO), @"time24", MWTime(now, YES), @"time", nil];
    NSInteger offset = [[data objectForKey:@"utc_offset_seconds"] integerValue];
    NSString *zone = [NSString stringWithFormat:@"GMT%@%ld:%02ld", offset < 0 ? @"-" : @"+", (long)labs(offset) / 3600, (long)(labs(offset) % 3600) / 60];
    [conditions setObject:zone forKey:@"timezone"];
    MWSetNumber(conditions, @"temp", [current objectForKey:@"temperature_2m"]);
    MWSetNumber(conditions, @"feelsLike", [current objectForKey:@"apparent_temperature"]);
    MWSetNumber(conditions, @"windChill", [current objectForKey:@"apparent_temperature"]);
    MWSetNumber(conditions, @"percentHumidity", [current objectForKey:@"relative_humidity_2m"]);
    MWSetNumber(conditions, @"barometer", [current objectForKey:@"pressure_msl"]);
    MWSetNumber(conditions, @"windSpeed", [current objectForKey:@"wind_speed_10m"]);
    MWSetNumber(conditions, @"windDirection", [current objectForKey:@"wind_direction_10m"]);
    MWSetNumber(conditions, @"windDirectionDegree", [current objectForKey:@"wind_direction_10m"]);
    NSString *sunrise = MWValue(daily, @"sunrise", 0), *sunset = MWValue(daily, @"sunset", 0);
    if (MWDate(sunrise)) { [conditions setObject:MWTime(sunrise, NO) forKey:@"sunrise24"]; [conditions setObject:MWTime(sunrise, YES) forKey:@"sunrise"]; }
    if (MWDate(sunset)) { [conditions setObject:MWTime(sunset, NO) forKey:@"sunset24"]; [conditions setObject:MWTime(sunset, YES) forKey:@"sunset"]; }
    NSArray *times = [hourly objectForKey:@"time"];
    if (![times isKindOfClass:[NSArray class]]) { MWError(error, 3, @"Missing hourly forecast."); return nil; }
    NSUInteger closest = NSNotFound;
    for (NSUInteger i = 0; i < [times count]; i++) {
        NSString *time = [times objectAtIndex:i];
        if (![time isKindOfClass:[NSString class]]) continue;
        if ([time compare:now] != NSOrderedDescending) closest = i;
    }
    if (closest != NSNotFound) {
        MWSetNumber(conditions, @"dewpoint", MWValue(hourly, @"dew_point_2m", closest));
        id visibility = MWValue(hourly, @"visibility", closest);
        if (MWNumber(visibility)) [conditions setObject:[NSString stringWithFormat:@"%.1f", [visibility doubleValue] / 1000.0] forKey:@"visibility"];
    }
    [xml appendFormat:@"<currently%@><condition code=\"%ld\"/></currently><forecast>", MWAttrs(conditions),
        (long)MWYahooCode([[current objectForKey:@"weather_code"] integerValue], [[current objectForKey:@"is_day"] boolValue])];
    NSUInteger days = 0;
    NSCalendar *calendar = [[[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar] autorelease];
    [calendar setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:0]];
    for (NSUInteger i = 1; i < 7; i++) {
        NSDate *date = MWDate(MWValue(daily, @"time", i));
        NSString *high = MWNumber(MWValue(daily, @"temperature_2m_max", i));
        NSString *low = MWNumber(MWValue(daily, @"temperature_2m_min", i));
        id code = MWValue(daily, @"weather_code", i);
        if (!date || !high || !low || !MWNumber(code)) continue;
        NSInteger weekday = ([[calendar components:NSWeekdayCalendarUnit fromDate:date] weekday] + 5) % 7 + 1;
        NSMutableDictionary *day = [NSMutableDictionary dictionaryWithObject:[NSNumber numberWithInteger:weekday] forKey:@"dayOfWeek"];
        MWSetNumber(day, @"poP", MWValue(daily, @"precipitation_probability_max", i));
        [xml appendFormat:@"<day%@><temp high=\"%@\" low=\"%@\"/><condition code=\"%ld\"/></day>",
            MWAttrs(day), high, low, (long)MWYahooCode([code integerValue], YES)];
        days++;
    }
    [xml appendString:@"<extended_forecast_url>https://open-meteo.com/</extended_forecast_url></forecast></location></results>"];
    [xml appendFormat:@"<results><location woeid=\"%@\"><hourlyforecast>", MWXML(identifier)];
    NSUInteger hours = 0;
    for (NSUInteger i = 0; i < [times count] && hours < 12; i++) {
        NSString *time = [times objectAtIndex:i];
        if (!MWDate(time) || [time compare:now] != NSOrderedDescending) continue;
        NSString *temp = MWNumber(MWValue(hourly, @"temperature_2m", i));
        id code = MWValue(hourly, @"weather_code", i);
        if (!temp || !MWNumber(code)) continue;
        NSMutableDictionary *hour = [NSMutableDictionary dictionaryWithObjectsAndKeys:temp, @"temp",
            [NSNumber numberWithInteger:MWYahooCode([code integerValue], [MWValue(hourly, @"is_day", i) boolValue])], @"code", nil];
        MWSetNumber(hour, @"poP", MWValue(hourly, @"precipitation_probability", i));
        [xml appendFormat:@"<hour time24=\"%@\"><condition%@/></hour>", MWTime(time, NO), MWAttrs(hour)];
        hours++;
    }
    [xml appendString:@"</hourlyforecast></location></results>"];
    if (!days || !hours) { MWError(error, 3, @"Forecast has no usable daily or hourly data."); return nil; }
    return xml;
}

- (NSData *)responseForRequest:(NSURLRequest *)request error:(NSError **)error {
    NSDictionary *query = MWParseQuery([request URL], error);
    if (!query) return nil;
    if ([[query objectForKey:@"action"] isEqualToString:@"search"]) return [self search:query error:error];
    NSMutableArray *results = [NSMutableArray array];
    if ([query objectForKey:@"latitude"]) {
        NSDictionary *place = [NSDictionary dictionaryWithObjectsAndKeys:[query objectForKey:@"latitude"], @"latitude",
            [query objectForKey:@"longitude"], @"longitude", @"Current location", @"name", nil];
        NSString *xml = [self forecastForPlace:place identifier:@"0" error:error];
        if (!xml) return nil;
        [results addObject:xml];
    } else {
        NSError *oldCityError = nil;
        for (NSString *identifier in [query objectForKey:@"ids"]) {
            NSError *lookupError = nil;
            NSDictionary *place = [self placeForID:identifier language:[query objectForKey:@"language"] error:&lookupError];
            if (!place) {
                if ([[lookupError domain] isEqualToString:@"com.michirose.weather"] && [lookupError code] == 4) {
                    oldCityError = lookupError;
                    continue; // An old saved city must not prevent a newly added city from updating.
                }
                if (error) *error = lookupError;
                return nil;
            }
            NSString *xml = [self forecastForPlace:place identifier:identifier error:error];
            if (!xml) return nil;
            [results addObject:xml];
        }
        if (![results count]) { if (error) *error = oldCityError; return nil; }
    }
    NSMutableString *xml = [NSMutableString stringWithString:MWRoot([results count] * 2, [query objectForKey:@"language"])];
    [xml appendString:@"<meta><meta><weather><yahoo_mobile_url>https://open-meteo.com/</yahoo_mobile_url><twc_mobile_url>https://open-meteo.com/</twc_mobile_url><units distanceUnits=\"km\" pressureUnits=\"mb\" speedUnits=\"km/h\" tempUnits=\"C\"/></weather></meta><meta><weather><units tempUnits=\"C\"/></weather></meta></meta><results>"];
    [xml appendString:[results componentsJoinedByString:@""]];
    [xml appendString:@"</results></query>"];
    return [xml dataUsingEncoding:NSUTF8StringEncoding];
}
@end
