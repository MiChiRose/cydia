// SPDX-License-Identifier: GPL-3.0-only
#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "MWDiagnostics.h"
#include <math.h>

@interface MWCheckController : UIViewController <CLLocationManagerDelegate, UITextFieldDelegate> {
    UILabel *_titleLabel, *_subtitleLabel;
    UITextField *_city;
    UIButton *_weatherButton, *_locationButton;
    UITextView *_report;
    CLLocationManager *_manager;
    NSTimer *_locationTimer;
    BOOL _locationRunning;
}
- (void)stopLocation;
@end

@implementation MWCheckController
- (void)dealloc {
    [self stopLocation];
    [_manager setDelegate:nil]; [_manager release];
    [_titleLabel release]; [_subtitleLabel release]; [_city release];
    [_weatherButton release]; [_locationButton release]; [_report release];
    [super dealloc];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithWhite:0.94 alpha:1];
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _titleLabel.text = @"MiChiRose Weather";
    _titleLabel.font = [UIFont boldSystemFontOfSize:22];
    _titleLabel.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_titleLabel];
    _subtitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _subtitleLabel.text = @"Alpha 3 · погода и геопозиция отдельно";
    _subtitleLabel.font = [UIFont systemFontOfSize:12];
    _subtitleLabel.numberOfLines = 2;
    _subtitleLabel.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_subtitleLabel];
    _city = [[UITextField alloc] initWithFrame:CGRectZero];
    _city.borderStyle = UITextBorderStyleRoundedRect;
    _city.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    _city.text = @"Minsk"; _city.placeholder = @"Город для проверки";
    _city.autocorrectionType = UITextAutocorrectionTypeNo;
    _city.returnKeyType = UIReturnKeyDone; _city.delegate = self;
    [self.view addSubview:_city];
    _weatherButton = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
    [_weatherButton setTitle:@"Проверить погоду" forState:UIControlStateNormal];
    [_weatherButton addTarget:self action:@selector(checkWeather) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_weatherButton];
    _locationButton = [[UIButton buttonWithType:UIButtonTypeRoundedRect] retain];
    [_locationButton setTitle:@"Проверить геопозицию" forState:UIControlStateNormal];
    [_locationButton addTarget:self action:@selector(checkLocation) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_locationButton];
    _report = [[UITextView alloc] initWithFrame:CGRectZero];
    _report.editable = NO; _report.font = [UIFont fontWithName:@"Courier" size:12];
    _report.text = @"Сначала откройте штатную «Погоду» и выполните поиск города. Затем вернитесь сюда и нажмите «Проверить погоду».\n\nГеопозиция проверяется только отдельной кнопкой. Координаты телефона в отчёт не записываются.\n\nИсточники погоды: Open-Meteo и GeoNames, CC BY 4.0. Проверка использует город, введённый выше.";
    [self.view addSubview:_report];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat w = self.view.bounds.size.width, h = self.view.bounds.size.height;
    _titleLabel.frame = CGRectMake(12, 8, w-24, 30);
    _subtitleLabel.frame = CGRectMake(12, 40, w-24, 30);
    _city.frame = CGRectMake(12, 76, w-24, 32);
    _weatherButton.frame = CGRectMake(12, 118, w-24, 36);
    _locationButton.frame = CGRectMake(12, 162, w-24, 36);
    _report.frame = CGRectMake(8, 208, w-16, MAX(80, h-216));
}
- (BOOL)textFieldShouldReturn:(UITextField *)field { [field resignFirstResponder]; return YES; }
- (void)setBusy:(BOOL)busy {
    _weatherButton.enabled = !busy; _locationButton.enabled = !busy; _city.enabled = !busy;
}
- (void)checkWeather {
    [_city resignFirstResponder]; [self setBusy:YES];
    _report.text = @"Проверка библиотеки, HTTPS и погодного протокола…\nМожет занять около минуты.";
    NSString *city = [[_city.text copy] autorelease];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        @autoreleasepool {
            NSString *result = nil;
            @try { result = MWRunWeatherDiagnostics(city); }
            @catch (NSException *error) { result = [NSString stringWithFormat:@"Диагностика остановлена: %@.\nПришлите этот экран.", [error name]]; }
            dispatch_async(dispatch_get_main_queue(), ^{ _report.text = result; [self setBusy:NO]; });
        }
    });
}
- (void)stopLocation {
    BOOL wasRunning = _locationRunning;
    [_locationTimer invalidate]; [_locationTimer release]; _locationTimer = nil;
    [_manager stopUpdatingLocation]; _locationRunning = NO;
    if (wasRunning) [self setBusy:NO];
}
- (void)checkLocation {
    [_city resignFirstResponder];
    if (![CLLocationManager locationServicesEnabled]) {
        _report.text = @"Службы геолокации выключены в настройках телефона. Эта проверка не меняет настройки.";
        return;
    }
    CLAuthorizationStatus status = [CLLocationManager authorizationStatus];
    if (status == kCLAuthorizationStatusDenied || status == kCLAuthorizationStatusRestricted) {
        _report.text = @"Доступ к геопозиции запрещён или ограничен. Разрешите доступ для Weather Check в настройках геолокации и повторите тест.";
        return;
    }
    [self stopLocation]; [self setBusy:YES];
    if (!_manager) { _manager = [[CLLocationManager alloc] init]; _manager.delegate = self; }
    _manager.desiredAccuracy = kCLLocationAccuracyHundredMeters;
    _manager.distanceFilter = kCLDistanceFilterNone;
    _locationRunning = YES;
    _report.text = @"Ожидание свежей геопозиции — до 45 секунд. Разрешите запрос системы, если он появится.\n\nПроверяются разрешение и получение координат через Core Location. Наличие спутникового GPS отдельно этим не доказывается.\n\nПриложение не отображает и не сохраняет координаты, не передаёт их погодному сервису.";
    _locationTimer = [[NSTimer scheduledTimerWithTimeInterval:45 target:self selector:@selector(locationTimedOut) userInfo:nil repeats:NO] retain];
    [_manager startUpdatingLocation];
}
- (void)locationTimedOut {
    [self stopLocation]; [self setBusy:NO];
    _report.text = @"За 45 секунд свежая геопозиция не получена. Это может быть сбой служб позиционирования или отсутствие подходящего сигнала; само по себе это не доказывает поломку GPS.\n\nСравните с результатом отдельной проверки погоды: поиск города должен работать без геопозиции.";
}
- (void)acceptLocation:(CLLocation *)location {
    if (!_locationRunning || !location || location.horizontalAccuracy < 0 || fabs([location.timestamp timeIntervalSinceNow]) > 120) return;
    NSString *result = [NSString stringWithFormat:@"ГЕОПОЗИЦИЯ: OK\nПолучена свежая координата Core Location.\nТочность: примерно %.0f м.\nВозраст: %.0f сек.\n\nТочные координаты не записаны. Этот результат не подтверждает исправность геокодера штатной «Погоды» или каждого источника GPS/Wi-Fi по отдельности.", location.horizontalAccuracy, fabs([location.timestamp timeIntervalSinceNow])];
    [self stopLocation]; [self setBusy:NO]; _report.text = result;
}
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations { [self acceptLocation:[locations lastObject]]; }
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation { [self acceptLocation:newLocation]; }
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
    if (!_locationRunning || ([[error domain] isEqualToString:kCLErrorDomain] && [error code] == kCLErrorLocationUnknown)) return;
    [self stopLocation]; [self setBusy:NO];
    _report.text = [NSString stringWithFormat:@"ГЕОПОЗИЦИЯ: %@\n%@", MWErrorSummary(error), [error localizedDescription]];
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    if (_locationRunning) { [self stopLocation]; [self setBusy:NO]; }
}
@end

@interface MWCheckDelegate : NSObject <UIApplicationDelegate> { UIWindow *_window; }
@property(nonatomic, retain) UIWindow *window;
@end
@implementation MWCheckDelegate
@synthesize window = _window;
- (void)dealloc { [_window release]; [super dealloc]; }
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    self.window.rootViewController = [[[MWCheckController alloc] init] autorelease];
    [self.window makeKeyAndVisible];
    return YES;
}
- (void)applicationDidEnterBackground:(UIApplication *)application {
    MWCheckController *controller = (MWCheckController *)self.window.rootViewController;
    [controller stopLocation];
}
@end

int main(int argc, char **argv) {
    @autoreleasepool { return UIApplicationMain(argc, argv, nil, NSStringFromClass([MWCheckDelegate class])); }
}
