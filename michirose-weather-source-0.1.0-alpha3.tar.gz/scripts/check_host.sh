#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/build"
clang -fno-objc-arc -fblocks -DMW_HOST_TEST=1 -Werror=unguarded-availability \
  -Wno-deprecated-declarations -Wall -Wextra -Wno-unused-parameter \
  -framework Foundation -framework CoreFoundation -I"$ROOT/Sources" \
  "$ROOT/Sources/MWWeatherEngine.m" "$ROOT/Sources/MWWeatherProtocol.m" \
  "$ROOT/Sources/MWDiagnostics.m" \
  "$ROOT/Tests/probe.m" -o "$ROOT/build/weather-probe"
"$ROOT/build/weather-probe" --self-test "$ROOT/Tests/fixtures"
