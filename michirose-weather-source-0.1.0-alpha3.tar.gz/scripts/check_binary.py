#!/usr/bin/env python3
"""Inspect the actual Mach-O header/load commands, not compiler arguments."""
import struct
import sys
import hashlib
from pathlib import Path

for name in sys.argv[1:]:
    data = Path(name).read_bytes()
    magic, cpu, subtype, kind, count, size, flags = struct.unpack_from('<7I', data)
    assert magic == 0xFEEDFACE and cpu == 12 and (subtype & 0xFFFFFF) == 9, name
    cursor = 28
    minimum = signature = False
    for _ in range(count):
        command, length = struct.unpack_from('<2I', data, cursor)
        assert length >= 8 and cursor + length <= 28 + size
        assert command not in (0x80000034, 0x80000033, 0x32), 'modern dyld commands are incompatible with iOS 6'
        if command == 0x25:
            version, sdk = struct.unpack_from('<2I', data, cursor + 8)
            assert version == 0x60000, (name, version)
            minimum = True
        if command == 0x1D:
            offset, size_ = struct.unpack_from('<2I', data, cursor + 8)
            assert offset > 0 and size_ > 0 and offset + size_ <= len(data)
            magic_, length_, entries = struct.unpack_from('>3I', data, offset)
            assert magic_ == 0xFADE0CC0
            for index in range(entries):
                slot, relative = struct.unpack_from('>2I', data, offset + 12 + 8 * index)
                if slot != 0:
                    continue
                directory = offset + relative
                magic_cd, length_cd, version_cd, flags_cd, hash_offset, ident, specials, pages, limit = struct.unpack_from('>9I', data, directory)
                hash_size, hash_type, platform, page_power = struct.unpack_from('>4B', data, directory + 36)
                assert magic_cd == 0xFADE0C02 and hash_type == 1 and hash_size == 20
                page_size = 1 << page_power
                for page in range(pages):
                    actual = hashlib.sha1(data[page * page_size:min((page + 1) * page_size, limit)]).digest()
                    start = directory + hash_offset + page * hash_size
                    assert actual == data[start:start + hash_size], 'code signature page hash mismatch'
                signature = True
        cursor += length
    assert minimum and signature, name
    print(f'ARMv7 / iOS 6.0 load commands / embedded signature: {Path(name).name}')
