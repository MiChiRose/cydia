// SPDX-License-Identifier: GPL-3.0-only
#import "MWWeatherEngine.h"
#import "MWWeatherProtocol.h"
#import "MWDiagnostics.h"

static NSUInteger checks = 0;
static void Check(BOOL condition, NSString *label) {
    checks++;
    if (!condition) { fprintf(stderr, "FAIL: %s\n", [label UTF8String]); exit(1); }
}
static NSURLRequest *Request(NSString *query) {
    return [NSURLRequest requestWithURL:[NSURL URLWithString:[@"https://apple-mobile.query.yahooapis.com/v1/yql?"
        stringByAppendingString:MWEncodeQuery([NSDictionary dictionaryWithObjectsAndKeys:query, @"q", @"xml", @"format", nil])]]];
}
static NSString *ForecastQuery(NSString *identifier) {
    return [NSString stringWithFormat:@"select * from yql.query.multi where queries='select * from partner.weather.forecasts where woeid=%@ and lang=\"en-US\"; select * from partner.weather.forecasts where woeid=%@ and lang=\"en-US\"'", identifier, identifier];
}
@interface MWXMLCapture : NSObject <NSXMLParserDelegate> {
    NSMutableDictionary *_elements;
}
@property(nonatomic, readonly) NSMutableDictionary *elements;
@end
@implementation MWXMLCapture
@synthesize elements = _elements;
- (id)init { if ((self = [super init])) _elements = [[NSMutableDictionary alloc] init]; return self; }
- (void)dealloc { [_elements release]; [super dealloc]; }
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)element namespaceURI:(NSString *)uri qualifiedName:(NSString *)qualified attributes:(NSDictionary *)attrs {
    NSMutableArray *items = [_elements objectForKey:element];
    if (!items) { items = [NSMutableArray array]; [_elements setObject:items forKey:element]; }
    [items addObject:attrs];
}
@end
static NSDictionary *ParseXML(NSData *data) {
    Check(data != nil, @"XML response exists");
    MWXMLCapture *capture = [[[MWXMLCapture alloc] init] autorelease];
    NSXMLParser *parser = [[[NSXMLParser alloc] initWithData:data] autorelease];
    [parser setDelegate:capture];
    Check([parser parse], @"XML is well formed");
    return [capture elements];
}
static NSDictionary *Fixture(NSString *root, NSString *name) {
    NSData *data = [NSData dataWithContentsOfFile:[root stringByAppendingPathComponent:name]];
    Check(data != nil, @"fixture readable");
    return [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:NULL];
}
static void SelfTest(NSString *root) {
    NSDictionary *search = Fixture(root, @"search.json");
    NSDictionary *place = Fixture(root, @"place.json");
    NSDictionary *forecast = Fixture(root, @"forecast.json");
    __block NSUInteger fetches = 0;
    MWWeatherEngine *engine = [[[MWWeatherEngine alloc] initWithFetcher:^NSDictionary *(NSString *host, NSString *path, NSDictionary *params, NSError **error) {
        fetches++;
        Check([host hasSuffix:@"open-meteo.com"], @"provider hostname fixed");
        if ([path isEqualToString:@"/v1/search"]) {
            Check([[params objectForKey:@"name"] isEqualToString:@"Минск & test"], @"Unicode search survives URL encoding");
            return search;
        }
        if ([path isEqualToString:@"/v1/get"]) {
            Check([[params objectForKey:@"id"] longLongValue] == 625144, @"synthetic ID decodes to GeoNames");
            return place;
        }
        return forecast;
    }] autorelease];
    NSURLRequest *searchRequest = Request(@"select * from partner.weather.locations where query=\"Минск & test\" and lang='ru-RU'");
    Check(MWIsWeatherRequest(searchRequest), @"original Yahoo weather URL intercepted");
    Check(!MWIsWeatherRequest([NSURLRequest requestWithURL:[NSURL URLWithString:@"https://example.com/v1/yql?q=partner.weather.locations"]]), @"unrelated hostname untouched");
    Check(!MWIsWeatherRequest(Request(@"select * from yahoo.finance.quotes")), @"stocks untouched");
    Check(!MWIsWeatherRequest([NSURLRequest requestWithURL:[NSURL URLWithString:@"https://api.open-meteo.com/v1/forecast"]]), @"provider request cannot recurse");
    NSMutableURLRequest *post = [[searchRequest mutableCopy] autorelease]; [post setHTTPMethod:@"POST"];
    Check(!MWIsWeatherRequest(post), @"POST is outside scope");
    NSError *error = nil;
    NSDictionary *xml = ParseXML([engine responseForRequest:searchRequest error:&error]);
    NSDictionary *location = [[xml objectForKey:@"location"] objectAtIndex:0];
    Check([[location objectForKey:@"woeid"] isEqualToString:@"1000625144"], @"search returns reversible city ID");
    Check([[location objectForKey:@"city"] isEqualToString:@"Минск & \"test\" <city>"], @"XML attributes escaped exactly once");
    NSUInteger before = fetches;
    NSData *output = [engine responseForRequest:Request(ForecastQuery(@"1000625144")) error:&error];
    xml = ParseXML(output);
    Check(fetches == before + 2, @"duplicate query IDs fetched once");
    Check([[xml objectForKey:@"results"] count] == 3, @"Yahoo grouped results layout");
    Check([[xml objectForKey:@"day"] count] == 6, @"six upcoming days");
    Check([[xml objectForKey:@"hour"] count] == 12, @"twelve future hours");
    NSDictionary *current = [[xml objectForKey:@"currently"] objectAtIndex:0];
    Check([[current objectForKey:@"temp"] isEqualToString:@"-3"], @"negative temperature rounded correctly");
    Check([[current objectForKey:@"timezone"] isEqualToString:@"GMT+5:45"], @"fractional time zones preserved");
    Check([[current objectForKey:@"time24"] isEqualToString:@"23:30"], @"city local time used");
    Check([[current objectForKey:@"visibility"] isEqualToString:@"10.0"], @"visibility meters converted to km");
    Check(![current objectForKey:@"moonphase"], @"unavailable values are not fabricated");
    Check([[[[xml objectForKey:@"day"] objectAtIndex:0] objectForKey:@"dayOfWeek"] isEqualToString:@"6"], @"weekday derives from city forecast date");
    Check([[[[xml objectForKey:@"hour"] objectAtIndex:0] objectForKey:@"time24"] isEqualToString:@"00:00"], @"hourly forecast crosses midnight");
    before = fetches;
    Check([engine responseForRequest:Request(ForecastQuery(@"1000625144")) error:&error] != nil && before == fetches, @"forecast and city lookup cache reused");
    NSString *mixed = [ForecastQuery(@"2459115") stringByAppendingString:ForecastQuery(@"1000625144")];
    NSDictionary *mixedXML = ParseXML([engine responseForRequest:Request(mixed) error:&error]);
    Check([[mixedXML objectForKey:@"day"] count] == 6, @"old saved city does not block a new city in the same query");
    error = nil;
    Check(![engine responseForRequest:Request(ForecastQuery(@"2459115")) error:&error] && [error code] == 4, @"old Yahoo IDs require explicit city re-add");
    error = nil;
    Check(!MWParseQuery([Request(@"select * from partner.weather.forecasts where lat=91 and lon=27") URL], &error), @"invalid latitude rejected");
    NSDictionary *coords = MWParseQuery([Request(@"select * from partner.weather.forecasts where lat=-33 and lon=151 and lang='en-US'") URL], &error);
    Check([[coords objectForKey:@"latitude"] isEqualToString:@"-33"], @"integer and negative coordinates parsed");
    error = nil;
    Check(!MWParseQuery([Request(@"select * from partner.weather.forecasts where lat=1") URL], &error), @"partial coordinates rejected");
    Check(MWYahooCode(0, YES) == 32 && MWYahooCode(0, NO) == 31, @"day and night icons differ");
    Check(MWYahooCode(95, YES) == 4 && MWYahooCode(73, YES) == 16, @"thunder and snow icons mapped");
    MWWeatherEngine *broken = [[[MWWeatherEngine alloc] initWithFetcher:^NSDictionary *(NSString *h, NSString *p, NSDictionary *q, NSError **e) {
        if (e) *e = [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorServerCertificateUntrusted userInfo:nil];
        return nil;
    }] autorelease];
    error = nil;
    Check(![broken responseForRequest:searchRequest error:&error] && [error code] == NSURLErrorServerCertificateUntrusted, @"TLS failures propagate without bypass");
    NSMutableDictionary *invalid = [[forecast mutableCopy] autorelease];
    NSMutableDictionary *invalidCurrent = [[[invalid objectForKey:@"current"] mutableCopy] autorelease];
    [invalidCurrent setObject:[NSNull null] forKey:@"temperature_2m"];
    [invalid setObject:invalidCurrent forKey:@"current"];
    MWWeatherEngine *nullEngine = [[[MWWeatherEngine alloc] initWithFetcher:^NSDictionary *(NSString *h, NSString *p, NSDictionary *q, NSError **e) { return [p isEqualToString:@"/v1/get"] ? place : invalid; }] autorelease];
    error = nil;
    Check(![nullEngine responseForRequest:Request(ForecastQuery(@"1000625144")) error:&error] && [error code] == 3, @"null temperature does not become zero degrees");
    printf("PASS: %lu protocol, mapping, cache and failure checks\n", (unsigned long)checks);
}
static int Live(NSString *term) {
    // Exercise NSURLConnection -> NSURLProtocol -> provider -> Yahoo XML, not just the converter.
    [NSURLProtocol registerClass:[MWWeatherProtocol class]];
    NSError *error = nil;
    NSURLResponse *response = nil;
    NSString *query = [NSString stringWithFormat:@"select * from partner.weather.locations where query=\"%@\" and lang='en-US'", term];
    NSData *data = [NSURLConnection sendSynchronousRequest:Request(query) returningResponse:&response error:&error];
    if (!data) { fprintf(stderr, "SEARCH FAIL: %s (%ld)\n", [[error localizedDescription] UTF8String], (long)[error code]); return 1; }
    NSDictionary *xml = ParseXML(data);
    NSArray *locations = [xml objectForKey:@"location"];
    if (![locations count]) { fprintf(stderr, "No city matches\n"); return 1; }
    NSString *identifier = [[locations objectAtIndex:0] objectForKey:@"woeid"];
    data = [NSURLConnection sendSynchronousRequest:Request(ForecastQuery(identifier)) returningResponse:&response error:&error];
    if (!data) { fprintf(stderr, "FORECAST FAIL: %s (%ld)\n", [[error localizedDescription] UTF8String], (long)[error code]); return 1; }
    xml = ParseXML(data);
    printf("LIVE PASS: HTTP %ld, %lu daily rows, %lu hourly rows; original Yahoo URL handled locally\n",
        (long)[(NSHTTPURLResponse *)response statusCode], (unsigned long)[[xml objectForKey:@"day"] count], (unsigned long)[[xml objectForKey:@"hour"] count]);
    return 0;
}
int main(int argc, char **argv) {
    @autoreleasepool {
        NSString *mode = argc > 1 ? [NSString stringWithUTF8String:argv[1]] : @"";
        if (argc == 3 && [mode isEqualToString:@"--self-test"]) { SelfTest([NSString stringWithUTF8String:argv[2]]); return 0; }
        if (argc == 3 && [mode isEqualToString:@"--live"]) return Live([NSString stringWithUTF8String:argv[2]]);
        if (argc == 3 && [mode isEqualToString:@"--diagnose"]) {
            printf("%s\n", [MWRunWeatherDiagnostics([NSString stringWithUTF8String:argv[2]]) UTF8String]); return 0;
        }
        fprintf(stderr, "Usage: weather-probe --self-test FIXTURES | --live CITY | --diagnose CITY\n");
        return 2;
    }
}
