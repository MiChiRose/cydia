#!/bin/sh
# launchd runs this as mobile. Only our signed helper is copied/executed.
set -eu
# The helper checks its real and effective UID before starting the service.
TASK_CACHE=/var/mobile/Library/Caches/com.michirose.telegraphica.background
/bin/mkdir -p "$TASK_CACHE"
/bin/chmod 700 "$TASK_CACHE"
/bin/cp /Library/Telegraphica/TelegraphicaBackground "$TASK_CACHE/TelegraphicaBackground"
/bin/chmod 700 "$TASK_CACHE/TelegraphicaBackground"
exec "$TASK_CACHE/TelegraphicaBackground" --watch-app "$1" "$2"
