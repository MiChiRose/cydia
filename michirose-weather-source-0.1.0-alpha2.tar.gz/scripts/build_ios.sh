#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${MW_SDKROOT:?Set MW_SDKROOT to an ARMv7-capable iPhoneOS SDK (tested: Theos iPhoneOS9.3.sdk).}"
: "${MW_LDID:?Set MW_LDID to a local ldid executable.}"
mkdir -p "$ROOT/build/stubs"
# Modern TAPI interprets mixed device/simulator v1 stubs ambiguously.
# Thin linker stubs only; headers and the source SDK remain unchanged.
for framework in Foundation CoreFoundation CFNetwork; do
    mkdir -p "$ROOT/build/stubs/$framework.framework"
    xcrun tapi archive --extract armv7 \
      "$MW_SDKROOT/System/Library/Frameworks/$framework.framework/$framework.tbd" \
      -o "$ROOT/build/stubs/$framework.framework/$framework.tbd"
done
mkdir -p "$ROOT/build/libs"
xcrun tapi archive --extract armv7 "$MW_SDKROOT/usr/lib/libSystem.B.tbd" -o "$ROOT/build/libs/libSystem.tbd"
xcrun tapi archive --extract armv7 "$MW_SDKROOT/usr/lib/libobjc.A.tbd" -o "$ROOT/build/libs/libobjc.tbd"
COMMON=(-target armv7-apple-ios6.0 -isysroot "$MW_SDKROOT" -fno-objc-arc -fblocks -Os
  -Wall -Wextra -Wno-unused-parameter -Werror=unguarded-availability -I"$ROOT/Sources"
  -Wl,-F,"$ROOT/build/stubs" -L"$ROOT/build/libs" -framework Foundation -framework CoreFoundation -framework CFNetwork
  -Wl,-no_fixup_chains,-no_adhoc_codesign)
clang "${COMMON[@]}" -dynamiclib \
  -Wl,-install_name,/Library/MobileSubstrate/DynamicLibraries/MiChiRoseWeather.dylib \
  "$ROOT/Sources/MWWeatherEngine.m" "$ROOT/Sources/MWWeatherProtocol.m" -o "$ROOT/build/MiChiRoseWeather.dylib"
clang "${COMMON[@]}" -DMW_HOST_TEST=1 \
  "$ROOT/Sources/MWWeatherEngine.m" "$ROOT/Sources/MWWeatherProtocol.m" "$ROOT/Tests/probe.m" \
  -o "$ROOT/build/michirose-weather-probe"
"$MW_LDID" -Hsha1 -S "$ROOT/build/MiChiRoseWeather.dylib"
"$MW_LDID" -Hsha1 -S "$ROOT/build/michirose-weather-probe"
python3 "$ROOT/scripts/check_binary.py" "$ROOT/build/MiChiRoseWeather.dylib" "$ROOT/build/michirose-weather-probe"
python3 "$ROOT/scripts/package.py"
python3 "$ROOT/Tests/check_deb_layout.py" --current
