// SPDX-License-Identifier: GPL-3.0-only
#import "MWWeatherProtocol.h"
#import "MWWeatherEngine.h"

@implementation MWWeatherProtocol
+ (BOOL)canInitWithRequest:(NSURLRequest *)request { return MWIsWeatherRequest(request); }
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }
- (void)startLoading {
    @synchronized(self) { if (_stopped || _operation) return; }
    NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
        @autoreleasepool {
            NSError *error = nil;
            NSData *data = nil;
            @try { data = [[MWWeatherEngine sharedEngine] responseForRequest:[self request] error:&error]; }
            @catch (NSException *exception) {
                error = [NSError errorWithDomain:@"com.michirose.weather" code:3
                    userInfo:[NSDictionary dictionaryWithObject:@"Unexpected weather response format." forKey:NSLocalizedDescriptionKey]];
            }
            @synchronized(self) {
                [_operation release];
                _operation = nil;
                if (_stopped) return;
                if (!data) {
                    // Log the error code only; queries, cities and coordinates are not logged.
                    NSLog(@"[MiChiRoseWeather] Request failed (%@:%ld).", [error domain], (long)[error code]);
                    [[self client] URLProtocol:self didFailWithError:error ?: [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorUnknown userInfo:nil]];
                } else {
                    NSHTTPURLResponse *response = [[[NSHTTPURLResponse alloc] initWithURL:[[self request] URL]
                        statusCode:200 HTTPVersion:@"HTTP/1.1" headerFields:[NSDictionary dictionaryWithObjectsAndKeys:
                            @"application/xml; charset=utf-8", @"Content-Type", @"no-store", @"Cache-Control", nil]] autorelease];
                    [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
                    if (!_stopped) [[self client] URLProtocol:self didLoadData:data];
                    if (!_stopped) [[self client] URLProtocolDidFinishLoading:self];
                }
            }
        }
    }];
    @synchronized(self) {
        if (_stopped) return;
        _operation = [operation retain];
    }
    static NSOperationQueue *queue = nil;
    @synchronized([MWWeatherProtocol class]) {
        if (!queue) { queue = [[NSOperationQueue alloc] init]; [queue setMaxConcurrentOperationCount:2]; }
    }
    [queue addOperation:operation];
}
- (void)stopLoading {
    @synchronized(self) { _stopped = YES; [_operation cancel]; [_operation release]; _operation = nil; }
}
- (void)dealloc { [_operation cancel]; [_operation release]; [super dealloc]; }
@end

#ifndef MW_HOST_TEST
__attribute__((constructor)) static void MWInstallWeatherProtocol(void) {
    @autoreleasepool {
        // Even if the injection filter is changed, avoid altering other applications.
        if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.weather"]) return;
        [NSURLProtocol registerClass:[MWWeatherProtocol class]];
        NSLog(@"[MiChiRoseWeather] Direct Open-Meteo bridge loaded (0.1.0 alpha 1).");
    }
}
#endif
