#!/bin/sh
# launchd runs this as mobile. Only our signed helper is copied/executed.
set -eu
[ "$(/usr/bin/id -u)" = 501 ] || exit 2
TASK_CACHE=/var/mobile/Library/Caches/com.michirose.telegraphica.background
/bin/mkdir -p "$TASK_CACHE"
/bin/chmod 700 "$TASK_CACHE"
/bin/cp /Library/Telegraphica/TelegraphicaBackground "$TASK_CACHE/TelegraphicaBackground"
/bin/chmod 700 "$TASK_CACHE/TelegraphicaBackground"
exec "$TASK_CACHE/TelegraphicaBackground" --watch-app "$1" "$2"
