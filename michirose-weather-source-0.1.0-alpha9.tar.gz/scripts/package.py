#!/usr/bin/env python3
"""Build a gzip-only DEB compatible with old dpkg; include corresponding source."""
import gzip
import hashlib
import io
import plistlib
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist'
OUT.mkdir(exist_ok=True)
CONTROL_TEXT = (ROOT / 'packaging/control').read_text()
VERSION = next(line.split(': ', 1)[1] for line in CONTROL_TEXT.splitlines() if line.startswith('Version: '))

def archive(files):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as tf:
        # dpkg unpacks files directly, unlike tar extractors that silently make
        # missing parents. Every directory must be an explicit earlier member.
        directories = {Path('.')}
        for name, _, _ in files:
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            directories.update(path.parents)
        for path in sorted(directories, key=lambda p: (len(p.parts), str(p))):
            info = tarfile.TarInfo('./' if path == Path('.') else './' + str(path) + '/')
            info.type = tarfile.DIRTYPE
            info.mode, info.mtime = 0o755, 0
            info.uid = info.gid = 0
            info.uname = info.gname = 'root'
            tf.addfile(info)
        for name, content, executable in sorted(files):
            info = tarfile.TarInfo('./' + name)
            info.size, info.mtime = len(content), 0
            info.mode = 0o755 if executable else 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = 'root'
            tf.addfile(info, io.BytesIO(content))
    return gzip.compress(buffer.getvalue(), mtime=0)

source_files = []
for path in ROOT.rglob('*'):
    relative = path.relative_to(ROOT)
    if not path.is_file() or any(part in ('.git', 'build', 'dist', '__pycache__', '.pytest_cache') for part in relative.parts):
        continue
    source_files.append((str(relative), path.read_bytes(), path.suffix == '.sh'))
source = archive(source_files)
(OUT / f'michirose-weather-source-{VERSION.replace("~", "-")}.tar.gz').write_bytes(source)
data = [
    ('Library/MobileSubstrate/DynamicLibraries/MiChiRoseWeather.dylib', (ROOT / 'build/MiChiRoseWeather.dylib').read_bytes(), True),
    ('Library/MobileSubstrate/DynamicLibraries/MiChiRoseWeather.plist', (ROOT / 'packaging/MiChiRoseWeather.plist').read_bytes(), False),
    ('usr/bin/michirose-weather-probe', (ROOT / 'build/michirose-weather-probe').read_bytes(), True),
    ('usr/bin/michirose-weather-loadcheck', (ROOT / 'build/michirose-weather-loadcheck').read_bytes(), True),
    ('usr/share/doc/com.michirose.weather/README.md', (ROOT / 'README.md').read_bytes(), False),
    ('usr/share/doc/com.michirose.weather/LICENSE', (ROOT / 'LICENSE').read_bytes(), False),
    ('usr/share/doc/com.michirose.weather/THIRD_PARTY_NOTICES.md', (ROOT / 'THIRD_PARTY_NOTICES.md').read_bytes(), False),
    ('usr/share/doc/com.michirose.weather/source.tar.gz', source, False),
]
for name in ('MbedTLS-LICENSE', 'MbedTLS-NOTICE'):
    document = ROOT / 'Resources' / name
    if document.exists():
        data.append((f'usr/share/doc/com.michirose.weather/{name}', document.read_bytes(), False))
# Explicit payload allowlist: stale developer app builds can never enter a DEB.
assert not any(name.startswith('Applications/') or '.app/' in name for name, _, _ in data)
plist = plistlib.loads(data[1][1])
assert plist['Filter']['Bundles'] == ['com.apple.weather']
control_text = CONTROL_TEXT
control_text += f'Installed-Size: {(sum(len(content) for _, content, _ in data) + 1023) // 1024}\n'
control = [('control', control_text.encode(), False)]
for script in ('preinst', 'postinst', 'postrm'):
    control.append((script, (ROOT / 'packaging' / script).read_bytes(), True))
control.append(('md5sums', ''.join(f'{hashlib.md5(content).hexdigest()}  {name}\n' for name, content, _ in data).encode(), False))
members = [('debian-binary', b'2.0\n'), ('control.tar.gz', archive(control)), ('data.tar.gz', archive(data))]
deb = bytearray(b'!<arch>\n')
for name, content in members:
    header = f'{name + "/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(content):<10}`\n'
    assert len(header) == 60
    deb += header.encode() + content
    if len(content) % 2: deb += b'\n'
path = OUT / f'michirose-weather_{VERSION}_iphoneos-arm.deb'
path.write_bytes(deb)
# Re-open both archive layers to verify package paths and script executable bits.
with tarfile.open(fileobj=io.BytesIO(members[1][1]), mode='r:gz') as tf:
    assert tf.getmember('./preinst').mode == 0o755
with tarfile.open(fileobj=io.BytesIO(members[2][1]), mode='r:gz') as tf:
    seen_directories = {Path('.')}
    for member in tf:
        path_ = Path(member.name)
        assert not path_.is_absolute() and '..' not in path_.parts
        assert all(parent in seen_directories for parent in path_.parents), member.name
        if member.isdir():
            assert member.mode == 0o755
            seen_directories.add(path_)
        else:
            assert member.isfile()
(OUT / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256SUMS'))
print(f'Built {path.name} ({path.stat().st_size} bytes); includes corresponding source.')
