#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/build"
TLS="$ROOT/build/tls-host"
bash "$ROOT/scripts/build_tls.sh" "$TLS" > "$ROOT/build/tls-host.log" 2>&1
clang -fno-objc-arc -fblocks -DMW_HOST_TEST=1 -Werror=unguarded-availability \
  -Wno-deprecated-declarations -Wall -Wextra -Wno-unused-parameter \
  -framework Foundation -framework CoreFoundation -I"$ROOT/Sources" \
  -I"$TLS" -I"$TLS/mbedtls-3.6.7/include" '-DMBEDTLS_CONFIG_FILE="mw_mbedtls_config.h"' \
  "$ROOT/Sources/MWWeatherEngine.m" "$ROOT/Sources/MWWeatherProtocol.m" \
  "$ROOT/Sources/MWDiagnostics.m" \
  "$ROOT/Tests/probe.m" "$ROOT/Sources/MWHTTPS.m" "$ROOT/Sources/MWManualRefresh.m" \
  "$TLS/mbedtls-3.6.7/library/libmbedtls.a" "$TLS/mbedtls-3.6.7/library/libmbedx509.a" "$TLS/mbedtls-3.6.7/library/libmbedcrypto.a" \
  -o "$ROOT/build/weather-probe"
"$ROOT/build/weather-probe" --self-test "$ROOT/Tests/fixtures"
