// SPDX-License-Identifier: GPL-3.0-only
#import <Foundation/Foundation.h>

typedef NSDictionary *(^MWJSONFetcher)(NSString *host, NSString *path,
                                      NSDictionary *parameters, NSError **error);

BOOL MWIsWeatherRequest(NSURLRequest *request);
NSDictionary *MWParseQuery(NSURL *url, NSError **error);
NSString *MWEncodeQuery(NSDictionary *parameters);
NSInteger MWYahooCode(NSInteger wmo, BOOL daytime);

@interface MWWeatherEngine : NSObject {
    MWJSONFetcher _fetcher;
    NSCache *_cache;
}
- (id)initWithFetcher:(MWJSONFetcher)fetcher;
- (NSData *)responseForRequest:(NSURLRequest *)request error:(NSError **)error;
- (void)invalidateForecastCache;
+ (MWWeatherEngine *)sharedEngine;
@end
