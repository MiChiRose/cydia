// SPDX-License-Identifier: GPL-3.0-only
#import "MWManualRefresh.h"
#import "MWWeatherEngine.h"
#import <objc/runtime.h>
#import <dispatch/dispatch.h>

NSString *const MWCityRefreshFinished = @"MWCityRefreshFinished";
static NSString *const MWForcedCityKey = @"MWForcedWeatherCity";
static NSInteger (*MWOriginalAge)(id, SEL);
static void (*MWOriginalFinished)(id, SEL, int, int);

@interface NSObject (MWCityRefreshMethods)
- (NSInteger)weatherDataAge;
- (BOOL)_isUpdating;
- (void)update;
@end

static NSInteger MWCityAge(id city, SEL selector) {
    // Bypass only the freshness gate during this specific manual invocation.
    // Other cities, automatic updates and the saved update time are untouched.
    if ([[[NSThread currentThread] threadDictionary] objectForKey:MWForcedCityKey] == city) return 1;
    return MWOriginalAge(city, selector);
}

static void MWCityFinished(id city, SEL selector, int status, int detail) {
    MWOriginalFinished(city, selector, status, detail);
    // Native City sets its update time only for status 0, after accepting the
    // parsed forecast. A successful HTTP transfer alone is not confirmation.
    NSLog(@"[MiChiRoseWeather] Native city update finished (status=%d, detail=%d).", status, detail);
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:
        [NSNumber numberWithInt:status], @"status", [NSNumber numberWithInt:detail], @"detail", nil];
    void (^notify)(void) = ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:MWCityRefreshFinished object:city userInfo:info];
    };
    if ([NSThread isMainThread]) notify();
    else dispatch_async(dispatch_get_main_queue(), notify);
}

BOOL MWInstallCityRefreshHooks(Class cityClass) {
    if (!cityClass || MWOriginalAge) return NO;
    Method age = class_getInstanceMethod(cityClass, @selector(weatherDataAge));
    Method finished = class_getInstanceMethod(cityClass, NSSelectorFromString(@"finishedUpdating:statusDetail:"));
    if (!age || !finished) return NO;
    MWOriginalAge = (NSInteger (*)(id, SEL))method_getImplementation(age);
    MWOriginalFinished = (void (*)(id, SEL, int, int))method_getImplementation(finished);
    if (!class_addMethod(cityClass, @selector(weatherDataAge), (IMP)MWCityAge, method_getTypeEncoding(age)))
        method_setImplementation(age, (IMP)MWCityAge);
    SEL selector = NSSelectorFromString(@"finishedUpdating:statusDetail:");
    if (!class_addMethod(cityClass, selector, (IMP)MWCityFinished, method_getTypeEncoding(finished)))
        method_setImplementation(finished, (IMP)MWCityFinished);
    return YES;
}

BOOL MWForceCityRefresh(id city) {
    if (!MWOriginalAge || ![city respondsToSelector:@selector(update)] ||
        ![city respondsToSelector:@selector(_isUpdating)] || [city _isUpdating]) return NO;
    NSMutableDictionary *thread = [[NSThread currentThread] threadDictionary];
    id previous = [[thread objectForKey:MWForcedCityKey] retain];
    @try {
        [[MWWeatherEngine sharedEngine] invalidateForecastCache];
        [thread setObject:city forKey:MWForcedCityKey];
        [city update];
    } @finally {
        if (previous) [thread setObject:previous forKey:MWForcedCityKey];
        else [thread removeObjectForKey:MWForcedCityKey];
        [previous release];
    }
    return YES;
}
