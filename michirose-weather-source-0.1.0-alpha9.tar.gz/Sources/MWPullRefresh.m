// SPDX-License-Identifier: GPL-3.0-only
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <math.h>
#import "MWManualRefresh.h"

// Selectors verified against the stock iOS 6.1.3 Weather executable. No
// private ivar offsets and no changes to Apple's executable are required.
@interface NSObject (MWStockWeatherRefresh)
- (id)controller;
- (id)tabController;
- (id)activeCity;
- (BOOL)_isUpdating;
- (NSDate *)updateTime;
@end

static char MWPullKey;
static NSTimeInterval MWLastPull;
static void (*MWOriginalDidMoveToWindow)(id, SEL);

@interface MWPullRefresh : NSObject <UIGestureRecognizerDelegate> {
    UIPanGestureRecognizer *_pan;
    UILabel *_hint;
    id _pendingCity;
    NSTimer *_timer;
    BOOL _russian;
}
- (id)initWithView:(UIView *)view;
@end

@implementation MWPullRefresh
- (id)initWithView:(UIView *)view {
    if ((self = [super init])) {
        _russian = [[[NSLocale preferredLanguages] objectAtIndex:0] hasPrefix:@"ru"];
        _pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pulled:)];
        _pan.maximumNumberOfTouches = 1;
        _pan.delegate = self;
        _pan.cancelsTouchesInView = NO;
        // Only the header accepts this gesture. Let native vertical drawers
        // and horizontal city paging win everywhere else.
        for (UIView *ancestor = view; ancestor; ancestor = ancestor.superview) {
            for (UIGestureRecognizer *other in ancestor.gestureRecognizers) {
                if ([other isKindOfClass:[UIPanGestureRecognizer class]])
                    [other requireGestureRecognizerToFail:_pan];
            }
        }
        [view addGestureRecognizer:_pan];
        _hint = [[UILabel alloc] initWithFrame:CGRectMake(8, 2, view.bounds.size.width - 16, 24)];
        _hint.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        _hint.backgroundColor = [UIColor clearColor];
        _hint.textColor = [UIColor whiteColor];
        _hint.shadowColor = [UIColor colorWithWhite:0 alpha:0.6];
        _hint.shadowOffset = CGSizeMake(0, 1);
        _hint.font = [UIFont boldSystemFontOfSize:11];
        _hint.textAlignment = NSTextAlignmentCenter;
        _hint.userInteractionEnabled = NO;
        _hint.hidden = YES;
        [view addSubview:_hint];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cityFinished:)
            name:MWCityRefreshFinished object:nil];
        NSLog(@"[MiChiRoseWeather] Pull-to-refresh gesture installed.");
    }
    return self;
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [_timer invalidate];
    [_timer release];
    [_pendingCity release];
    _pan.delegate = nil;
    [_pan removeTarget:self action:@selector(pulled:)];
    [_pan release];
    [_hint release];
    [super dealloc];
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gesture shouldReceiveTouch:(UITouch *)touch {
    UIView *view = _pan.view;
    CGPoint point = [touch locationInView:view];
    if (!view.window || point.y < 0 || point.y > 90) return NO;
    // Do not take touches from buttons, including controls from other tweaks.
    for (UIView *hit = touch.view; hit && hit != view; hit = hit.superview)
        if ([hit isKindOfClass:[UIControl class]]) return NO;
    return YES;
}
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gesture {
    CGPoint delta = [_pan translationInView:_pan.view];
    return delta.y > 0 && delta.y > fabs(delta.x) * 1.5;
}
- (void)pulled:(UIPanGestureRecognizer *)gesture {
    UIView *view = _pan.view;
    CGFloat distance = [gesture translationInView:view].y;
    if (gesture.state == UIGestureRecognizerStateBegan || gesture.state == UIGestureRecognizerStateChanged) {
        if (_pendingCity) return;
        _hint.hidden = NO;
        _hint.text = distance >= 64 ? (_russian ? @"Отпустите для обновления" : @"Release to refresh")
            : (_russian ? @"↓ Потяните для обновления" : @"↓ Pull to refresh");
        [view bringSubviewToFront:_hint];
        return;
    }
    if (_pendingCity) return;
    _hint.hidden = YES;
    if (gesture.state != UIGestureRecognizerStateEnded || distance < 64) return;
    // A held/rapidly repeated pull must not flood the public weather service.
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (now - MWLastPull < 10) {
        [self showResult:(_russian ? @"Подождите несколько секунд" : @"Please wait a few seconds")];
        return;
    }
    id application = [UIApplication sharedApplication];
    id controller = [application respondsToSelector:@selector(controller)] ? [application controller] : nil;
    id tabs = [controller respondsToSelector:@selector(tabController)] ? [controller tabController] : nil;
    id city = [tabs respondsToSelector:@selector(activeCity)] ? [tabs activeCity] : nil;
    if (!city) return;
    if ([city respondsToSelector:@selector(_isUpdating)] && [city _isUpdating]) {
        [self showResult:(_russian ? @"Обновление уже идёт…" : @"Already updating…")];
        return;
    }
    MWLastPull = now;
    _pendingCity = [city retain];
    [_timer invalidate]; [_timer release];
    _timer = [[NSTimer scheduledTimerWithTimeInterval:45 target:self selector:@selector(refreshTimedOut:)
        userInfo:nil repeats:NO] retain];
    _hint.hidden = NO;
    _hint.text = _russian ? @"Обновление…" : @"Updating…";
    NSLog(@"[MiChiRoseWeather] Forced manual city refresh requested.");
    @try {
        if (!MWForceCityRefresh(city)) [self showResult:(_russian ? @"Не удалось начать обновление" : @"Could not start refresh")];
    } @catch (NSException *exception) {
        [self showResult:(_russian ? @"Ошибка обновления" : @"Refresh failed")];
    }
}
- (void)hideHint:(NSTimer *)timer {
    _hint.hidden = YES;
    [_timer invalidate]; [_timer release]; _timer = nil;
}
- (void)showResult:(NSString *)text {
    [_pendingCity release]; _pendingCity = nil;
    [_timer invalidate]; [_timer release];
    _hint.text = text;
    _hint.hidden = NO;
    _timer = [[NSTimer scheduledTimerWithTimeInterval:4 target:self selector:@selector(hideHint:)
        userInfo:nil repeats:NO] retain];
}
- (void)refreshTimedOut:(NSTimer *)timer {
    [self showResult:(_russian ? @"Обновление не подтверждено" : @"Refresh not confirmed")];
}
- (void)cityFinished:(NSNotification *)notification {
    if (!_pendingCity || notification.object != _pendingCity) return;
    if ([[notification.userInfo objectForKey:@"status"] intValue] != 0) {
        [self showResult:(_russian ? @"Ошибка обновления" : @"Refresh failed")];
        return;
    }
    NSDate *updated = [_pendingCity respondsToSelector:@selector(updateTime)] ? [_pendingCity updateTime] : nil;
    if (!updated) { [self refreshTimedOut:nil]; return; }
    NSDateFormatter *formatter = [[[NSDateFormatter alloc] init] autorelease];
    formatter.dateStyle = NSDateFormatterNoStyle;
    formatter.timeStyle = NSDateFormatterShortStyle;
    [self showResult:[NSString stringWithFormat:_russian ? @"Обновлено в %@" : @"Updated at %@", [formatter stringFromDate:updated]]];
}
@end

static void MWCityDidMoveToWindow(UIView *view, SEL selector) {
    MWOriginalDidMoveToWindow(view, selector);
    if (view.window && !objc_getAssociatedObject(view, &MWPullKey)) {
        MWPullRefresh *pull = [[MWPullRefresh alloc] initWithView:view];
        objc_setAssociatedObject(view, &MWPullKey, pull, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [pull release];
    }
}

void MWInstallPullRefresh(void) {
    if (!MWInstallCityRefreshHooks(NSClassFromString(@"City"))) return;
    Class cityView = NSClassFromString(@"CityView");
    Method method = class_getInstanceMethod(cityView, @selector(didMoveToWindow));
    if (!method) return;
    MWOriginalDidMoveToWindow = (void (*)(id, SEL))method_getImplementation(method);
    // If inherited, add the override only to CityView, never to UIView itself.
    if (!class_addMethod(cityView, @selector(didMoveToWindow), (IMP)MWCityDidMoveToWindow, method_getTypeEncoding(method)))
        method_setImplementation(method, (IMP)MWCityDidMoveToWindow);
}
