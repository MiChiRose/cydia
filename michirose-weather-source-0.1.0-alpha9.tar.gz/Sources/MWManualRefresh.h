// SPDX-License-Identifier: GPL-3.0-only
#import <Foundation/Foundation.h>

extern NSString *const MWCityRefreshFinished;
BOOL MWInstallCityRefreshHooks(Class cityClass);
BOOL MWForceCityRefresh(id city);
