#!/usr/bin/env python3
"""Regress the missing-parent failure without running package scripts or dpkg."""
import argparse
import hashlib
import io
import tarfile
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def members(path):
    data = path.read_bytes()
    assert data.startswith(b'!<arch>\n')
    result, position = {}, 8
    while position < len(data):
        header = data[position:position + 60]
        assert len(header) == 60 and header[-2:] == b'`\n'
        size = int(header[48:58])
        result[header[:16].decode().strip().rstrip('/')] = data[position + 60:position + 60 + size]
        position += 60 + size + size % 2
    assert position == len(data)
    assert result['debian-binary'] == b'2.0\n'
    return result

def payloads(archive):
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tf:
        return {str(Path(item.name)): tf.extractfile(item).read() for item in tf if item.isfile()}

def unpack_without_implicit_parents(archive):
    # Emulate a phone with the standard jailbreak paths, but no package-specific
    # doc directory. open(...dpkg-new) must fail if a tar directory was omitted.
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        for name in ('Library/MobileSubstrate/DynamicLibraries', 'usr/bin', 'usr/share/doc'):
            (root / name).mkdir(parents=True)
        with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tf:
            for item in tf:
                relative = Path(item.name)
                assert not relative.is_absolute() and '..' not in relative.parts
                target = root / relative
                if item.isdir():
                    target.mkdir(exist_ok=True)  # deliberately no parents=True
                elif item.isfile():
                    staging = target.with_name(target.name + '.dpkg-new')
                    with staging.open('xb') as stream:
                        stream.write(tf.extractfile(item).read())
                    staging.rename(target)
                else:
                    raise AssertionError('unexpected non-file member')
        license_path = root / 'usr/share/doc/com.michirose.weather/LICENSE'
        assert license_path.read_bytes() == (ROOT / 'LICENSE').read_bytes()

def validate(path):
    archive = members(path)
    for key in ('control.tar.gz', 'data.tar.gz'):
        seen = {Path('.')}
        with tarfile.open(fileobj=io.BytesIO(archive[key]), mode='r:gz') as tf:
            for item in tf:
                name = Path(item.name)
                assert not name.is_absolute() and '..' not in name.parts
                assert all(parent in seen for parent in name.parents), item.name
                assert item.uid == item.gid == 0
                if item.isdir():
                    assert item.mode == 0o755
                    seen.add(name)
                else:
                    assert item.isfile()
    with tarfile.open(fileobj=io.BytesIO(archive['control.tar.gz']), mode='r:gz') as tf:
        for script in ('preinst', 'postinst', 'postrm'):
            assert tf.getmember('./' + script).mode == 0o755
    unpack_without_implicit_parents(archive['data.tar.gz'])
    print(f'PASS: explicit parent directories, modes and strict unpack: {path.name}')
    return archive

parser = argparse.ArgumentParser()
parser.add_argument('--current', action='store_true')
parser.add_argument('--regression', nargs=2, metavar=('BROKEN', 'FIXED'))
args = parser.parse_args()
if args.regression:
    old_path, new_path = map(Path, args.regression)
    old = members(old_path)
    try:
        unpack_without_implicit_parents(old['data.tar.gz'])
    except FileNotFoundError as error:
        assert Path(error.filename).name == 'LICENSE.dpkg-new', error
        print('REPRODUCED alpha 1: unable to create LICENSE.dpkg-new (missing parent directory)')
    else:
        raise AssertionError('old package did not reproduce the failure')
    new = validate(new_path)
    for name in ('Library/MobileSubstrate/DynamicLibraries/MiChiRoseWeather.dylib', 'usr/bin/michirose-weather-probe'):
        assert payloads(old['data.tar.gz'])[name] == payloads(new['data.tar.gz'])[name]
    print('PASS: installed weather binaries are byte-for-byte unchanged')
elif args.current:
    control = (ROOT / 'packaging/control').read_text()
    version = next(line.split(': ', 1)[1] for line in control.splitlines() if line.startswith('Version: '))
    current = validate(ROOT / 'dist' / f'michirose-weather_{version}_iphoneos-arm.deb')
    paths = payloads(current['data.tar.gz'])
    assert not any(name.startswith('Applications/') or '.app/' in name for name in paths), 'release must not install an app or SpringBoard icon'
    print('PASS: release payload installs no application bundle or extra icon')
else:
    parser.error('pass --current or --regression BROKEN FIXED')
