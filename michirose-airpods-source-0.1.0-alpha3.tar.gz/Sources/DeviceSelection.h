// MIT. Match the selected route to an already-connected legacy Bluetooth object.
#import "ServiceLease.h"
id<MWLeaseDevice> MWSelectAudioDevice(NSArray *devices,NSString *routeUID,NSString *routeName);
