// MIT. Legacy system alert; no app, launcher icon or new notification section.
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <dispatch/dispatch.h>
#include <dlfcn.h>
#include <syslog.h>

void MWShowConnectionLossNotice(void) {
    NSArray *languages=[NSLocale preferredLanguages];
    BOOL russian=[languages count] && [[languages objectAtIndex:0] hasPrefix:@"ru"];
    NSString *message=russian ? @"Соединение с наушниками потеряно. Возможно, они переключились на другое устройство."
        : @"The headphones disconnected. They may have switched to another device.";
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
        @autoreleasepool {
            // Present in the actual SDK 6.1 CoreFoundation binary. It is not
            // declared in the public iPhone headers; resolve the legacy API.
            typedef SInt32 (*Notice)(CFTimeInterval,CFOptionFlags,CFURLRef,CFURLRef,CFURLRef,CFStringRef,CFStringRef,CFStringRef);
            Notice notice=(Notice)dlsym(RTLD_DEFAULT,"CFUserNotificationDisplayNotice");
            if(!notice) { syslog(LOG_NOTICE,"AirPodsFix: system notification API unavailable"); return; }
            // No sound URL, no reconnect button. Keep UI work off the audio
            // watchdog/main thread; the native system alert expires in 15 s.
            SInt32 error=notice(15,3,NULL,NULL,NULL,CFSTR("AirPods Fix"),(CFStringRef)message,CFSTR("OK"));
            syslog(LOG_NOTICE,"AirPodsFix: connection-loss notice result=%d",(int)error);
        }
    });
}
