// MIT. Independent implementation of continuous silent A2DP playback.
// The approach is documented by asentientbot/ios-6-pods-hack and
// mikey820/AirPodsReconnectFix; no source/audio assets from them are included.
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreTelephony/CTCallCenter.h>
#import <dispatch/dispatch.h>
#include <sys/sysctl.h>
#include <syslog.h>
#include <string.h>
#include <dlfcn.h>
#import "KeepWarmEngine.h"
#import "RoutePolicy.h"
#import "ServiceLease.h"
#import "DeviceSelection.h"
#include "LossNotice.h"
extern void MWShowConnectionLossNotice(void);

// These read-only selectors are present in the iOS 6 BluetoothManager binary.
@interface NSObject (MWBluetoothAudioState)
+ (id)sharedInstance;
- (BOOL)audioConnected;
- (BOOL)enabled;
- (NSArray *)connectedDevices;
- (NSString *)address;
- (NSString *)name;
- (unsigned)majorClass;
@end

static BOOL MWA2DPRoute(AVAudioSession *session) {
    for (AVAudioSessionPortDescription *port in session.currentRoute.outputs)
        if ([port.portType isEqualToString:AVAudioSessionPortBluetoothA2DP]) return YES;
    return NO;
}

static MWRouteKind MWOutputKind(AVAudioSession *session) {
    if(MWA2DPRoute(session)) return MWRouteA2DP;
    NSArray *outputs=session.currentRoute.outputs;
    if(![outputs count]) return MWRouteUnknown;
    for(AVAudioSessionPortDescription *port in outputs)
        if(![port.portType isEqualToString:AVAudioSessionPortBuiltInSpeaker] &&
            ![port.portType isEqualToString:AVAudioSessionPortBuiltInReceiver]) return MWRouteOther;
    return MWRouteBuiltIn;
}

static id<MWLeaseDevice> MWSelectedDevice(id manager,AVAudioSession *session) {
    if(![manager respondsToSelector:@selector(connectedDevices)]) return nil;
    for(AVAudioSessionPortDescription *port in session.currentRoute.outputs)
        if([port.portType isEqualToString:AVAudioSessionPortBluetoothA2DP])
            return MWSelectAudioDevice([manager connectedDevices],port.UID,port.portName);
    return nil;
}

@interface AVAudioPlayer (MWWarmPlayer) <MWWarmPlayer>
@end

@interface MWWarmService : NSObject <MWWarmBackend> {
    MWWarmEngine *_engine;
    CTCallCenter *_calls;
    id _bluetooth;
    MWServiceLease *_lease;
    id<MWLeaseDevice> _routeDevice;
    MWRoutePolicy _policy;
    MWLossNotice _lossNotice;
    MWRouteKind _lastKind;
    BOOL _recordedState, _lastCall, _lastAllowed;
    BOOL _evaluating, _ownsSession;
    NSString *_previousCategory;
    NSMutableArray *_events;
    AVAudioSessionCategoryOptions _previousOptions;
}
- (void)evaluate;
@end

@implementation MWWarmService
- (id)init {
    if ((self = [super init])) {
        _events = [[NSMutableArray alloc] init];
        _calls = [[CTCallCenter alloc] init];
        dlopen("/System/Library/PrivateFrameworks/BluetoothManager.framework/BluetoothManager", RTLD_LAZY);
        Class managerClass = NSClassFromString(@"BluetoothManager");
        if ([managerClass respondsToSelector:@selector(sharedInstance)]) _bluetooth = [[managerClass sharedInstance] retain];
        _engine = [[MWWarmEngine alloc] initWithBackend:self];
        _lease = [[MWServiceLease alloc] init];
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(routeChanged:) name:AVAudioSessionRouteChangeNotification object:nil];
        [center addObserver:self selector:@selector(interruption:) name:AVAudioSessionInterruptionNotification object:nil];
        [center addObserver:self selector:@selector(reset:) name:AVAudioSessionMediaServicesWereResetNotification object:nil];
        // SpringBoard remains alive while locked; common modes cover UI tracking.
        NSTimer *timer = [NSTimer timerWithTimeInterval:2 target:self selector:@selector(evaluate) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
        [self record:@"route and service protection loaded (alpha 3)"];
        [self evaluate];
    }
    return self;
}
- (void)record:(NSString *)event {
    syslog(LOG_NOTICE, "AirPodsFix: %s", [event UTF8String]);
    [_events addObject:[NSString stringWithFormat:@"%@ %@", [NSDate date], event]];
    while ([_events count] > 64) [_events removeObjectAtIndex:0];
    NSString *folder = @"/var/mobile/Library/Logs";
    [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:NULL];
    [[[_events componentsJoinedByString:@"\n"] stringByAppendingString:@"\n"]
        writeToFile:[folder stringByAppendingPathComponent:@"AirPodsFix.log"] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}
- (void)evaluate {
    if (_evaluating) return;
    _evaluating = YES;
    @try {
        AVAudioSession *session = [AVAudioSession sharedInstance];
        NSTimeInterval now=[NSProcessInfo processInfo].systemUptime;
        MWRouteKind kind=MWOutputKind(session);
        if(kind==MWRouteA2DP) {
            id<MWLeaseDevice> selected=MWSelectedDevice(_bluetooth,session);
            if(selected!=_routeDevice) { [_routeDevice release]; _routeDevice=[selected retain]; }
        }
        BOOL connected=(_routeDevice && [_routeDevice connected]) ||
            ([_bluetooth respondsToSelector:@selector(audioConnected)] && [_bluetooth audioConnected]);
        BOOL call=[_calls.currentCalls count]!=0;
        BOOL bluetoothOn=![_bluetooth respondsToSelector:@selector(enabled)] || [_bluetooth enabled];
        if(MWLossNoticeUpdate(&_lossNotice,now,kind==MWRouteA2DP,connected,session.otherAudioPlaying,bluetoothOn,call)) {
            [self record:@"connection lost during playback; user notification requested"];
            MWShowConnectionLossNotice();
        }
        BOOL wasInterrupted=_policy.interrupted;
        BOOL allowed=MWRouteAllowed(&_policy,now,kind,connected,call,_ownsSession);
        if(wasInterrupted && !_policy.interrupted) [self record:@"recovered omitted interruption end on selected A2DP"];
        if(!_recordedState || kind!=_lastKind || call!=_lastCall || allowed!=_lastAllowed) {
            [self record:[NSString stringWithFormat:@"route state kind=%d allowed=%d call=%d target=%d",kind,allowed,call,_routeDevice!=nil]];
            _recordedState=YES; _lastKind=kind; _lastCall=call; _lastAllowed=allowed;
        }
        BOOL leaseAllowed=allowed && kind==MWRouteA2DP && !call;
        if([_lease updateAt:now device:_routeDevice eligible:leaseAllowed]) [self record:@"connected services reasserted"];
        if(!connected) { [_routeDevice release]; _routeDevice=nil; }
        [_engine updateAt:now allowed:allowed];
    } @catch (NSException *exception) {
        [_engine stop];
        [_lease updateAt:0 device:nil eligible:NO];
        [self record:@"route protection stopped after exception"];
    } @finally { _evaluating = NO; }
}
- (void)routeChanged:(NSNotification *)note {
    // Route callbacks may originate outside the main thread. All state and
    // player transitions are serialized on the main run loop.
    dispatch_async(dispatch_get_main_queue(), ^{ [self evaluate]; });
}
- (void)interruption:(NSNotification *)note {
    BOOL began = [[note.userInfo objectForKey:AVAudioSessionInterruptionTypeKey] unsignedIntegerValue] == AVAudioSessionInterruptionTypeBegan;
    dispatch_async(dispatch_get_main_queue(), ^{
        MWRouteInterruption(&_policy,began,[NSProcessInfo processInfo].systemUptime);
        if (began) {
            [_engine stop];
            [_lease updateAt:[NSProcessInfo processInfo].systemUptime device:_routeDevice eligible:NO];
        }
        else [self evaluate];
    });
}
- (void)reset:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        _ownsSession=NO;
        [_previousCategory release]; _previousCategory=nil;
        [_engine stop]; [_lease updateAt:0 device:nil eligible:NO];
        memset(&_policy,0,sizeof(_policy)); [self evaluate];
    });
}
- (BOOL)activate {
    AVAudioSession *session = [AVAudioSession sharedInstance];
    if(!_ownsSession) {
        [_previousCategory release]; _previousCategory = [session.category copy];
        _previousOptions = session.categoryOptions;
    }
    NSError *error = nil;
    if (![session setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionMixWithOthers error:&error]) {
        [self record:[NSString stringWithFormat:@"session category failed (%@:%ld)", error.domain, (long)error.code]];
        return NO;
    }
    if (![session setActive:YES error:&error]) {
        if (_previousCategory) [session setCategory:_previousCategory withOptions:_previousOptions error:NULL];
        [self record:[NSString stringWithFormat:@"session activation failed (%@:%ld)", error.domain, (long)error.code]];
        return NO;
    }
    _ownsSession = YES;
    if (!MWA2DPRoute(session)) {
        [self deactivate];
        return NO;
    }
    return YES;
}
- (BOOL)reactivate { return [self activate]; }
- (void)deactivate {
    if (!_ownsSession) return;
    _ownsSession = NO;
    AVAudioSession *session = [AVAudioSession sharedInstance];
    // Restore only a category we still own, respecting a change made elsewhere.
    if ([session.category isEqualToString:AVAudioSessionCategoryPlayback] &&
        session.categoryOptions == AVAudioSessionCategoryOptionMixWithOthers) {
        [session setActive:NO withOptions:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation error:NULL];
        if (_previousCategory) [session setCategory:_previousCategory withOptions:_previousOptions error:NULL];
    }
}
- (id<MWWarmPlayer>)startPlayer {
    NSError *error = nil;
    NSURL *url = [NSURL fileURLWithPath:@"/Library/Application Support/AirPodsFix/silence.mp3"];
    AVAudioPlayer *player = [[[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error] autorelease];
    if (!player || player.duration < 59 || ![player prepareToPlay] || ![player play]) {
        [player stop];
        [self record:[NSString stringWithFormat:@"silent audio failed (%@:%ld)", error.domain, (long)error.code]];
        return nil;
    }
    return player;
}
@end

__attribute__((constructor)) static void MWWarmInit(void) {
    @autoreleasepool {
        if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.springboard"]) return;
        char machine[32] = {0}, build[32] = {0}; size_t size = sizeof machine;
        if (sysctlbyname("hw.machine", machine, &size, NULL, 0)) return;
        size = sizeof build;
        if (sysctlbyname("kern.osversion", build, &size, NULL, 0) || strcmp(build, "10B329")) return;
        if (strcmp(machine,"iPhone4,1") && strcmp(machine,"iPhone5,1") && strcmp(machine,"iPhone5,2")) return;
        dispatch_async(dispatch_get_main_queue(), ^{
            static MWWarmService *service;
            service = [[MWWarmService alloc] init]; // process-lifetime service
            (void)service;
        });
    }
}
