// MIT. Playback policy shared by the iOS service and deterministic host tests.
#include <stdbool.h>
typedef enum { MWRouteUnknown, MWRouteA2DP, MWRouteBuiltIn, MWRouteOther } MWRouteKind;
typedef struct { bool hadA2DP, interrupted; double lastA2DP, interruptedAt; } MWRoutePolicy;
static void MWRouteInterruption(MWRoutePolicy *p,bool began,double now) { p->interrupted=began; p->interruptedAt=now; }
static bool MWRouteAllowed(MWRoutePolicy *p,double now,MWRouteKind route,bool connected,bool call,bool ownsSession) {
    if(call || route==MWRouteOther) return false;
    if(p->interrupted) {
        // iOS 6 can omit an interruption-ended notification. Recover only
        // once A2DP is selected again; never recover into HFP or a live call.
        if(route!=MWRouteA2DP || now-p->interruptedAt<2) return false;
        p->interrupted=false;
    }
    if(route==MWRouteA2DP) { p->hadA2DP=true; p->lastA2DP=now; return true; }
    if(!connected) { p->hadA2DP=false; return false; }
    // A short route-description gap must not itself tear down the warm stream.
    if(ownsSession) return p->hadA2DP && now-p->lastA2DP<=6;
    return true; // activation still verifies A2DP before creating a player
}
