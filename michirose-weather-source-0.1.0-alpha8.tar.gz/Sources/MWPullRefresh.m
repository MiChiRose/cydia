// SPDX-License-Identifier: GPL-3.0-only
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <math.h>
#import "MWWeatherEngine.h"

// Selectors verified against the stock iOS 6.1.3 Weather executable. No
// private ivar offsets and no changes to Apple's executable are required.
@interface NSObject (MWStockWeatherRefresh)
- (id)controller;
- (id)tabController;
- (id)activeCity;
- (BOOL)_isUpdating;
- (void)updateAllCities;
@end

static char MWPullKey;
static NSTimeInterval MWLastPull;
static void (*MWOriginalDidMoveToWindow)(id, SEL);

@interface MWPullRefresh : NSObject <UIGestureRecognizerDelegate> {
    UIView *_view; // The view owns this object through an associated object.
    UIPanGestureRecognizer *_pan;
    UILabel *_hint;
    BOOL _russian;
}
- (id)initWithView:(UIView *)view;
@end

@implementation MWPullRefresh
- (id)initWithView:(UIView *)view {
    if ((self = [super init])) {
        _view = view;
        _russian = [[[NSLocale preferredLanguages] objectAtIndex:0] hasPrefix:@"ru"];
        _pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(pulled:)];
        _pan.maximumNumberOfTouches = 1;
        _pan.delegate = self;
        _pan.cancelsTouchesInView = NO;
        // Only the header accepts this gesture. Let native vertical drawers
        // and horizontal city paging win everywhere else.
        for (UIView *ancestor = view; ancestor; ancestor = ancestor.superview) {
            for (UIGestureRecognizer *other in ancestor.gestureRecognizers) {
                if ([other isKindOfClass:[UIPanGestureRecognizer class]])
                    [other requireGestureRecognizerToFail:_pan];
            }
        }
        [view addGestureRecognizer:_pan];
        _hint = [[UILabel alloc] initWithFrame:CGRectMake(8, 2, view.bounds.size.width - 16, 24)];
        _hint.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        _hint.backgroundColor = [UIColor clearColor];
        _hint.textColor = [UIColor whiteColor];
        _hint.shadowColor = [UIColor colorWithWhite:0 alpha:0.6];
        _hint.shadowOffset = CGSizeMake(0, 1);
        _hint.font = [UIFont boldSystemFontOfSize:11];
        _hint.textAlignment = NSTextAlignmentCenter;
        _hint.userInteractionEnabled = NO;
        _hint.hidden = YES;
        [view addSubview:_hint];
        NSLog(@"[MiChiRoseWeather] Pull-to-refresh gesture installed.");
    }
    return self;
}
- (void)dealloc {
    _pan.delegate = nil;
    [_pan removeTarget:self action:@selector(pulled:)];
    [_pan release];
    [_hint release];
    [super dealloc];
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gesture shouldReceiveTouch:(UITouch *)touch {
    CGPoint point = [touch locationInView:_view];
    if (!_view.window || point.y < 0 || point.y > 90) return NO;
    // Do not take touches from buttons, including controls from other tweaks.
    for (UIView *hit = touch.view; hit && hit != _view; hit = hit.superview)
        if ([hit isKindOfClass:[UIControl class]]) return NO;
    return YES;
}
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gesture {
    CGPoint delta = [_pan translationInView:_view];
    return delta.y > 0 && delta.y > fabs(delta.x) * 1.5;
}
- (void)pulled:(UIPanGestureRecognizer *)gesture {
    CGFloat distance = [gesture translationInView:_view].y;
    if (gesture.state == UIGestureRecognizerStateBegan || gesture.state == UIGestureRecognizerStateChanged) {
        _hint.hidden = NO;
        _hint.text = distance >= 64 ? (_russian ? @"Отпустите для обновления" : @"Release to refresh")
            : (_russian ? @"↓ Потяните для обновления" : @"↓ Pull to refresh");
        [_view bringSubviewToFront:_hint];
        return;
    }
    _hint.hidden = YES;
    if (gesture.state != UIGestureRecognizerStateEnded || distance < 64) return;
    // A held/rapidly repeated pull must not flood the public weather service.
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    if (now - MWLastPull < 10) return;
    id application = [UIApplication sharedApplication];
    id controller = [application respondsToSelector:@selector(controller)] ? [application controller] : nil;
    id tabs = [controller respondsToSelector:@selector(tabController)] ? [controller tabController] : nil;
    id city = [tabs respondsToSelector:@selector(activeCity)] ? [tabs activeCity] : nil;
    if (![tabs respondsToSelector:@selector(updateAllCities)] || !city) return;
    if ([city respondsToSelector:@selector(_isUpdating)] && [city _isUpdating]) return;
    MWLastPull = now;
    [[MWWeatherEngine sharedEngine] invalidateForecastCache];
    NSLog(@"[MiChiRoseWeather] Manual refresh requested.");
    // Native Weather owns the progress state, location requests and result
    // labels. Never display a synthetic success when a network request fails.
    [tabs updateAllCities];
}
@end

static void MWCityDidMoveToWindow(UIView *view, SEL selector) {
    MWOriginalDidMoveToWindow(view, selector);
    if (view.window && !objc_getAssociatedObject(view, &MWPullKey)) {
        MWPullRefresh *pull = [[MWPullRefresh alloc] initWithView:view];
        objc_setAssociatedObject(view, &MWPullKey, pull, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [pull release];
    }
}

void MWInstallPullRefresh(void) {
    Class cityView = NSClassFromString(@"CityView");
    Method method = class_getInstanceMethod(cityView, @selector(didMoveToWindow));
    if (!method) return;
    MWOriginalDidMoveToWindow = (void (*)(id, SEL))method_getImplementation(method);
    // If inherited, add the override only to CityView, never to UIView itself.
    if (!class_addMethod(cityView, @selector(didMoveToWindow), (IMP)MWCityDidMoveToWindow, method_getTypeEncoding(method)))
        method_setImplementation(method, (IMP)MWCityDidMoveToWindow);
}
