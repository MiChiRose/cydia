// SPDX-License-Identifier: GPL-3.0-only
#import <Foundation/Foundation.h>

// A private HTTPS client restricted to the two fixed Open-Meteo endpoints.
NSData *MWHTTPSGet(NSString *host, NSString *path, NSDictionary *parameters,
                   NSInteger *status, NSError **error);
// Separate parser entry point for hostile/truncated response regression checks.
NSData *MWHTTPBody(NSData *wire, NSInteger *status, NSError **error);
