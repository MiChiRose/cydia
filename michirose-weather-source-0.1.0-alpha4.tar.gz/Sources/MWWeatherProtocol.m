// SPDX-License-Identifier: GPL-3.0-only
#import "MWWeatherProtocol.h"
#import "MWWeatherEngine.h"

static void MWRecordState(NSString *stage, NSString *outcome, NSError *error) {
#ifndef MW_HOST_TEST
    if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.weather"]) return;
    @synchronized([MWWeatherProtocol class]) {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSDictionary *previous = [defaults dictionaryForKey:@"MWWeatherDiagnostics"];
        NSMutableDictionary *state = previous ? [[previous mutableCopy] autorelease] : [NSMutableDictionary dictionary];
        if ([stage isEqualToString:@"load"]) {
            [state removeAllObjects];
            [state setObject:[NSDate date] forKey:@"loadedAt"];
        }
        [state setObject:stage forKey:@"stage"];
        [state setObject:outcome forKey:@"outcome"];
        [state setObject:[NSDate date] forKey:@"updatedAt"];
        if ([outcome isEqualToString:@"running"]) [state setObject:[NSNumber numberWithInteger:[[state objectForKey:@"requests"] integerValue] + 1] forKey:@"requests"];
        [state removeObjectForKey:@"errorDomain"];
        [state removeObjectForKey:@"errorCode"];
        if (error) {
            [state setObject:[error domain] forKey:@"errorDomain"];
            [state setObject:[NSNumber numberWithInteger:[error code]] forKey:@"errorCode"];
        }
        // Only our own status key is written. No city, URL or coordinates are stored.
        [defaults setObject:state forKey:@"MWWeatherDiagnostics"];
        [defaults synchronize];
    }
#endif
}

static void MWRecordCandidate(NSURLRequest *request, BOOL accepted) {
#ifndef MW_HOST_TEST
    if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.weather"]) return;
    NSString *host = [[[request URL] host] lowercaseString];
    if (![host isEqualToString:@"yahooapis.com"] && ![host hasSuffix:@".yahooapis.com"]) return;
    // Record only the request shape, never the query string, city or coordinate values.
    NSString *query = [[[[request URL] query] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding] lowercaseString];
    NSString *table = @"other";
    if (query && [query rangeOfString:@"partner.weather.locations"].location != NSNotFound) table = @"locations";
    else if (query && [query rangeOfString:@"partner.weather.forecasts"].location != NSNotFound) table = @"forecasts";
    @synchronized([MWWeatherProtocol class]) {
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSDictionary *previous = [defaults dictionaryForKey:@"MWWeatherDiagnostics"];
        NSMutableDictionary *state = previous ? [[previous mutableCopy] autorelease] : [NSMutableDictionary dictionary];
        [state setObject:[request HTTPMethod] ?: @"—" forKey:@"candidateMethod"];
        [state setObject:[[request URL] path] ?: @"—" forKey:@"candidatePath"];
        [state setObject:table forKey:@"candidateTable"];
        [state setObject:[NSNumber numberWithBool:accepted] forKey:@"candidateAccepted"];
        [defaults setObject:state forKey:@"MWWeatherDiagnostics"];
        [defaults synchronize];
    }
#endif
}

@implementation MWWeatherProtocol
+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    BOOL accepted = MWIsWeatherRequest(request);
    MWRecordCandidate(request, accepted);
    return accepted;
}
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }
- (void)startLoading {
    @synchronized(self) { if (_stopped || _operation) return; }
    NSString *stage = [MWParseQuery([[self request] URL], NULL) objectForKey:@"action"] ?: @"unparsed";
    MWRecordState(stage, @"running", nil);
    NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
        @autoreleasepool {
            NSError *error = nil;
            NSData *data = nil;
            @try { data = [[MWWeatherEngine sharedEngine] responseForRequest:[self request] error:&error]; }
            @catch (NSException *exception) {
                error = [NSError errorWithDomain:@"com.michirose.weather" code:3
                    userInfo:[NSDictionary dictionaryWithObject:@"Unexpected weather response format." forKey:NSLocalizedDescriptionKey]];
            }
            @synchronized(self) {
                [_operation release];
                _operation = nil;
                if (_stopped) return;
                if (!data) {
                    MWRecordState(stage, @"failed", error);
                    // Log the error code only; queries, cities and coordinates are not logged.
                    NSLog(@"[MiChiRoseWeather] Request failed (%@:%ld).", [error domain], (long)[error code]);
                    [[self client] URLProtocol:self didFailWithError:error ?: [NSError errorWithDomain:NSURLErrorDomain code:NSURLErrorUnknown userInfo:nil]];
                } else {
                    MWRecordState(stage, @"ok", nil);
                    NSHTTPURLResponse *response = [[[NSHTTPURLResponse alloc] initWithURL:[[self request] URL]
                        statusCode:200 HTTPVersion:@"HTTP/1.1" headerFields:[NSDictionary dictionaryWithObjectsAndKeys:
                            @"application/xml; charset=utf-8", @"Content-Type", @"no-store", @"Cache-Control", nil]] autorelease];
                    [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
                    if (!_stopped) [[self client] URLProtocol:self didLoadData:data];
                    if (!_stopped) [[self client] URLProtocolDidFinishLoading:self];
                }
            }
        }
    }];
    @synchronized(self) {
        if (_stopped) return;
        _operation = [operation retain];
    }
    static NSOperationQueue *queue = nil;
    @synchronized([MWWeatherProtocol class]) {
        if (!queue) { queue = [[NSOperationQueue alloc] init]; [queue setMaxConcurrentOperationCount:2]; }
    }
    [queue addOperation:operation];
}
- (void)stopLoading {
    @synchronized(self) { _stopped = YES; [_operation cancel]; [_operation release]; _operation = nil; }
}
- (void)dealloc { [_operation cancel]; [_operation release]; [super dealloc]; }
@end

#if !defined(MW_HOST_TEST) && !defined(MW_NO_AUTOINSTALL)
__attribute__((constructor)) static void MWInstallWeatherProtocol(void) {
    @autoreleasepool {
        // Even if the injection filter is changed, avoid altering other applications.
        if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.weather"]) return;
        BOOL registered = [NSURLProtocol registerClass:[MWWeatherProtocol class]];
        MWRecordState(@"load", registered ? @"registered" : @"registration failed", nil);
        NSLog(@"[MiChiRoseWeather] Direct Open-Meteo bridge loaded (alpha 4 diagnostics).");
    }
}
#endif
