// SPDX-License-Identifier: GPL-3.0-only
#import "MWHTTPS.h"
#import "MWWeatherEngine.h"
#include "MWTrustRoots.h"
#include <mbedtls/ssl.h>
#include <mbedtls/x509_crt.h>
#include <mbedtls/error.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netdb.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <stdlib.h>
#include <limits.h>
#include <mach/mach_time.h>

mbedtls_ms_time_t mbedtls_ms_time(void) {
    mach_timebase_info_data_t scale; mach_timebase_info(&scale);
    return (mbedtls_ms_time_t)(mach_absolute_time() * ((double)scale.numer / scale.denom) / 1000000.0);
}

static const NSUInteger MWLimit = 2 * 1024 * 1024;
static void MWHTTPError(NSError **error, NSInteger code, NSString *message) {
    if (error) *error = [NSError errorWithDomain:@"MiChiRoseHTTPS" code:code
        userInfo:[NSDictionary dictionaryWithObject:message forKey:NSLocalizedDescriptionKey]];
}

static BOOL MWDecimal(NSString *text, unsigned long long *value) {
    if (![text length]) return NO;
    unsigned long long number = 0;
    for (NSUInteger i=0; i<[text length]; i++) {
        unichar c = [text characterAtIndex:i];
        if (c<'0' || c>'9' || number > (ULLONG_MAX - (c-'0')) / 10) return NO;
        number = number * 10 + c-'0';
    }
    *value = number; return YES;
}

NSData *MWHTTPBody(NSData *wire, NSInteger *status, NSError **error) {
    if (status) *status = 0;
    if ([wire length] > MWLimit + 65536) goto malformed;
    NSRange boundary = [wire rangeOfData:[@"\r\n\r\n" dataUsingEncoding:NSASCIIStringEncoding]
        options:0 range:NSMakeRange(0, MIN([wire length], (NSUInteger)32768))];
    if (boundary.location == NSNotFound) goto malformed;
    NSString *head = [[[NSString alloc] initWithData:[wire subdataWithRange:NSMakeRange(0,boundary.location)]
        encoding:NSASCIIStringEncoding] autorelease];
    NSArray *lines = [head componentsSeparatedByString:@"\r\n"];
    if (![lines count]) goto malformed;
    NSArray *first = [[lines objectAtIndex:0] componentsSeparatedByString:@" "];
    if ([first count] < 2 || (![[first objectAtIndex:0] isEqualToString:@"HTTP/1.1"] &&
        ![[first objectAtIndex:0] isEqualToString:@"HTTP/1.0"])) goto malformed;
    unsigned long long code;
    if ([[first objectAtIndex:1] length] != 3 || !MWDecimal([first objectAtIndex:1], &code) || code < 100 || code > 599) goto malformed;
    if (status) *status = (NSInteger)code;
    NSMutableDictionary *headers = [NSMutableDictionary dictionary];
    for (NSUInteger i=1; i<[lines count]; i++) {
        NSString *line = [lines objectAtIndex:i]; NSRange colon = [line rangeOfString:@":"];
        if (colon.location == NSNotFound || colon.location == 0) goto malformed;
        NSString *key = [[line substringToIndex:colon.location] lowercaseString];
        NSString *value = [[line substringFromIndex:colon.location+1]
            stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if ([headers objectForKey:key]) goto malformed;
        [headers setObject:value forKey:key];
    }
    NSString *encoding = [[headers objectForKey:@"content-encoding"] lowercaseString];
    if (encoding && ![encoding isEqualToString:@"identity"]) goto malformed;
    NSUInteger start = boundary.location + 4;
    NSData *body = [wire subdataWithRange:NSMakeRange(start, [wire length]-start)];
    NSString *transfer = [[headers objectForKey:@"transfer-encoding"] lowercaseString];
    NSString *length = [headers objectForKey:@"content-length"];
    if (transfer) {
        if (length || ![transfer isEqualToString:@"chunked"]) goto malformed;
        NSMutableData *decoded = [NSMutableData data];
        NSUInteger cursor = 0;
        const unsigned char *bytes = [body bytes];
        while (cursor < [body length]) {
            NSUInteger end=cursor;
            while (end+1<[body length] && !(bytes[end]=='\r' && bytes[end+1]=='\n')) end++;
            if (end+1 >= [body length] || end==cursor || end-cursor>16) goto malformed;
            NSUInteger chunk=0;
            for (NSUInteger i=cursor; i<end; i++) {
                unsigned c=bytes[i], digit;
                if (c>='0' && c<='9') digit=c-'0';
                else if (c>='a' && c<='f') digit=c-'a'+10;
                else if (c>='A' && c<='F') digit=c-'A'+10;
                else goto malformed; // Extensions are not requested or needed.
                if (chunk > (MWLimit-digit)/16) goto malformed;
                chunk=chunk*16+digit;
            }
            cursor=end+2;
            if (!chunk) {
                // No trailers are requested. Reject ambiguous extra bytes.
                if ([body length]-cursor != 2 || bytes[cursor]!='\r' || bytes[cursor+1]!='\n') goto malformed;
                return decoded;
            }
            if (chunk > MWLimit-[decoded length] || chunk > [body length]-cursor || [body length]-cursor-chunk<2) goto malformed;
            [decoded appendBytes:bytes+cursor length:chunk]; cursor+=chunk;
            if (bytes[cursor]!='\r' || bytes[cursor+1]!='\n') goto malformed;
            cursor+=2;
        }
        goto malformed;
    }
    unsigned long long expected;
    if ([body length] > MWLimit || !length || !MWDecimal(length,&expected) || expected != [body length]) goto malformed;
    return body;
malformed:
    MWHTTPError(error, 1, @"Incomplete, oversized or unsupported HTTP response."); return nil;
}

typedef struct { int fd; CFAbsoluteTime deadline; } MWSocket;
static int MWWait(MWSocket *socket, BOOL writing) {
    for (;;) {
        double remaining=socket->deadline-CFAbsoluteTimeGetCurrent();
        if (remaining<=0) return MBEDTLS_ERR_SSL_TIMEOUT;
        fd_set set; FD_ZERO(&set); FD_SET(socket->fd,&set);
        struct timeval timeout={(time_t)remaining, (suseconds_t)((remaining-(time_t)remaining)*1000000)};
        int result=select(socket->fd+1,writing?NULL:&set,writing?&set:NULL,NULL,&timeout);
        if (result>0) return 0;
        if (!result) return MBEDTLS_ERR_SSL_TIMEOUT;
        if (errno!=EINTR) return MBEDTLS_ERR_SSL_INTERNAL_ERROR;
    }
}
static int MWSend(void *context, const unsigned char *data, size_t size) {
    MWSocket *socket=context;
    for (;;) {
        int result=MWWait(socket,YES); if (result) return result;
        ssize_t count=send(socket->fd,data,size,0);
        if (count>=0) return (int)count;
        if (errno!=EINTR && errno!=EAGAIN && errno!=EWOULDBLOCK) return MBEDTLS_ERR_SSL_INTERNAL_ERROR;
    }
}
static int MWReceive(void *context, unsigned char *data, size_t size) {
    MWSocket *socket=context;
    for (;;) {
        int result=MWWait(socket,NO); if (result) return result;
        ssize_t count=recv(socket->fd,data,size,0);
        if (count>=0) return (int)count;
        if (errno!=EINTR && errno!=EAGAIN && errno!=EWOULDBLOCK) return MBEDTLS_ERR_SSL_INTERNAL_ERROR;
    }
}
static int MWRandom(void *context, unsigned char *data, size_t size) {
    arc4random_buf(data,size); return 0;
}

NSData *MWHTTPSGet(NSString *host, NSString *path, NSDictionary *parameters, NSInteger *status, NSError **error) {
    if (status) *status=0;
    BOOL forecast=[host isEqualToString:@"api.open-meteo.com"] && [path isEqualToString:@"/v1/forecast"];
    BOOL search=[host isEqualToString:@"geocoding-api.open-meteo.com"] && [path isEqualToString:@"/v1/search"];
    BOOL place=[host isEqualToString:@"geocoding-api.open-meteo.com"] && [path isEqualToString:@"/v1/get"];
    if (!forecast && !search && !place) { MWHTTPError(error,2,@"Unexpected weather endpoint."); return nil; }
    NSData *result=nil;
    mbedtls_ssl_context tls; mbedtls_ssl_config config; mbedtls_x509_crt roots;
    mbedtls_ssl_init(&tls); mbedtls_ssl_config_init(&config); mbedtls_x509_crt_init(&roots);
    MWSocket channel={-1,CFAbsoluteTimeGetCurrent()+20};
    struct addrinfo hints, *addresses=NULL; memset(&hints,0,sizeof(hints));
    hints.ai_socktype=SOCK_STREAM; hints.ai_family=AF_UNSPEC;
    int failure=0;
    if (getaddrinfo([host UTF8String],"443",&hints,&addresses)!=0) {
        MWHTTPError(error,3,@"Weather server DNS lookup failed."); goto cleanup;
    }
    for (struct addrinfo *address=addresses; address; address=address->ai_next) {
        channel.fd=socket(address->ai_family,address->ai_socktype,address->ai_protocol);
        if (channel.fd<0) continue;
        if (channel.fd>=FD_SETSIZE) { close(channel.fd); channel.fd=-1; continue; }
        int one=1; setsockopt(channel.fd,SOL_SOCKET,SO_NOSIGPIPE,&one,sizeof(one));
        int flags=fcntl(channel.fd,F_GETFL,0);
        if (flags<0 || fcntl(channel.fd,F_SETFL,flags|O_NONBLOCK)<0) goto next;
        if (connect(channel.fd,address->ai_addr,address->ai_addrlen)==0) break;
        if (errno==EINPROGRESS && MWWait(&channel,YES)==0) {
            int value=0; socklen_t size=sizeof(value);
            if (getsockopt(channel.fd,SOL_SOCKET,SO_ERROR,&value,&size)==0 && !value) break;
        }
next:
        close(channel.fd); channel.fd=-1;
    }
    if (channel.fd<0) { MWHTTPError(error,4,@"Weather server connection failed or timed out."); goto cleanup; }
    failure=mbedtls_x509_crt_parse(&roots,(const unsigned char *)MWTrustRoots,sizeof(MWTrustRoots));
    if (failure) goto tls_error;
    failure=mbedtls_ssl_config_defaults(&config,MBEDTLS_SSL_IS_CLIENT,MBEDTLS_SSL_TRANSPORT_STREAM,MBEDTLS_SSL_PRESET_DEFAULT);
    if (failure) goto tls_error;
    mbedtls_ssl_conf_authmode(&config,MBEDTLS_SSL_VERIFY_REQUIRED);
    mbedtls_ssl_conf_ca_chain(&config,&roots,NULL);
    mbedtls_ssl_conf_rng(&config,MWRandom,NULL);
    mbedtls_ssl_conf_min_tls_version(&config,MBEDTLS_SSL_VERSION_TLS1_2);
    mbedtls_ssl_conf_max_tls_version(&config,MBEDTLS_SSL_VERSION_TLS1_2);
    failure=mbedtls_ssl_setup(&tls,&config); if (failure) goto tls_error;
    failure=mbedtls_ssl_set_hostname(&tls,[host UTF8String]); if (failure) goto tls_error;
    mbedtls_ssl_set_bio(&tls,&channel,MWSend,MWReceive,NULL);
    do { failure=mbedtls_ssl_handshake(&tls); } while (failure==MBEDTLS_ERR_SSL_WANT_READ || failure==MBEDTLS_ERR_SSL_WANT_WRITE);
    if (failure) goto tls_error;
    if (mbedtls_ssl_get_verify_result(&tls)) { failure=MBEDTLS_ERR_X509_CERT_VERIFY_FAILED; goto tls_error; }
    NSString *request=[NSString stringWithFormat:@"GET %@?%@ HTTP/1.1\r\nHost: %@\r\nUser-Agent: MiChiRoseWeather/0.1\r\nAccept: application/json\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n",path,MWEncodeQuery(parameters),host];
    NSData *requestData=[request dataUsingEncoding:NSUTF8StringEncoding];
    if ([requestData length]>16384) { MWHTTPError(error,5,@"Weather request too large."); goto cleanup; }
    for (NSUInteger sent=0; sent<[requestData length];) {
        failure=mbedtls_ssl_write(&tls,(const unsigned char *)[requestData bytes]+sent,[requestData length]-sent);
        if (failure<=0) goto tls_error;
        sent+=(NSUInteger)failure;
    }
    NSMutableData *wire=[NSMutableData data];
    for (;;) {
        unsigned char buffer[8192]; failure=mbedtls_ssl_read(&tls,buffer,sizeof(buffer));
        if (failure==MBEDTLS_ERR_SSL_PEER_CLOSE_NOTIFY) break;
        if (failure<=0) {
            // A valid TLS close-notify is required; do not accept a truncated stream.
            if (!failure) failure=MBEDTLS_ERR_SSL_CONN_EOF;
            goto tls_error;
        }
        if ([wire length]+(NSUInteger)failure>MWLimit+65536) { MWHTTPError(error,6,@"Weather response too large."); goto cleanup; }
        [wire appendBytes:buffer length:(NSUInteger)failure];
    }
    result=MWHTTPBody(wire,status,error); goto cleanup;
tls_error: {
        char message[180]; mbedtls_strerror(failure,message,sizeof(message));
        MWHTTPError(error,failure,[NSString stringWithFormat:@"TLS: %s (verify 0x%08x)",message,(unsigned)mbedtls_ssl_get_verify_result(&tls)]);
    }
cleanup:
    if (addresses) freeaddrinfo(addresses);
    if (channel.fd>=0) close(channel.fd);
    mbedtls_ssl_free(&tls); mbedtls_ssl_config_free(&config); mbedtls_x509_crt_free(&roots);
    return result;
}
