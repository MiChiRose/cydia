// SPDX-License-Identifier: GPL-3.0-only
#import "MWDiagnostics.h"
#import "MWWeatherEngine.h"
#import "MWWeatherProtocol.h"
#import "MWHTTPS.h"
#include <spawn.h>
#include <sys/wait.h>
#include <sys/select.h>
#include <unistd.h>
#include <signal.h>

NSString *MWErrorSummary(NSError *error) {
    if (!error) return @"неизвестная ошибка";
    NSString *hint = @"";
    if ([[error domain] isEqualToString:NSURLErrorDomain]) {
        switch ([error code]) {
            case -1200: hint = @" — сбой TLS-соединения"; break;
            case -1201: case -1202: case -1203: case -1204: hint = @" — сертификат или дата устройства"; break;
            case -1001: hint = @" — превышено время ожидания"; break;
            case -1003: hint = @" — имя сервера не найдено"; break;
            case -1009: hint = @" — нет подключения к интернету"; break;
        }
    }
    if ([[error domain] isEqualToString:@"MiChiRoseHTTPS"]) hint = [@" — " stringByAppendingString:[error localizedDescription]];
    return [NSString stringWithFormat:@"%@:%ld%@", [error domain], (long)[error code], hint];
}

NSString *MWWeatherRuntimeSummary(void) {
    CFPreferencesAppSynchronize(CFSTR("com.apple.weather"));
    id value = [(id)CFPreferencesCopyAppValue(CFSTR("MWWeatherDiagnostics"), CFSTR("com.apple.weather")) autorelease];
    if (![value isKindOfClass:[NSDictionary class]]) return @"Статус штатной Weather недоступен. Откройте её, выполните поиск города и повторите проверку. Это ещё не доказывает отсутствие загрузки твика.";
    NSMutableString *text = [NSMutableString stringWithFormat:@"Weather: загрузка %@\nПоследнее действие: %@ / %@\nЧисло запросов: %@",
        [value objectForKey:@"loadedAt"] ?: @"нет записи", [value objectForKey:@"stage"] ?: @"—",
        [value objectForKey:@"outcome"] ?: @"—", [value objectForKey:@"requests"] ?: @0];
    if ([value objectForKey:@"errorDomain"]) [text appendFormat:@"\nОшибка Weather: %@:%@", [value objectForKey:@"errorDomain"], [value objectForKey:@"errorCode"]];
    if ([value objectForKey:@"candidatePath"]) [text appendFormat:@"\nЗапрос: %@ %@\nТаблица: %@, перехват: %@",
        [value objectForKey:@"candidateMethod"], [value objectForKey:@"candidatePath"],
        [value objectForKey:@"candidateTable"], [[value objectForKey:@"candidateAccepted"] boolValue] ? @"да" : @"нет"];
    return text;
}

static NSString *MWLoadSummary(void) {
#ifdef MW_HOST_TEST
    return @"Проверка загрузчика iOS выполняется только на телефоне.";
#else
    int descriptors[2];
    if (pipe(descriptors) != 0) return @"LOAD: не удалось создать канал диагностики.";
    posix_spawn_file_actions_t actions;
    posix_spawn_file_actions_init(&actions);
    posix_spawn_file_actions_adddup2(&actions, descriptors[1], STDOUT_FILENO);
    posix_spawn_file_actions_adddup2(&actions, descriptors[1], STDERR_FILENO);
    posix_spawn_file_actions_addclose(&actions, descriptors[0]);
    posix_spawn_file_actions_addclose(&actions, descriptors[1]);
    char *argv[] = {"/usr/bin/michirose-weather-loadcheck", NULL};
    char *env[] = {"PATH=/usr/bin:/bin:/usr/sbin:/sbin", NULL};
    pid_t pid = 0;
    int result = posix_spawn(&pid, argv[0], &actions, NULL, argv, env);
    posix_spawn_file_actions_destroy(&actions);
    close(descriptors[1]);
    if (result != 0) { close(descriptors[0]); return [NSString stringWithFormat:@"LOAD: запуск проверки недоступен (errno %d).", result]; }
    NSMutableData *output = [NSMutableData data];
    NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:5];
    BOOL finished = NO;
    while ([deadline timeIntervalSinceNow] > 0 && [output length] < 8192) {
        fd_set readable; FD_ZERO(&readable); FD_SET(descriptors[0], &readable);
        struct timeval timeout = {0, 200000};
        if (select(descriptors[0] + 1, &readable, NULL, NULL, &timeout) <= 0) continue;
        char buffer[1024]; ssize_t count = read(descriptors[0], buffer, sizeof(buffer));
        if (count <= 0) { finished = YES; break; }
        [output appendBytes:buffer length:(NSUInteger)count];
    }
    close(descriptors[0]);
    if (!finished) kill(pid, SIGTERM);
    int status = 0;
    waitpid(pid, &status, 0);
    NSString *text = [[[NSString alloc] initWithData:output encoding:NSUTF8StringEncoding] autorelease];
    return [text length] ? text : [NSString stringWithFormat:@"LOAD: процесс завершился без отчёта (status %d).", status];
#endif
}

static NSDictionary *MWFetchDiagnosticJSON(NSString *host, NSString *path, NSDictionary *params, NSMutableString *report) {
    NSError *error = nil; NSInteger status = 0;
    NSData *data = MWHTTPSGet(host,path,params,&status,&error);
    if (!data) { [report appendFormat:@"%@\n%@\n", host, MWErrorSummary(error)]; return nil; }
    [report appendFormat:@"%@: HTTP %ld\n", host, (long)status];
    if (status != 200 || [data length] > 2 * 1024 * 1024) return nil;
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    if (![json isKindOfClass:[NSDictionary class]] || [[json objectForKey:@"error"] boolValue]) {
        [report appendFormat:@"Ответ не является корректным JSON прогноза (%@).\n", MWErrorSummary(error)]; return nil;
    }
    return json;
}

@interface MWDiagnosticParser : NSObject <NSXMLParserDelegate> {
    NSString *_identifier;
    NSUInteger _days, _hours;
}
@property(nonatomic, readonly) NSString *identifier;
@property(nonatomic, readonly) NSUInteger days;
@property(nonatomic, readonly) NSUInteger hours;
@end
@implementation MWDiagnosticParser
@synthesize identifier = _identifier, days = _days, hours = _hours;
- (void)dealloc { [_identifier release]; [super dealloc]; }
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)element namespaceURI:(NSString *)uri qualifiedName:(NSString *)qualified attributes:(NSDictionary *)attrs {
    if ([element isEqualToString:@"location"] && !_identifier) _identifier = [[attrs objectForKey:@"woeid"] copy];
    if ([element isEqualToString:@"day"]) _days++;
    if ([element isEqualToString:@"hour"]) _hours++;
}
@end

static MWDiagnosticParser *MWReadXML(NSData *data) {
    if (!data) return nil;
    MWDiagnosticParser *capture = [[[MWDiagnosticParser alloc] init] autorelease];
    NSXMLParser *parser = [[[NSXMLParser alloc] initWithData:data] autorelease];
    [parser setDelegate:capture];
    return [parser parse] ? capture : nil;
}

static NSURLRequest *MWDiagnosticRequest(NSString *query) {
    NSString *url = [@"https://apple-mobile.query.yahooapis.com/v1/yql?" stringByAppendingString:
        MWEncodeQuery([NSDictionary dictionaryWithObjectsAndKeys:query, @"q", @"xml", @"format", nil])];
    return [NSURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:45];
}

NSString *MWRunWeatherDiagnostics(NSString *city) {
    NSMutableString *report = [NSMutableString stringWithFormat:@"MiChiRose Weather — Alpha 4\nДата: %@\niOS: %@\n\n",
        [NSDate date], [[NSProcessInfo processInfo] operatingSystemVersionString]];
    [report appendFormat:@"%@\n\n%@\n\n", MWLoadSummary(), MWWeatherRuntimeSummary()];
    city = [city stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (![city length] || [city length] > 120 || [city rangeOfCharacterFromSet:[NSCharacterSet characterSetWithCharactersInString:@"\"'\n\r"]].location != NSNotFound) {
        [report appendString:@"Для теста введите простое название города, например Minsk.\n"]; return report;
    }
    [report appendString:@"1. Прямой HTTPS и поиск города\n"];
    NSDictionary *search = MWFetchDiagnosticJSON(@"geocoding-api.open-meteo.com", @"/v1/search",
        [NSDictionary dictionaryWithObjectsAndKeys:city, @"name", @1, @"count", @"en", @"language", nil], report);
    id places = [search objectForKey:@"results"];
    NSDictionary *place = [places isKindOfClass:[NSArray class]] && [places count] ? [places objectAtIndex:0] : nil;
    if (!place) { [report appendString:@"Поиск через HTTPS не дал города. Геолокация для этой проверки не использовалась.\n"]; return report; }
    [report appendString:@"Поиск: OK\n\n2. Прямой HTTPS и прогноз\n"];
    NSDictionary *forecast = MWFetchDiagnosticJSON(@"api.open-meteo.com", @"/v1/forecast",
        [NSDictionary dictionaryWithObjectsAndKeys:[place objectForKey:@"latitude"], @"latitude",
            [place objectForKey:@"longitude"], @"longitude", @"temperature_2m", @"current", nil], report);
    if (![[forecast objectForKey:@"current"] isKindOfClass:[NSDictionary class]]) {
        [report appendString:@"Получение прогноза не прошло. Геолокация для этого не нужна.\n"]; return report;
    }
    [report appendString:@"Прогноз API: OK\n\n3. Преобразование через твик\n"];
    [NSURLProtocol registerClass:[MWWeatherProtocol class]];
    NSError *error = nil; NSURLResponse *response = nil;
    NSString *q = [NSString stringWithFormat:@"select * from partner.weather.locations where query=\"%@\" and lang='en-US'", city];
    NSData *data = [NSURLConnection sendSynchronousRequest:MWDiagnosticRequest(q) returningResponse:&response error:&error];
    MWDiagnosticParser *parsed = MWReadXML(data);
    if (![[parsed identifier] length]) {
        [report appendFormat:@"Поиск в формате Weather: FAIL %@\n", MWErrorSummary(error)]; return report;
    }
    q = [NSString stringWithFormat:@"select * from yql.query.multi where queries='select * from partner.weather.forecasts where woeid=%@ and lang=\"en-US\"; select * from partner.weather.forecasts where woeid=%@ and lang=\"en-US\"'", [parsed identifier], [parsed identifier]];
    error = nil;
    data = [NSURLConnection sendSynchronousRequest:MWDiagnosticRequest(q) returningResponse:&response error:&error];
    parsed = MWReadXML(data);
    if (![parsed days] || ![parsed hours]) [report appendFormat:@"Прогноз в формате Weather: FAIL %@\n", MWErrorSummary(error)];
    else [report appendFormat:@"Цепочка в диагностике: OK (%lu дней, %lu часов).\nЕсли штатный поиск пустой, проверяем внедрение или формат реального запроса Weather.\n", (unsigned long)[parsed days], (unsigned long)[parsed hours]];
    [report appendString:@"\nГеопозиция телефона для погодной проверки не запрашивается. Запрашивается только погода для введённого города.\n"];
    return report;
}
