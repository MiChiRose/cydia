#!/usr/bin/env python3
"""Inspect the actual Mach-O header/load commands, not compiler arguments."""
import struct
import sys
import hashlib
import subprocess
import re
from pathlib import Path

for name in sys.argv[1:]:
    data = Path(name).read_bytes()
    magic, cpu, subtype, kind, count, size, flags = struct.unpack_from('<7I', data)
    assert magic == 0xFEEDFACE and cpu == 12 and (subtype & 0xFFFFFF) == 9, name
    cursor = 28
    minimum = signature = False
    sections = set()
    for _ in range(count):
        command, length = struct.unpack_from('<2I', data, cursor)
        assert length >= 8 and cursor + length <= 28 + size
        assert command not in (0x80000034, 0x80000033, 0x32), 'modern dyld commands are incompatible with iOS 6'
        if command == 1:  # LC_SEGMENT, 32-bit section table
            number = struct.unpack_from('<I', data, cursor + 48)[0]
            for index in range(number):
                section = data[cursor + 56 + 68 * index:cursor + 72 + 68 * index].split(b'\0', 1)[0].decode()
                sections.add(section)
            assert '__picsymbolstub5' not in sections, 'modern ARM stubs are incompatible with iOS 6 dyld'
        if command == 0x25:
            version, sdk = struct.unpack_from('<2I', data, cursor + 8)
            assert version == 0x60000, (name, version)
            minimum = True
        if command == 0x1D:
            offset, size_ = struct.unpack_from('<2I', data, cursor + 8)
            assert offset > 0 and size_ > 0 and offset + size_ <= len(data)
            magic_, length_, entries = struct.unpack_from('>3I', data, offset)
            assert magic_ == 0xFADE0CC0
            for index in range(entries):
                slot, relative = struct.unpack_from('>2I', data, offset + 12 + 8 * index)
                if slot != 0:
                    continue
                directory = offset + relative
                magic_cd, length_cd, version_cd, flags_cd, hash_offset, ident, specials, pages, limit = struct.unpack_from('>9I', data, directory)
                hash_size, hash_type, platform, page_power = struct.unpack_from('>4B', data, directory + 36)
                assert magic_cd == 0xFADE0C02 and hash_type == 1 and hash_size == 20
                page_size = 1 << page_power
                for page in range(pages):
                    actual = hashlib.sha1(data[page * page_size:min((page + 1) * page_size, limit)]).digest()
                    start = directory + hash_offset + page * hash_size
                    assert actual == data[start:start + hash_size], 'code signature page hash mismatch'
                signature = True
        cursor += length
    assert minimum and signature, name
    classic_pic = '__picsymbolstub4' in sections and '__la_symbol_ptr' in sections
    classic_import = '__symbolstub1' in sections and '__lazy_symbol' in sections
    assert classic_pic or classic_import, 'expected classic ARMv7 lazy stubs'
    imports = subprocess.check_output(['nm', '-m', '-u', name], text=True)
    for line in imports.splitlines():
        if re.search(r'_OBJC_(?:META)?CLASS_\$_(?:NSHTTPURLResponse|NSMutableURLRequest|NSURLConnection|NSURLProtocol|NSURLRequest)\b', line):
            assert '(from Foundation)' in line, f'iOS 6 network class bound to the wrong framework: {line}'
    print(f'ARMv7 / classic stubs / iOS 6 Foundation imports / SHA1 page hashes: {Path(name).name}')
