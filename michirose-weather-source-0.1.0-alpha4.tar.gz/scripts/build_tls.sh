#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$1"
mkdir -p "$OUT"
python3 - "$ROOT" "$OUT" <<'PY'
import hashlib,json,sys,tarfile
from pathlib import Path
root,out=map(Path,sys.argv[1:])
archive=root/'Vendor/mbedtls-3.6.7.tar.bz2'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == 'a7e8bcbec0e6f761b4af24f25677626b35f762f68eef79c08677a363212d11f6'
if not (out/'mbedtls-3.6.7').exists():
    with tarfile.open(archive) as tf:
        for m in tf:
            assert not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
            assert m.isfile() or m.isdir(), 'Unexpected archive entry type'
        tf.extractall(out)
roots=''.join((root/'Resources'/name).read_text() for name in ['isrgrootx1.pem','isrgrootx2.pem'])
(out/'MWTrustRoots.h').write_text('/* Public ISRG trust anchors, local to weather HTTPS. */\nstatic const char MWTrustRoots[] =\n'+''.join(json.dumps(line+'\n')+'\n' for line in roots.splitlines())+';\n')
PY
SRC="$OUT/mbedtls-3.6.7"
# Use the supported upstream configuration, disabling protocols not used here.
cp "$SRC/include/mbedtls/mbedtls_config.h" "$OUT/mw_mbedtls_config.h"
cat >> "$OUT/mw_mbedtls_config.h" <<'CONFIG'
#undef MBEDTLS_SSL_PROTO_TLS1_3
#undef MBEDTLS_SSL_PROTO_DTLS
#undef MBEDTLS_SSL_DTLS_HELLO_VERIFY
#undef MBEDTLS_SSL_DTLS_ANTI_REPLAY
#undef MBEDTLS_SSL_DTLS_CONNECTION_ID
#undef MBEDTLS_SSL_DTLS_CLIENT_PORT_REUSE
#undef MBEDTLS_SSL_DTLS_SRTP
#define MBEDTLS_PLATFORM_MS_TIME_ALT
CONFIG
python3 - "$SRC/library" "$OUT/mw_mbedtls_config.h" "${MW_TLS_CC:-clang}" "${MW_TLS_FLAGS:-}" <<'PY'
import hashlib,sys
from pathlib import Path
library,config=map(Path,sys.argv[1:3])
key=hashlib.sha256(config.read_bytes()+'\n'.join(sys.argv[3:]).encode()).hexdigest()
stamp=library/'.michirose-build-config'
if not stamp.exists() or stamp.read_text()!=key:
    for pattern in ('*.o','*.a','*.d'):
        for p in library.glob(pattern):
            p.unlink()
    stamp.write_text(key)
PY
make -C "$SRC/library" -j6 CC="${MW_TLS_CC:-clang}" AR="${MW_TLS_AR:-ar}" \
  CFLAGS="${MW_TLS_FLAGS:-} -Os -fvisibility=hidden -I$OUT -DMBEDTLS_CONFIG_FILE=\\\"mw_mbedtls_config.h\\\"" static
