# Sources and attribution

MiChiRose Weather is an independent compatibility implementation by MiChiRose.

- Yahoo XML response field layout was researched from
  [TestOrig/YQL-X-Server-New](https://github.com/TestOrig/YQL-X-Server-New),
  revision `f236e98a3f4a4d4f855933ca5ad4decae78eeb83`, by Electimon and
  ObscureMosquito. The project is GPL-3.0; this project is also GPL-3.0-only.
- The original-host interception approach was researched from
  [Notdbrand/NDBWeather](https://github.com/Notdbrand/NDBWeather). No NDBWeather
  source code or binary is included.
- Weather data: [Open-Meteo](https://open-meteo.com/),
  [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).
  The adapter rounds temperatures, translates WMO condition codes into Yahoo
  condition codes, and converts responses to XML; these changes are ours.
- City names and locations: [GeoNames](https://www.geonames.org/) through
  [Open-Meteo Geocoding](https://open-meteo.com/en/docs/geocoding-api),
  [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/).

The free Open-Meteo service is for noncommercial use and subject to its
[usage limits](https://open-meteo.com/en/terms). No API key is bundled.
This alpha is intended for personal testing, not a commercial weather service.

Build tools are not redistributed: Apple iPhoneOS 6.1 SDK (archive SHA-256
`2696df17fc48e1b6ea3f7acd346b5f2356fb5c6cc60b0f3aaca0c24522d761de`),
[cctools-port](https://github.com/tpoechtrager/cctools-port) revision
`904de2a71d4da6a9b30d2efaf912a10ddc7d9ddb` (classic ld64), and Procursus ldid
`v2.1.5-procursus7`. SDK 9.3 imports are incompatible with iOS 6 here.

The private HTTPS transport statically links
[Mbed TLS 3.6.7](https://github.com/Mbed-TLS/mbedtls/releases/tag/mbedtls-3.6.7),
used under Apache-2.0, compatible with this project's GPL-3.0-only license.
Its unmodified official source archive and published SHA-256 are included in
Vendor and in the corresponding source archive. The upstream license and
notice are also installed with the package. No device-wide TLS hooks are used.
TLS 1.3/DTLS are disabled. The monotonic millisecond clock uses Apple's
mach_absolute_time; secure randomness uses arc4random_buf.

The public ISRG Root X1 and X2 certificates come from
[Let's Encrypt](https://letsencrypt.org/certificates/). They are embedded only
in this fixed-provider client, with required chain, validity and hostname
verification. They do not change the device trust store. OCSP/CRL checking is
not implemented in this alpha; CA changes require a package update.
