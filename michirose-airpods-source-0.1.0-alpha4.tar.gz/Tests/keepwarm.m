// MIT. Exercise the production renewal/stop/retry state machine without audio hardware.
#import <Foundation/Foundation.h>
#import "KeepWarmEngine.h"
#include "RoutePolicy.h"
#import "ServiceLease.h"
#import "DeviceSelection.h"
#include "LossNotice.h"
#import "RouteRefresh.h"
#include <assert.h>
static double clockNow;
@interface TestRoutes : NSObject <MWMediaRouteController> {
@public NSDictionary *selected; unsigned picks, clears; BOOL reject;
}
@end
@implementation TestRoutes
- (void)clearCachedRoutes { clears++; }
- (NSDictionary *)pickedRouteDescription { return selected; }
- (BOOL)_pickRoute:(NSDictionary *)route { assert(route==selected); picks++; return !reject; }
@end
static void RouteRefreshTest(void) {
    TestRoutes *routes=[[[TestRoutes alloc] init] autorelease];
    MWRouteRefresh *refresh=[[[MWRouteRefresh alloc] initWithController:routes a2dpPortType:@"BluetoothA2DPOutput"] autorelease];
    assert([refresh refreshAt:0]==MWRefreshNotA2DP && !routes->picks);
    for(NSString *type in @[@"Speaker",@"Receiver",@"BluetoothHFP",@"Headphones",@"AirTunes"]) {
        routes->selected=@{@"AVAudioRouteName":type};
        assert(!refresh.selectedA2DP && [refresh refreshAt:0]==MWRefreshNotA2DP && !routes->picks);
    }
    routes->selected=@{@"AVAudioRouteName":@"BluetoothA2DPOutput"};
    assert(refresh.selectedA2DP && [refresh refreshAt:0]==MWRefreshAccepted && routes->picks==1);
    assert([refresh refreshAt:1]==MWRefreshCooldown && routes->picks==1);
    // Intervening manual output selection must win over queued track events.
    routes->selected=@{@"AVAudioRouteName":@"Speaker"};
    assert([refresh refreshAt:2]==MWRefreshNotA2DP && routes->picks==1);
    routes->selected=@{@"AVAudioRouteName":@"BluetoothA2DP"}; routes->reject=YES;
    assert([refresh refreshAt:2]==MWRefreshRejected && routes->picks==2);
    assert([refresh refreshAt:3]==MWRefreshCooldown && routes->picks==2);
    routes->reject=NO;
    for(int i=0;i<100;i++) assert([refresh refreshAt:4+i*2]==MWRefreshAccepted);
    assert(routes->picks==102);
    MWRouteRefresh *unsupported=[[[MWRouteRefresh alloc] initWithController:nil a2dpPortType:@"BluetoothA2DP"] autorelease];
    assert([unsupported refreshAt:0]==MWRefreshUnavailable);
}
@interface TestPlayer : NSObject <MWWarmPlayer> { @public double started, delay; BOOL stopped; }
@end
@implementation TestPlayer
- (BOOL)isPlaying { return !stopped && clockNow >= started + delay && clockNow < started + 60; }
- (void)stop { stopped = YES; }
@end
@interface TestAudio : NSObject <MWWarmBackend> {
@public NSMutableArray *created; BOOL failActivation, failPlayer, active; unsigned starts, activations, deactivations, reactivations, confirmations, timeouts; double latency;
}
@end
@implementation TestAudio
- (id)init { if ((self=[super init])) created=[[NSMutableArray alloc] init]; return self; }
- (void)dealloc { [created release]; [super dealloc]; }
- (BOOL)activate { activations++; active=!failActivation; return active; }
- (BOOL)reactivate { reactivations++; return [self activate]; }
- (void)deactivate { deactivations++; active=NO; }
- (id<MWWarmPlayer>)startPlayer {
    starts++; if(failPlayer) return nil;
    TestPlayer *p=[[[TestPlayer alloc] init] autorelease]; p->started=clockNow; p->delay=latency; [created addObject:p]; return p;
}
- (void)record:(NSString *)event { }
- (void)confirmedPlaying { confirmations++; }
- (void)playerStartTimedOut { timeouts++; }
- (NSUInteger)playing {
    NSUInteger n=0; for(TestPlayer *p in created) if(p.isPlaying)n++; return n;
}
@end
static void Tick(MWWarmEngine *engine,double time,BOOL allowed) { clockNow=time; [engine updateAt:time allowed:allowed]; }
@interface TestDevice : NSObject <MWLeaseDevice,MWConnectedAudioDevice> { @public BOOL linked; unsigned services, renewals; NSString *addressValue,*nameValue; }
@end
@implementation TestDevice
- (BOOL)connected { return linked; }
- (unsigned)connectedServices { return services; }
- (unsigned)majorClass { return 0x400; }
- (NSString *)address { return addressValue; }
- (NSString *)name { return nameValue; }
- (void)connectWithServices:(unsigned)value { assert(linked && value==services); renewals++; }
@end

static void DeviceTest(void) {
 TestDevice *device=[[[TestDevice alloc] init] autorelease]; device->linked=YES;
 TestDevice *other=[[[TestDevice alloc] init] autorelease]; other->linked=YES;other->services=0x25;
 device->addressValue=@"AA:BB:CC:DD:EE:FF"; device->nameValue=@"Custom headphones";
 other->addressValue=@"11:22:33:44:55:66"; other->nameValue=@"Other headphones";
 NSArray *both=[NSArray arrayWithObjects:device,other,nil];
 assert(MWSelectAudioDevice(both,@"aabbccddeeff-output",@"renamed") == device);
 assert(MWSelectAudioDevice(both,@"opaque UID",@"Custom headphones") == device);
 assert(!MWSelectAudioDevice(both,@"opaque UID",@"unknown"));
 other->nameValue=device->nameValue;
 assert(MWSelectAudioDevice(both,@"aabbccddeeff-output",device->nameValue) == device);
 assert(!MWSelectAudioDevice(both,@"opaque UID",device->nameValue));
 other->linked=NO;
 assert(MWSelectAudioDevice(both,@"opaque UID",@"unknown") == device);
 device->linked=NO;
 assert(!MWSelectAudioDevice(both,@"opaque UID",@"unknown"));
}
static void PolicyTest(void) {
 MWRoutePolicy p={0};
 assert(MWRouteAllowed(&p,0,MWRouteA2DP,YES,NO,YES));
 assert(MWRouteAllowed(&p,2,MWRouteBuiltIn,YES,NO,YES));
 assert(MWRouteAllowed(&p,6,MWRouteUnknown,YES,NO,YES));
 assert(MWRouteAllowed(&p,6.01,MWRouteBuiltIn,YES,NO,YES)); // no self-inflicted route cutoff
 assert(!MWRouteAllowed(&p,7,MWRouteOther,YES,NO,YES));
 MWRouteInterruption(&p,true,8);
 assert(!MWRouteAllowed(&p,9,MWRouteA2DP,YES,NO,NO));
 assert(!MWRouteAllowed(&p,11,MWRouteOther,YES,NO,NO));
 assert(!MWRouteAllowed(&p,12,MWRouteA2DP,YES,YES,NO));
 assert(MWRouteAllowed(&p,13,MWRouteA2DP,YES,NO,NO)); // no end event needed
 assert(!p.interrupted);
 assert(!MWRouteAllowed(&p,14,MWRouteUnknown,NO,NO,YES));
 assert(MWRouteAllowed(&p,15,MWRouteBuiltIn,YES,NO,NO)); // cold session before A2DP route appears
 p.userPaused=true;
 assert(!MWRouteAllowed(&p,16,MWRouteBuiltIn,YES,NO,YES));
 assert(MWRouteAllowed(&p,17,MWRouteA2DP,YES,NO,YES));
 assert(!p.userPaused);
 assert(!MWRouteAllowed(&p,18,MWRouteA2DP,NO,NO,YES));
}
static void NoticeTest(void) {
 MWLossNotice p={0};
 assert(!MWLossNoticeUpdate(&p,0,YES,YES,YES,YES,NO));
 assert(!MWLossNoticeUpdate(&p,5,YES,YES,YES,YES,NO));
 assert(!MWLossNoticeUpdate(&p,10,NO,NO,NO,YES,NO));
 assert(!MWLossNoticeUpdate(&p,12,YES,YES,YES,YES,NO)); // brief drop recovers silently
 assert(!MWLossNoticeUpdate(&p,17,YES,YES,YES,YES,NO));
 assert(!MWLossNoticeUpdate(&p,18,NO,NO,NO,YES,NO));
 assert(MWLossNoticeUpdate(&p,21,NO,NO,NO,YES,NO));
 assert(!MWLossNoticeUpdate(&p,22,NO,NO,NO,YES,NO)); // one notice per loss
 MWLossNoticeUpdate(&p,23,YES,YES,YES,YES,NO);
 MWLossNoticeUpdate(&p,28,YES,YES,YES,YES,NO);
 MWLossNoticeUpdate(&p,29,NO,NO,NO,YES,NO);
 assert(!MWLossNoticeUpdate(&p,40,NO,NO,NO,YES,NO)); // global cooldown
 assert(!MWLossNoticeUpdate(&p,111,NO,NO,NO,YES,NO)); // no delayed stale notice after cooldown
 assert(!MWLossNoticeUpdate(&p,111,NO,NO,NO,NO,NO)); // Bluetooth disabled: cancel
 MWLossNoticeUpdate(&p,120,YES,YES,YES,YES,NO);
 MWLossNoticeUpdate(&p,125,YES,YES,YES,YES,NO);
 assert(!MWLossNoticeUpdate(&p,126,NO,NO,NO,YES,YES)); // call: cancel
 MWLossNoticeUpdate(&p,130,YES,YES,NO,YES,NO);
 assert(!MWLossNoticeUpdate(&p,140,NO,NO,NO,YES,NO)); // no user music
}
int main(void) { @autoreleasepool {
    DeviceTest(); PolicyTest(); NoticeTest(); RouteRefreshTest();
    TestAudio *audio=[[[TestAudio alloc] init] autorelease];
    MWWarmEngine *engine=[[[MWWarmEngine alloc] initWithBackend:audio] autorelease];
    Tick(engine,0,NO); assert(audio->activations==0 && audio.playing==0);
    // Two-second watchdog over ten minutes, including many 60-second clip ends.
    for(unsigned t=0;t<=600;t+=2) {
        Tick(engine,t,YES);
        assert(audio->active && audio.playing>=1 && audio.playing<=2);
    }
    // Leaving A2DP, an interruption, or a call must stop all players promptly.
    Tick(engine,602,NO); assert(!audio->active && audio.playing==0);
    unsigned before=audio->starts;
    Tick(engine,604,NO); assert(audio->starts==before);
    Tick(engine,606,YES); assert(audio->active && audio.playing==1);
    // Renewal failure must preserve the older clip and recover during overlap.
    audio->failPlayer=YES;
    Tick(engine,651,YES); assert(audio.playing==1);
    before=audio->starts;
    Tick(engine,652,YES); assert(audio->starts==before);
    audio->failPlayer=NO;
    Tick(engine,656,YES); assert(audio.playing==2);
    Tick(engine,666.1,YES); assert(audio.playing==1);
    // Total player failure relinquishes the session, then retries at a bound.
    Tick(engine,668,NO); audio->failPlayer=YES;
    Tick(engine,670,YES); assert(!audio->active && audio.playing==0);
    before=audio->activations;
    Tick(engine,672,YES); assert(audio->activations==before);
    audio->failPlayer=NO;
    Tick(engine,675,YES); assert(audio->active && audio.playing==1);
    Tick(engine,676,NO); audio->failActivation=YES;
    Tick(engine,678,YES); assert(!audio->active && audio.playing==0);
    before=audio->activations;
    Tick(engine,680,YES); assert(audio->activations==before);
    audio->failActivation=NO;
    Tick(engine,688,YES); assert(audio->active && audio.playing==1);
    // Actual AVAudioPlayers can stop without our bookkeeping losing _active.
    // Simulate that state: recovery must reactivate the session before play.
    for(TestPlayer *p in audio->created) [p stop]; audio->active=NO;
    before=audio->reactivations;
    Tick(engine,690,YES); assert(audio->reactivations==before+1 && audio->active && audio.playing==1);
    for(TestPlayer *p in audio->created) [p stop]; audio->active=NO;audio->failActivation=YES;
    Tick(engine,692,YES); assert(!audio->active && audio.playing==0);
    before=audio->activations;
    Tick(engine,693,YES); assert(audio->activations==before);
    audio->failActivation=NO;
    Tick(engine,694,YES); assert(audio->active && audio.playing==1);
    [engine stop]; assert(audio.playing==0 && !audio->active);
    // A route refresh discards stale players without deactivating the session
    // or restoring an old category underneath another app's music.
    Tick(engine,700,YES); before=audio->deactivations;
    [engine restartPlayers];
    assert(audio->active && !audio.playing && audio->deactivations==before);
    Tick(engine,701,YES); assert(audio.playing==1 && audio->deactivations==before);
    [engine stop];
    // play:YES with a delayed isPlaying transition must not be cancelled.
    TestAudio *delayed=[[[TestAudio alloc] init] autorelease]; delayed->latency=1.5;
    MWWarmEngine *cold=[[[MWWarmEngine alloc] initWithBackend:delayed] autorelease];
    Tick(cold,0,YES); assert(delayed->starts==1 && delayed->active && delayed.playing==0);
    assert(!((TestPlayer*)[delayed->created objectAtIndex:0])->stopped);
    Tick(cold,1,YES); assert(delayed->starts==1 && delayed->confirmations==0);
    Tick(cold,2,YES); assert(delayed->starts==1 && delayed.playing==1 && delayed->confirmations==1);
    for(unsigned t=4;t<180;t+=2) { Tick(cold,t,YES); assert(delayed.playing>=1 && delayed.playing<=2); }
    [cold stop];
    // A queue which never starts is diagnosed and recovered after the grace.
    delayed->latency=10;
    Tick(cold,200,YES); assert(delayed->active);
    unsigned timed=delayed->timeouts;
    Tick(cold,204,YES); assert(delayed->timeouts==timed+1);
    [cold stop];
    puts("PASS: selected A2DP refresh, user route preservation, queue restart without deactivation, asynchronous startup and loss-notice limits.");
} }
