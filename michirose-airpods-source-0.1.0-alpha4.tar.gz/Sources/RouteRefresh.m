// MIT. Interface and BOOL return ABI checked against iOS 6.1 MediaPlayer metadata.
#import "RouteRefresh.h"
@implementation MWRouteRefresh
- (id)initWithController:(id<MWMediaRouteController>)controller a2dpPortType:(NSString *)type {
    if((self=[super init])) { _controller=[controller retain]; _a2dpPortType=[type copy]; }
    return self;
}
- (void)dealloc { [_controller release]; [_a2dpPortType release]; [super dealloc]; }
- (NSDictionary *)currentA2DP {
    @try {
    if(![_controller respondsToSelector:@selector(clearCachedRoutes)] ||
       ![_controller respondsToSelector:@selector(pickedRouteDescription)]) return nil;
    [_controller clearCachedRoutes];
    id route=[_controller pickedRouteDescription];
    if(![route isKindOfClass:[NSDictionary class]]) return nil;
    id type=[route objectForKey:@"AVAudioRouteName"];
    if(![type isKindOfClass:[NSString class]]) return nil;
    if(![type isEqualToString:_a2dpPortType] && ![type isEqualToString:@"BluetoothA2DPOutput"] &&
       ![type isEqualToString:@"BluetoothA2DP"]) return nil;
    return route;
    } @catch(NSException *exception) { return nil; }
}
- (BOOL)selectedA2DP { return [self currentA2DP]!=nil; }
- (MWRefreshResult)refreshAt:(NSTimeInterval)now {
    if(![_controller respondsToSelector:@selector(_pickRoute:)]) return MWRefreshUnavailable;
    // Read again at execution time, so a delayed track event cannot undo a
    // user's intervening choice of speaker, HFP, AirPlay or wired headphones.
    NSDictionary *route=[self currentA2DP];
    if(!route) return MWRefreshNotA2DP;
    if(now<_next) return MWRefreshCooldown;
    _next=now+2;
    @try { return [_controller _pickRoute:route] ? MWRefreshAccepted : MWRefreshRejected; }
    @catch(NSException *exception) { return MWRefreshUnavailable; }
}
@end
