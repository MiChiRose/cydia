// MIT. MiChiRose AirPods Fix. No Bluetooth addresses, device names or audio
// belonging to the user are inspected or recorded.
#import "KeepWarmEngine.h"

@interface MWWarmSlot : NSObject { @public id<MWWarmPlayer> player; NSTimeInterval started; BOOL observedPlaying; }
@end
@implementation MWWarmSlot
- (void)dealloc { [player release]; [super dealloc]; }
@end

@implementation MWWarmEngine
- (id)initWithBackend:(id<MWWarmBackend>)backend {
    if ((self = [super init])) { _backend = [backend retain]; _players = [[NSMutableArray alloc] init]; }
    return self;
}
- (void)dealloc { [self stop]; [_players release]; [_backend release]; [super dealloc]; }
- (void)stop {
    [self restartPlayers];
    if (_active) { [_backend deactivate]; [_backend record:@"warm stopped"]; }
    _active = NO;
}
- (void)restartPlayers {
    for (MWWarmSlot *slot in _players) [slot->player stop];
    [_players removeAllObjects];
    _renewAt = _retryAt = 0;
}
- (void)updateAt:(NSTimeInterval)now allowed:(BOOL)allowed {
    if (!allowed) { [self stop]; return; }
    if (now < _retryAt) return;
    BOOL justActivated=NO;
    if (!_active) {
        if (![_backend activate]) { _retryAt = now + 10; return; }
        _active = YES;
        justActivated=YES;
    }
    for (MWWarmSlot *slot in [[_players copy] autorelease]) {
        // AVAudioPlayer.play accepting a request and isPlaying becoming true
        // are separate events. Give the audio queue time to start.
        BOOL playing=[slot->player isPlaying];
        if(playing && !slot->observedPlaying && [_backend respondsToSelector:@selector(confirmedPlaying)]) [_backend confirmedPlaying];
        if(playing) slot->observedPlaying=YES;
        if (!playing && (slot->observedPlaying || now-slot->started>=3)) {
            if(!slot->observedPlaying && [_backend respondsToSelector:@selector(playerStartTimedOut)]) [_backend playerStartTimedOut];
            [slot->player stop];
            [_players removeObjectIdenticalTo:slot];
        }
    }
    if ([_players count] && now < _renewAt) return;
    if(![_players count] && !justActivated && ![_backend reactivate]) {
        [self stop]; _retryAt=now+2;
        [_backend record:@"warm session lost; reactivation pending"];
        return;
    }
    id<MWWarmPlayer> player = [_backend startPlayer];
    if (!player) {
        [player stop];
        // Preserve an older, still-playing clip if renewal fails. Retry well
        // before its end; never claim that silence is playing when it isn't.
        if (![_players count]) [self stop];
        _retryAt = now + 5;
        [_backend record:@"warm player failed; retry pending"];
        return;
    }
    MWWarmSlot *slot=[[[MWWarmSlot alloc] init] autorelease];
    slot->player=[player retain]; slot->started=now; slot->observedPlaying=[player isPlaying];
    if(slot->observedPlaying && [_backend respondsToSelector:@selector(confirmedPlaying)]) [_backend confirmedPlaying];
    [_players addObject:slot];
    while ([_players count] > 2) {
        MWWarmSlot *old=[_players objectAtIndex:0]; [old->player stop];
        [_players removeObjectAtIndex:0];
    }
    _renewAt = now + 45; // Nominal 15-second overlap, minus watchdog scheduling.
    _retryAt = 0;
    [_backend record:@"warm player started"];
}
@end
