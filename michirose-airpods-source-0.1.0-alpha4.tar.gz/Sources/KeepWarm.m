// MIT. Independent implementation of continuous silent A2DP playback.
// The approach is documented by asentientbot/ios-6-pods-hack and
// mikey820/AirPodsReconnectFix; no source/audio assets from them are included.
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreTelephony/CTCallCenter.h>
#import <dispatch/dispatch.h>
#include <sys/sysctl.h>
#include <syslog.h>
#include <string.h>
#include <dlfcn.h>
#import "KeepWarmEngine.h"
#import "RoutePolicy.h"
#import "DeviceSelection.h"
#import "RouteRefresh.h"
#include "LossNotice.h"
extern void MWShowAirPodsNotice(NSString *title,NSString *message,NSString *report);

// These read-only selectors are present in the iOS 6 BluetoothManager binary.
@interface NSObject (MWBluetoothAudioState)
+ (id)sharedInstance;
- (BOOL)audioConnected;
- (BOOL)enabled;
- (NSArray *)connectedDevices;
- (NSString *)address;
- (NSString *)name;
- (unsigned)majorClass;
- (void)setCategory:(NSString *)category;
@end

static BOOL MWA2DPRoute(AVAudioSession *session) {
    for (AVAudioSessionPortDescription *port in session.currentRoute.outputs)
        if ([port.portType isEqualToString:AVAudioSessionPortBluetoothA2DP]) return YES;
    return NO;
}

static MWRouteKind MWOutputKind(AVAudioSession *session) {
    if(MWA2DPRoute(session)) return MWRouteA2DP;
    NSArray *outputs=session.currentRoute.outputs;
    if(![outputs count]) return MWRouteUnknown;
    for(AVAudioSessionPortDescription *port in outputs)
        if(![port.portType isEqualToString:AVAudioSessionPortBuiltInSpeaker] &&
            ![port.portType isEqualToString:AVAudioSessionPortBuiltInReceiver]) return MWRouteOther;
    return MWRouteBuiltIn;
}

static id<MWConnectedAudioDevice> MWSelectedDevice(id manager,AVAudioSession *session) {
    if(![manager respondsToSelector:@selector(connectedDevices)]) return nil;
    for(AVAudioSessionPortDescription *port in session.currentRoute.outputs)
        if([port.portType isEqualToString:AVAudioSessionPortBluetoothA2DP])
            return MWSelectAudioDevice([manager connectedDevices],port.UID,port.portName);
    return nil;
}

@interface AVAudioPlayer (MWWarmPlayer) <MWWarmPlayer>
@end

@interface MWWarmService : NSObject <MWWarmBackend> {
    MWWarmEngine *_engine;
    MWRouteRefresh *_routeRefresh;
    CTCallCenter *_calls;
    id _bluetooth;
    id<MWConnectedAudioDevice> _routeDevice;
    MWRoutePolicy _policy;
    MWLossNotice _lossNotice;
    MWRouteKind _lastKind;
    BOOL _recordedState, _lastCall, _lastAllowed;
    BOOL _evaluating, _ownsSession;
    BOOL _connected, _refreshQueued;
    NSTimeInterval _connectedAt;
    unsigned _failures;
    NSTimeInterval _nextFailureNotice;
    NSString *_previousCategory;
    NSMutableArray *_events;
    AVAudioSessionCategoryOptions _previousOptions;
}
- (void)evaluate;
- (NSString *)reportText;
- (void)failedStage:(NSString *)stage error:(NSError *)error;
- (void)queueRouteRefresh:(NSNotification *)note;
@end

@implementation MWWarmService
- (id)init {
    if ((self = [super init])) {
        _events = [[NSMutableArray alloc] init];
        _calls = [[CTCallCenter alloc] init];
        dlopen("/System/Library/PrivateFrameworks/BluetoothManager.framework/BluetoothManager", RTLD_LAZY);
        Class managerClass = NSClassFromString(@"BluetoothManager");
        if ([managerClass respondsToSelector:@selector(sharedInstance)]) _bluetooth = [[managerClass sharedInstance] retain];
        _engine = [[MWWarmEngine alloc] initWithBackend:self];
        dlopen("/System/Library/Frameworks/MediaPlayer.framework/MediaPlayer",RTLD_LAZY);
        Class routeClass=NSClassFromString(@"MPAudioDeviceController");
        id controller=[[routeClass alloc] init];
        if([controller respondsToSelector:@selector(setCategory:)]) [controller setCategory:AVAudioSessionCategoryPlayback];
        _routeRefresh=[[MWRouteRefresh alloc] initWithController:controller a2dpPortType:AVAudioSessionPortBluetoothA2DP];
        [controller release];
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(routeChanged:) name:AVAudioSessionRouteChangeNotification object:nil];
        [center addObserver:self selector:@selector(interruption:) name:AVAudioSessionInterruptionNotification object:nil];
        [center addObserver:self selector:@selector(reset:) name:AVAudioSessionMediaServicesWereResetNotification object:nil];
        // Both notification names are present in the iOS 6 SpringBoard binary.
        [center addObserver:self selector:@selector(queueRouteRefresh:) name:@"SBMediaNowPlayingChangedNotification" object:nil];
        [center addObserver:self selector:@selector(queueRouteRefresh:) name:@"SBMediaNowPlayingAppChangedNotification" object:nil];
        // SpringBoard remains alive while locked; common modes cover UI tracking.
        NSTimer *timer = [NSTimer timerWithTimeInterval:2 target:self selector:@selector(evaluate) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
        [self record:@"selected A2DP route protection loaded (alpha 4)"];
        [self evaluate];
    }
    return self;
}
- (void)record:(NSString *)event {
    syslog(LOG_NOTICE, "AirPodsFix: %s", [event UTF8String]);
    [_events addObject:[NSString stringWithFormat:@"%@ %@", [NSDate date], event]];
    while ([_events count] > 64) [_events removeObjectAtIndex:0];
    NSString *folder = @"/var/mobile/Library/Logs";
    [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:NULL];
    [[[_events componentsJoinedByString:@"\n"] stringByAppendingString:@"\n"]
        writeToFile:[folder stringByAppendingPathComponent:@"AirPodsFix.log"] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}
- (void)evaluate {
    if (_evaluating) return;
    _evaluating = YES;
    @try {
        AVAudioSession *session = [AVAudioSession sharedInstance];
        NSTimeInterval now=[NSProcessInfo processInfo].systemUptime;
        MWRouteKind kind=MWOutputKind(session);
        if(kind==MWRouteA2DP) {
            id<MWConnectedAudioDevice> selected=MWSelectedDevice(_bluetooth,session);
            if(selected!=_routeDevice) { [_routeDevice release]; _routeDevice=[selected retain]; }
        }
        NSArray *devices=[_bluetooth respondsToSelector:@selector(connectedDevices)] ? [_bluetooth connectedDevices] : nil;
        BOOL connected=[MWConnectedAudioDevices(devices) count]!=0;
        if(!devices && [_bluetooth respondsToSelector:@selector(audioConnected)]) connected=[_bluetooth audioConnected];
        if(connected!=_connected) {
            _connected=connected; _connectedAt=now; _failures=0;
        }
        BOOL call=[_calls.currentCalls count]!=0;
        BOOL microphone=[session.category isEqualToString:AVAudioSessionCategoryRecord] ||
            [session.category isEqualToString:AVAudioSessionCategoryPlayAndRecord];
        BOOL busy=call || microphone;
        BOOL bluetoothOn=![_bluetooth respondsToSelector:@selector(enabled)] || [_bluetooth enabled];
        if(MWLossNoticeUpdate(&_lossNotice,now,kind==MWRouteA2DP,connected,session.otherAudioPlaying,bluetoothOn,busy)) {
            [self record:@"connection lost during playback; user notification requested"];
            BOOL ru=[[[NSLocale preferredLanguages] objectAtIndex:0] hasPrefix:@"ru"];
            MWShowAirPodsNotice(@"AirPods Fix",ru ? @"Соединение с наушниками потеряно. Возможно, они переключились на другое устройство."
                : @"The headphones disconnected. They may have switched to another device.",[self reportText]);
        }
        BOOL wasInterrupted=_policy.interrupted;
        BOOL allowed=MWRouteAllowed(&_policy,now,kind,connected,busy,_ownsSession);
        if(wasInterrupted && !_policy.interrupted) [self record:@"recovered omitted interruption end on connected audio device"];
        if(!_recordedState || kind!=_lastKind || call!=_lastCall || allowed!=_lastAllowed) {
            [self record:[NSString stringWithFormat:@"route state kind=%d allowed=%d call=%d target=%d",kind,allowed,call,_routeDevice!=nil]];
            _recordedState=YES; _lastKind=kind; _lastCall=call; _lastAllowed=allowed;
        }
        if(!connected) { [_routeDevice release]; _routeDevice=nil; }
        [_engine updateAt:now allowed:allowed];
    } @catch (NSException *exception) {
        [_engine stop];
        [self record:@"route protection stopped after exception"];
    } @finally { _evaluating = NO; }
}
- (void)routeChanged:(NSNotification *)note {
    // Route callbacks may originate outside the main thread. All state and
    // player transitions are serialized on the main run loop.
    unsigned reason=[[note.userInfo objectForKey:AVAudioSessionRouteChangeReasonKey] unsignedIntValue];
    dispatch_async(dispatch_get_main_queue(), ^{
        if(reason==AVAudioSessionRouteChangeReasonOverride) _policy.userPaused=
            ![_routeRefresh selectedA2DP] && MWOutputKind([AVAudioSession sharedInstance])!=MWRouteA2DP;
        // A player can still report isPlaying on the old output after a route
        // switch. Its status alone does not establish a live new A2DP stream.
        if(MWOutputKind([AVAudioSession sharedInstance])==MWRouteA2DP && _lastKind!=MWRouteA2DP) {
            [_engine restartPlayers]; _failures=0;
        }
        [self record:[NSString stringWithFormat:@"route notification reason=%u",reason]];
        [self evaluate];
    });
}
- (void)queueRouteRefresh:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        if(_refreshQueued) return;
        _refreshQueued=YES;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.35*NSEC_PER_SEC)),dispatch_get_main_queue(), ^{
            _refreshQueued=NO;
            @try {
                AVAudioSession *session=[AVAudioSession sharedInstance];
                BOOL mic=[session.category isEqualToString:AVAudioSessionCategoryRecord] ||
                    [session.category isEqualToString:AVAudioSessionCategoryPlayAndRecord];
                if(!_connected || _policy.userPaused || _policy.interrupted || mic || [_calls.currentCalls count]) return;
                MWRefreshResult result=[_routeRefresh refreshAt:[NSProcessInfo processInfo].systemUptime];
                [self record:[NSString stringWithFormat:@"track change selected-route refresh=%d",result]];
                if(result==MWRefreshAccepted) {
                    [_engine restartPlayers];
                    [self evaluate];
                }
            } @catch(NSException *exception) {
                [self record:@"selected-route refresh unavailable after exception"];
            }
        });
    });
}
- (void)interruption:(NSNotification *)note {
    BOOL began = [[note.userInfo objectForKey:AVAudioSessionInterruptionTypeKey] unsignedIntegerValue] == AVAudioSessionInterruptionTypeBegan;
    dispatch_async(dispatch_get_main_queue(), ^{
        MWRouteInterruption(&_policy,began,[NSProcessInfo processInfo].systemUptime);
        if (began) {
            [_engine stop];
        }
        else [self evaluate];
    });
}
- (void)reset:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        _ownsSession=NO;
        [_previousCategory release]; _previousCategory=nil;
        [_engine stop];
        memset(&_policy,0,sizeof(_policy)); [self evaluate];
    });
}
- (BOOL)activate {
    AVAudioSession *session = [AVAudioSession sharedInstance];
    if(!_ownsSession) {
        [_previousCategory release]; _previousCategory = [session.category copy];
        _previousOptions = session.categoryOptions;
    }
    NSError *error = nil;
    if (![session setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionMixWithOthers error:&error]) {
        [self failedStage:@"SESSION_CATEGORY" error:error];
        return NO;
    }
    if (![session setActive:YES error:&error]) {
        if (_previousCategory) [session setCategory:_previousCategory withOptions:_previousOptions error:NULL];
        [self failedStage:@"SESSION_ACTIVATE" error:error];
        return NO;
    }
    _ownsSession = YES;
    return YES;
}
- (BOOL)reactivate { return [self activate]; }
- (void)deactivate {
    if (!_ownsSession) return;
    _ownsSession = NO;
    AVAudioSession *session = [AVAudioSession sharedInstance];
    // Restore only a category we still own, respecting a change made elsewhere.
    if ([session.category isEqualToString:AVAudioSessionCategoryPlayback] &&
        session.categoryOptions == AVAudioSessionCategoryOptionMixWithOthers) {
        [session setActive:NO withOptions:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation error:NULL];
        if (_previousCategory) [session setCategory:_previousCategory withOptions:_previousOptions error:NULL];
    }
}
- (NSString *)reportText {
    return [NSString stringWithFormat:@"AirPods Fix 0.1.0~alpha4\n%@\nNo device names, addresses or music contents.\n",[_events componentsJoinedByString:@"\n"]];
}
- (void)failedStage:(NSString *)stage error:(NSError *)error {
    [self record:[NSString stringWithFormat:@"%@ failed (%@:%ld)",stage,error.domain ?: @"no OS error",(long)error.code]];
    _failures++;
    NSTimeInterval now=[NSProcessInfo processInfo].systemUptime;
    // Connection/setup transients are not proof that headphones are unavailable.
    if(!_connected || now-_connectedAt<8) return;
    if(_failures<3 || now<_nextFailureNotice) return;
    _nextFailureNotice=now+180;
    BOOL ru=[[[NSLocale preferredLanguages] objectAtIndex:0] hasPrefix:@"ru"];
    NSString *text=[NSString stringWithFormat:ru ? @"Не удалось запустить защитный аудиопоток. Это не означает, что наушники отключены. Этап: %@. Код: %@:%ld."
        : @"The protective audio stream could not start. This does not mean the headphones disconnected. Stage: %@. Code: %@:%ld.",stage,error.domain ?: @"none",(long)error.code];
    MWShowAirPodsNotice(@"AirPods Fix",text,[self reportText]);
}
- (id<MWWarmPlayer>)startPlayer {
    NSError *error=nil;
    NSURL *url=[NSURL fileURLWithPath:@"/Library/Application Support/AirPodsFix/silence.mp3"];
    NSDictionary *attributes=[[NSFileManager defaultManager] attributesOfItemAtPath:[url path] error:&error];
    if(![[attributes objectForKey:NSFileSize] unsignedLongLongValue]) { [self failedStage:@"AUDIO_RESOURCE" error:error]; return nil; }
    AVAudioPlayer *player=[[[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error] autorelease];
    if(!player) { [self failedStage:@"PLAYER_CREATE" error:error]; return nil; }
    if(player.duration<59) {
        [self record:[NSString stringWithFormat:@"player duration=%.3f",player.duration]];
        [self failedStage:@"PLAYER_DURATION" error:nil]; return nil;
    }
    if(![player prepareToPlay]) { [self failedStage:@"PLAYER_PREPARE" error:nil]; return nil; }
    if(![player play]) { [self failedStage:@"PLAYER_PLAY" error:nil]; return nil; }
    // play:YES means the queue accepted the request; isPlaying may become true
    // on a later audio callback. KeepWarmEngine handles this startup interval.
    return player;
}
- (void)playerStartTimedOut { [self failedStage:@"PLAYER_START_TIMEOUT" error:nil]; }
- (void)confirmedPlaying { _failures=0; }
@end

__attribute__((constructor)) static void MWWarmInit(void) {
    @autoreleasepool {
        if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.springboard"]) return;
        char machine[32] = {0}, build[32] = {0}; size_t size = sizeof machine;
        if (sysctlbyname("hw.machine", machine, &size, NULL, 0)) return;
        size = sizeof build;
        if (sysctlbyname("kern.osversion", build, &size, NULL, 0) || strcmp(build, "10B329")) return;
        if (strcmp(machine,"iPhone4,1") && strcmp(machine,"iPhone5,1") && strcmp(machine,"iPhone5,2")) return;
        dispatch_async(dispatch_get_main_queue(), ^{
            static MWWarmService *service;
            service = [[MWWarmService alloc] init]; // process-lifetime service
            (void)service;
        });
    }
}
