// MIT. Re-select only the current A2DP route; never select a speaker or connect Bluetooth.
#import <Foundation/Foundation.h>
@protocol MWMediaRouteController <NSObject>
- (void)clearCachedRoutes;
- (NSDictionary *)pickedRouteDescription;
- (BOOL)_pickRoute:(NSDictionary *)route;
@end
typedef enum { MWRefreshUnavailable, MWRefreshNotA2DP, MWRefreshCooldown,
               MWRefreshRejected, MWRefreshAccepted } MWRefreshResult;
@interface MWRouteRefresh : NSObject {
    id<MWMediaRouteController> _controller;
    NSString *_a2dpPortType;
    NSTimeInterval _next;
}
- (id)initWithController:(id<MWMediaRouteController>)controller a2dpPortType:(NSString *)type;
- (BOOL)selectedA2DP;
- (MWRefreshResult)refreshAt:(NSTimeInterval)now;
@end
