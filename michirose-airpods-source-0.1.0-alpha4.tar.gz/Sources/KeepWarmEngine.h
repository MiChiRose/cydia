// MIT. MiChiRose AirPods Fix.
#import <Foundation/Foundation.h>

@protocol MWWarmPlayer <NSObject>
- (BOOL)isPlaying;
- (void)stop;
@end
@protocol MWWarmBackend <NSObject>
- (BOOL)activate;
- (BOOL)reactivate;
- (void)deactivate;
- (id<MWWarmPlayer>)startPlayer;
- (void)record:(NSString *)event;
@optional
- (void)playerStartTimedOut;
- (void)confirmedPlaying;
@end

@interface MWWarmEngine : NSObject {
    id<MWWarmBackend> _backend;
    NSMutableArray *_players;
    BOOL _active;
    NSTimeInterval _renewAt, _retryAt;
}
- (id)initWithBackend:(id<MWWarmBackend>)backend;
- (void)updateAt:(NSTimeInterval)now allowed:(BOOL)allowed;
- (void)stop;
- (void)restartPlayers;
@end
