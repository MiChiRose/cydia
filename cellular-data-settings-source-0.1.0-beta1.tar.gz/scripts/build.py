#!/usr/bin/env python3
import argparse
import gzip
import hashlib
import io
import subprocess
import sys
import tarfile
from pathlib import Path
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[1]
LIBRARY = 'Library/MobileSubstrate/DynamicLibraries'
STEM = 'cellular-data-settings'


def tar_gzip(files):
    buffer = io.BytesIO()
    directories = {Path('.')}
    for name, _, _ in files:
        directories.update(Path(name).parents)
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for directory in sorted(directories, key=lambda path: (len(path.parts), str(path))):
            info = tarfile.TarInfo('./' if directory == Path('.') else f'./{directory}/')
            info.type = tarfile.DIRTYPE
            info.mode = 0o755
            info.uname = info.gname = 'root'
            archive.addfile(info)
        for name, data, mode in sorted(files):
            info = tarfile.TarInfo(f'./{name}')
            info.size = len(data)
            info.mode = mode
            info.uname = info.gname = 'root'
            archive.addfile(info, io.BytesIO(data))
    return gzip.compress(buffer.getvalue(), mtime=0)


def deb_archive(members):
    deb = bytearray(b'!<arch>\n')
    for name, data in members:
        header = f'{name + "/":<16}{0:<12}{0:<6}{0:<6}{"100644":<8}{len(data):<10}`\n'
        assert len(header) == 60
        deb.extend(header.encode('ascii'))
        deb.extend(data)
        if len(data) % 2:
            deb.extend(b'\n')
    return deb


def main():
    parser = argparse.ArgumentParser(description='Build the iOS 6.1.3 Settings tweak')
    parser.add_argument('--sdk', type=Path, required=True)
    parser.add_argument('--linker', type=Path, required=True)
    parser.add_argument('--ldid', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=ROOT / 'dist')
    args = parser.parse_args()

    with TemporaryDirectory(prefix='cellular-data-build.') as temp:
        binary = Path(temp) / 'CellularDataSettings.dylib'
        subprocess.run([
            'clang', '-target', 'armv7-apple-ios6.0', '-marm', '-isysroot', str(args.sdk.resolve()),
            '-dynamiclib', '-O2', '-fno-objc-arc', '-fblocks', '-fvisibility=hidden',
            '-Wall', '-Wextra', '-Werror', '-Wno-cast-function-type-mismatch',
            '--ld-path=' + str(args.linker.resolve()), '-Wl,-no_fixup_chains,-no_adhoc_codesign',
            '-framework', 'Foundation', '-framework', 'CoreTelephony',
            str(ROOT / 'Sources/CellularDataSettings.m'), '-o', str(binary),
        ], check=True)
        subprocess.run([str(args.ldid.resolve()), '-Hsha1', '-S', str(binary)], check=True)
        subprocess.run([sys.executable, str(ROOT / 'scripts/check_binary.py'), str(binary)], check=True)
        dylib = binary.read_bytes()

    control = (ROOT / 'packaging/control').read_text()
    version = next(line.split(': ', 1)[1] for line in control.splitlines() if line.startswith('Version: '))
    payload = [
        (f'{LIBRARY}/CellularDataSettings.dylib', dylib, 0o755),
        (f'{LIBRARY}/CellularDataSettings.plist', (ROOT / 'packaging/CellularDataSettings.plist').read_bytes(), 0o644),
    ]
    control += f'Installed-Size: {(sum(len(data) for _, data, _ in payload) + 1023) // 1024}\n'
    md5sums = ''.join(f'{hashlib.md5(data).hexdigest()}  {name}\n' for name, data, _ in payload)
    metadata = [('control', control.encode(), 0o644), ('md5sums', md5sums.encode(), 0o644)]

    args.output.mkdir(parents=True, exist_ok=True)
    deb = args.output / f'{STEM}_{version}_iphoneos-arm.deb'
    deb.write_bytes(deb_archive([
        ('debian-binary', b'2.0\n'),
        ('control.tar.gz', tar_gzip(metadata)),
        ('data.tar.gz', tar_gzip(payload)),
    ]))
    source_files = [ROOT / name for name in ('LICENSE', 'README.md', '.gitignore')]
    for directory in ('Sources', 'scripts', 'packaging'):
        source_files.extend(path for path in (ROOT / directory).iterdir() if path.is_file())
    sources = [(str(path.relative_to(ROOT)), path.read_bytes(), 0o644) for path in source_files]
    source = args.output / f'{STEM}-source-{version.replace("~", "-")}.tar.gz'
    source.write_bytes(tar_gzip(sources))
    print(f'Built {deb.name} and {source.name}')


if __name__ == '__main__':
    main()
