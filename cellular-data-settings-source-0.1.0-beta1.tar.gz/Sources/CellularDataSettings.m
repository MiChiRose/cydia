#import <Foundation/Foundation.h>
#import <dispatch/dispatch.h>
#import <dlfcn.h>
#import <objc/runtime.h>
#import <string.h>
#import <sys/sysctl.h>

// These are the CoreTelephony entry points used by SettingsNetworkController
// in the iPhone 4s iOS 6.1.3 firmware.
extern BOOL CTCellularDataPlanGetIsEnabled(void);
extern void CTCellularDataPlanSetIsEnabled(BOOL enabled);
extern CFArrayRef CTCopyCurrentCallsWithTypes(CFAllocatorRef allocator, CFArrayRef types);
extern CFStringRef const kCTCallTypeVideoConference;

@interface PSSpecifier : NSObject
+ (instancetype)preferenceSpecifierNamed:(NSString *)name target:(id)target set:(SEL)setter
                                    get:(SEL)getter detail:(Class)detail cell:(NSInteger)cell edit:(Class)edit;
- (void)setIdentifier:(NSString *)identifier;
- (void)setProperty:(id)value forKey:(NSString *)key;
@end

@interface NSObject (CellularDataSettingsPrivate)
+ (NSInteger)cellTypeFromString:(NSString *)name;
- (PSSpecifier *)specifierForID:(NSString *)identifier;
- (void)insertSpecifier:(id)specifier afterSpecifier:(id)anchor animated:(BOOL)animated;
- (void)reloadSpecifier:(id)specifier animated:(BOOL)animated;
- (NSNumber *)getAirplaneMode:(id)specifier;
- (id)cds_readCellularData:(id)specifier;
- (void)cds_writeCellularData:(NSNumber *)value specifier:(id)specifier;
- (BOOL)isViewLoaded;
- (id)initWithTitle:(NSString *)title message:(NSString *)message delegate:(id)delegate
  cancelButtonTitle:(NSString *)cancel otherButtonTitles:(NSString *)other, ...;
- (void)show;
- (NSInteger)cancelButtonIndex;
@end

static NSString *const DataRowID = @"com.michirose.cellulardata.switch";
static char WarningDelegateKey;

static NSString *NetworkString(NSString *key, NSString *fallback) {
    return [[NSBundle mainBundle] localizedStringForKey:key value:fallback table:@"Network~iphone"];
}

static BOOL IsAirplaneMode(id root) {
    return [[root getAirplaneMode:nil] boolValue];
}

static void RefreshRow(id root) {
    if (![root isViewLoaded]) return;
    PSSpecifier *row = [root specifierForID:DataRowID];
    if (!row) return;
    [row setProperty:@(!IsAirplaneMode(root)) forKey:@"enabled"];
    [root reloadSpecifier:row animated:NO];
}

static void SetDataEnabled(id root, BOOL enabled) {
    BOOL previous = CTCellularDataPlanGetIsEnabled();
    if (!IsAirplaneMode(root) && previous != enabled) {
        CTCellularDataPlanSetIsEnabled(enabled);
    }
    // Read the value back from CoreTelephony after the switch's event handler.
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL actual = CTCellularDataPlanGetIsEnabled();
        if (actual != previous) {
            [[NSNotificationCenter defaultCenter] postNotificationName:@"PSCellDataChangedNotification"
                                                                object:nil userInfo:@{@"DataEnabled": @(actual)}];
        }
        RefreshRow(root);
    });
}

@interface CDSFaceTimeWarning : NSObject {
    id _root;
}
- (instancetype)initWithRoot:(id)root;
@end

@implementation CDSFaceTimeWarning
- (instancetype)initWithRoot:(id)root {
    self = [super init];
    if (self) _root = [root retain];
    return self;
}

- (void)dealloc {
    [_root release];
    [super dealloc];
}

- (void)alertView:(id)alert clickedButtonAtIndex:(NSInteger)index {
    if (index != [alert cancelButtonIndex]) {
        SetDataEnabled(_root, NO);
    }
}
@end

static BOOL ShowFaceTimeWarning(id root) {
    NSArray *types = @[(NSString *)kCTCallTypeVideoConference];
    CFArrayRef calls = CTCopyCurrentCallsWithTypes(kCFAllocatorDefault, (CFArrayRef)types);
    BOOL hasVideoCall = calls && CFArrayGetCount(calls) > 0;
    if (calls) CFRelease(calls);
    if (!hasVideoCall) return NO;

    CDSFaceTimeWarning *delegate = [[CDSFaceTimeWarning alloc] initWithRoot:root];
    id alert = [[NSClassFromString(@"UIAlertView") alloc]
        initWithTitle:@"FaceTime"
              message:NetworkString(@"CELLULAR_DATA_ON_FACETIME_WIFI_WARNING_DISABLE",
                                    @"Turning off Cellular Data may end this FaceTime call.")
             delegate:delegate
    cancelButtonTitle:NetworkString(@"ON_CALL_CANCEL", @"Cancel")
    otherButtonTitles:NetworkString(@"DISABLE_CELLULAR_DATA", @"Disable Cellular Data"), nil];
    objc_setAssociatedObject(alert, &WarningDelegateKey, delegate, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [delegate release];
    [alert show];
    [alert release];
    // Until the user confirms, leave the switch showing the current setting.
    dispatch_async(dispatch_get_main_queue(), ^{ RefreshRow(root); });
    return YES;
}

static id ReadData(id root, SEL command, id specifier) {
    (void)root;
    (void)command;
    (void)specifier;
    return @(CTCellularDataPlanGetIsEnabled());
}

static void WriteData(id root, SEL command, NSNumber *value, id specifier) {
    (void)command;
    (void)specifier;
    BOOL enabled = [value boolValue];
    if (!enabled && !IsAirplaneMode(root) && CTCellularDataPlanGetIsEnabled() && ShowFaceTimeWarning(root)) {
        return;
    }
    SetDataEnabled(root, enabled);
}

static void InstallRow(id root) {
    if (![root isViewLoaded]) return;
    if ([root specifierForID:DataRowID]) {
        RefreshRow(root);
        return;
    }

    // IDs from the stock iPhone Settings.plist are independent of the language.
    id bluetooth = [root specifierForID:@"Bluetooth"];
    if (!bluetooth || ![root specifierForID:@"WIFI"] || ![root specifierForID:@"AIRPLANE_MODE"]) return;

    NSInteger switchCell = [NSClassFromString(@"PSTableCell") cellTypeFromString:@"PSSwitchCell"];
    PSSpecifier *row = [NSClassFromString(@"PSSpecifier")
        preferenceSpecifierNamed:NetworkString(@"MOBILE_DATA_SETTINGS", @"Cellular Data")
                           target:root set:@selector(cds_writeCellularData:specifier:)
                              get:@selector(cds_readCellularData:) detail:Nil cell:switchCell edit:Nil];
    if (!row) return;
    [row setIdentifier:DataRowID];
    [row setProperty:@(!IsAirplaneMode(root)) forKey:@"enabled"];

    Ivar iconCache = class_getInstanceVariable(object_getClass(root), "_iconCache");
    id icons = iconCache ? object_getIvar(root, iconCache) : nil;
    if ([icons isKindOfClass:[NSDictionary class]]) {
        id image = [icons objectForKey:@"Data"];
        if ([image isKindOfClass:NSClassFromString(@"UIImage")]) {
            [row setProperty:image forKey:@"iconImage"];
        }
    }
    [root insertSpecifier:row afterSpecifier:bluetooth animated:NO];
}

static void (*OriginalViewWillAppear)(id, SEL, BOOL);
static void (*OriginalReloadSpecifiers)(id, SEL);
static void (*OriginalWillEnterForeground)(id, SEL);
static void (*OriginalAirplaneModeChangedExternally)(id, SEL);
static void (*OriginalSetAirplaneMode)(id, SEL, BOOL);

static void ViewWillAppear(id root, SEL command, BOOL animated) {
    OriginalViewWillAppear(root, command, animated);
    InstallRow(root);
}

static void ReloadSpecifiers(id root, SEL command) {
    OriginalReloadSpecifiers(root, command);
    InstallRow(root);
}

static void WillEnterForeground(id root, SEL command) {
    OriginalWillEnterForeground(root, command);
    RefreshRow(root);
}

static void AirplaneModeChangedExternally(id root, SEL command) {
    OriginalAirplaneModeChangedExternally(root, command);
    RefreshRow(root);
}

static void SetAirplaneMode(id root, SEL command, BOOL enabled) {
    OriginalSetAirplaneMode(root, command, enabled);
    RefreshRow(root);
}

typedef void (*HookMessage)(Class, SEL, IMP, IMP *);

static HookMessage SubstrateHook(void) {
    HookMessage hook = (HookMessage)dlsym(RTLD_DEFAULT, "MSHookMessageEx");
    if (hook) return hook;
    const char *paths[] = {
        "/Library/Frameworks/CydiaSubstrate.framework/CydiaSubstrate",
        "/Library/MobileSubstrate/MobileSubstrate.dylib",
    };
    for (size_t i = 0; i < sizeof(paths) / sizeof(paths[0]); i++) {
        void *handle = dlopen(paths[i], RTLD_LAZY);
        if (handle && (hook = (HookMessage)dlsym(handle, "MSHookMessageEx"))) return hook;
    }
    return NULL;
}

__attribute__((constructor)) static void LoadCellularDataSettings(void) {
    @autoreleasepool {
        if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.Preferences"]) return;
        char device[32] = {0}, build[32] = {0};
        size_t length = sizeof(device);
        if (sysctlbyname("hw.machine", device, &length, NULL, 0) || strncmp(device, "iPhone", 6) != 0) return;
        length = sizeof(build);
        if (sysctlbyname("kern.osversion", build, &length, NULL, 0) || strcmp(build, "10B329") != 0) return;

        Class root = NSClassFromString(@"PrefsRootController");
        HookMessage hook = SubstrateHook();
        if (!root || !hook || !class_getInstanceMethod(root, @selector(getAirplaneMode:))) return;

        SEL appear = sel_registerName("viewWillAppear:");
        SEL reload = sel_registerName("reloadSpecifiers");
        SEL foreground = sel_registerName("willEnterForeground");
        SEL airplaneChanged = sel_registerName("airplaneModeChangedExternally");
        SEL setAirplane = sel_registerName("_setAirplaneMode:");
        if (!class_getInstanceMethod(root, appear) || !class_getInstanceMethod(root, reload)) return;
        if (!class_addMethod(root, @selector(cds_readCellularData:), (IMP)ReadData, "@@:@") ||
            !class_addMethod(root, @selector(cds_writeCellularData:specifier:), (IMP)WriteData, "v@:@@")) return;

        hook(root, appear, (IMP)ViewWillAppear, (IMP *)&OriginalViewWillAppear);
        hook(root, reload, (IMP)ReloadSpecifiers, (IMP *)&OriginalReloadSpecifiers);
        if (class_getInstanceMethod(root, foreground)) {
            hook(root, foreground, (IMP)WillEnterForeground, (IMP *)&OriginalWillEnterForeground);
        }
        if (class_getInstanceMethod(root, airplaneChanged)) {
            hook(root, airplaneChanged, (IMP)AirplaneModeChangedExternally, (IMP *)&OriginalAirplaneModeChangedExternally);
        }
        if (class_getInstanceMethod(root, setAirplane)) {
            hook(root, setAirplane, (IMP)SetAirplaneMode, (IMP *)&OriginalSetAirplaneMode);
        }
    }
}
