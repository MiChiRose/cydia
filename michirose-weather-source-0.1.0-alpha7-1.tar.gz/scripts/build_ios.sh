#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${MW_SDKROOT:?Set MW_SDKROOT to a real iPhoneOS6.1.sdk.}"
: "${MW_LDID:?Set MW_LDID to a local ldid executable.}"
: "${MW_LD:?Set MW_LD to a compatible classic ld64 executable.}"
python3 - "$MW_SDKROOT" <<'PYSDK'
import plistlib,sys
from pathlib import Path
settings=plistlib.loads((Path(sys.argv[1])/'SDKSettings.plist').read_bytes())
assert str(settings['Version']) == '6.1', 'Use SDK 6.1: newer SDKs bind NSURL classes to the wrong framework on iOS 6.'
PYSDK
mkdir -p "$ROOT/build"
TLS="$ROOT/build/tls-ios"
MW_TLS_CC="clang -target armv7-apple-ios6.0 -isysroot $MW_SDKROOT" \
  MW_TLS_FLAGS="-fno-common" bash "$ROOT/scripts/build_tls.sh" "$TLS" > "$ROOT/build/tls-ios.log" 2>&1
COMMON=(-target armv7-apple-ios6.0 -isysroot "$MW_SDKROOT" -fno-objc-arc -fblocks -Os
  -Wall -Wextra -Wno-unused-parameter -Werror=unguarded-availability -I"$ROOT/Sources"
  -I"$TLS" -I"$TLS/mbedtls-3.6.7/include" '-DMBEDTLS_CONFIG_FILE="mw_mbedtls_config.h"'
  -fuse-ld="$MW_LD" -framework Foundation -framework CoreFoundation -framework CFNetwork
  -Wl,-no_fixup_chains,-no_adhoc_codesign)
TLSLIBS=("$TLS/mbedtls-3.6.7/library/libmbedtls.a" "$TLS/mbedtls-3.6.7/library/libmbedx509.a" "$TLS/mbedtls-3.6.7/library/libmbedcrypto.a")
clang "${COMMON[@]}" -dynamiclib \
  -Wl,-install_name,/Library/MobileSubstrate/DynamicLibraries/MiChiRoseWeather.dylib \
  "$ROOT/Sources/MWWeatherEngine.m" "$ROOT/Sources/MWWeatherProtocol.m" "$ROOT/Sources/MWHTTPS.m" "${TLSLIBS[@]}" -o "$ROOT/build/MiChiRoseWeather.dylib"
clang "${COMMON[@]}" -DMW_NO_AUTOINSTALL=1 \
  "$ROOT/Sources/MWWeatherEngine.m" "$ROOT/Sources/MWWeatherProtocol.m" "$ROOT/Sources/MWDiagnostics.m" "$ROOT/Tests/probe.m" \
  "$ROOT/Sources/MWHTTPS.m" "${TLSLIBS[@]}" -o "$ROOT/build/michirose-weather-probe"
clang "${COMMON[@]}" "$ROOT/Sources/MWLoadCheck.m" -o "$ROOT/build/michirose-weather-loadcheck"
"$MW_LDID" -Hsha1 -S "$ROOT/build/MiChiRoseWeather.dylib"
"$MW_LDID" -Hsha1 -S "$ROOT/build/michirose-weather-probe"
"$MW_LDID" -Hsha1 -S "$ROOT/build/michirose-weather-loadcheck"
python3 "$ROOT/scripts/check_binary.py" "$ROOT/build/MiChiRoseWeather.dylib" "$ROOT/build/michirose-weather-probe" \
  "$ROOT/build/michirose-weather-loadcheck"
python3 "$ROOT/scripts/package.py"
python3 "$ROOT/Tests/check_deb_layout.py" --current
