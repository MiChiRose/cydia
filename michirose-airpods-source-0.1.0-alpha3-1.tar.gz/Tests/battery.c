#include "BatteryFrame.h"
#include <assert.h>
#include <string.h>
#include <stdio.h>
int main(void){
 const char *valid[]={"AT+IPHONEACCEV=1,1,8","at+iphoneaccev=2,1,0,2,1","AT+IPHONEACCEV=1,2,1"};
 const char *invalid[]={"ATD123","ATA","AT+IPHONEACCEV=1,1,8\r","AT+IPHONEACCEV=1,1,8\r\nATD123","AT+IPHONEACCEV=1,1,","AT+IPHONEACCEV=2,1,8","AT+IPHONEACCEV=1,1,10","AT+IPHONEACCEV=0","AT+IPHONEACCEV=1,3,8","AT+IPHONEACCEV=1,2,2","AT+IPHONEACCEV=99999999999999999999999", "8"};
 for(unsigned i=0;i<sizeof(valid)/sizeof(*valid);i++)assert(MWCompleteBatteryFrame((const uint8_t *)valid[i],strlen(valid[i])));
 for(unsigned i=0;i<sizeof(invalid)/sizeof(*invalid);i++)assert(!MWCompleteBatteryFrame((const uint8_t *)invalid[i],strlen(invalid[i])));
 const char *frame=valid[0];
 for(size_t split=1;split<strlen(frame);split++){
  assert(!MWCompleteBatteryFrame((const uint8_t *)frame,split));
  assert(!MWCompleteBatteryFrame((const uint8_t *)frame+split,strlen(frame)-split));
 }
 assert(!MWCompleteBatteryFrame(NULL,20));
 puts("PASS: complete battery reports accepted; call commands, truncations and every split rejected.");
}
