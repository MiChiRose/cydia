// MIT. Exercise every split of actual accessory grammars and mixed frames.
#include "AccessoryStream.h"
#include <assert.h>
#include <stdio.h>
int main(void) {
 const char *reports[]={"AT+IPHONEACCEV=1,1,8","AT+IPHONEACCEV=2,1,0,2,1","AT+IPHONEACCEV=1,2,1"};
 int parser1=0,parser2=0;
 for(unsigned i=0;i<3;i++) {
  const uint8_t *b=(const uint8_t*)reports[i];size_t n=strlen(reports[i]);
  for(size_t split=1;split<n;split++) {
   MWAccessoryStream s={0};
   assert(!MWAccessoryFeed(&s,&parser1,b,split,false));
   assert(MWAccessoryFeed(&s,&parser1,b+split,n-split,true));
  }
  MWAccessoryStream s={0};
  for(size_t k=0;k<n;k++) assert(MWAccessoryFeed(&s,&parser1,b+k,1,k!=0)==(k==n-1));
 }
 MWAccessoryStream s={0};
 const char *mixed="ATA\rAT+IPHONEACCEV=1,1,8";
 assert(MWAccessoryFeed(&s,&parser1,(const uint8_t*)mixed,strlen(mixed),false));
 MWAccessoryReset(&s,&parser1);
 const char *fragment="AT+IPHONEACCEV=1,1,";
 assert(!MWAccessoryFeed(&s,&parser1,(const uint8_t*)fragment,strlen(fragment),false));
 const char *call="ATD123";
 assert(!MWAccessoryFeed(&s,&parser2,(const uint8_t*)call,strlen(call),false));
 assert(MWAccessoryFeed(&s,&parser1,(const uint8_t*)"8",1,true));
 // New command state, malformed data and explicit terminators cannot splice
 // a previous report into another command or force-close telephone commands.
 assert(!MWAccessoryFeed(&s,&parser1,(const uint8_t*)"8",1,false));
 assert(!MWAccessoryFeed(&s,&parser1,(const uint8_t*)"ATA",3,false));
 const char *closed="AT+IPHONEACCEV=1,1,8\r";
 assert(!MWAccessoryFeed(&s,&parser1,(const uint8_t*)closed,strlen(closed),false));
 uint8_t huge[512];memset(huge,'A',sizeof huge);
 assert(!MWAccessoryFeed(&s,&parser1,huge,sizeof huge,false));
 puts("PASS: dock-only reports, every fragment boundary, bytewise input, mixed frames and parser isolation.");
}
