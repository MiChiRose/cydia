// MIT. Only accept a complete, bounded Apple accessory battery report.
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
static bool MWNumber(const uint8_t *bytes,size_t length,size_t *cursor,unsigned *number) {
    unsigned value=0;size_t start=*cursor;
    while (*cursor<length && bytes[*cursor]>='0' && bytes[*cursor]<='9') {
        value=value*10+bytes[(*cursor)++]-'0';if(value>255)return false;
    }
    *number=value;return *cursor>start;
}
static bool MWCompleteBatteryFrame(const uint8_t *bytes,size_t length) {
    static const char prefix[]="AT+IPHONEACCEV=";
    if(!bytes || length<sizeof(prefix) || length>256)return false;
    for(size_t i=0;i<sizeof(prefix)-1;i++) {
        unsigned char c=bytes[i];if(c>='a' && c<='z')c-=32;
        if(c!=(unsigned char)prefix[i])return false;
    }
    size_t cursor=sizeof(prefix)-1;unsigned pairs=0;
    if(!MWNumber(bytes,length,&cursor,&pairs) || !pairs || pairs>16)return false;
    for(unsigned i=0;i<pairs;i++) {
        unsigned key,value;
        if(cursor>=length || bytes[cursor++]!=',' || !MWNumber(bytes,length,&cursor,&key))return false;
        if(cursor>=length || bytes[cursor++]!=',' || !MWNumber(bytes,length,&cursor,&value))return false;
        if(key==1){if(value>9)return false;}
        else if(key==2){if(value>1)return false;}
        else return false;
    }
    // A dock-only update (key 2) is a valid accessory report too.
    return cursor==length;
}
