// MIT. Service reassertion, not a disconnect/reconnect loop.
#import "ServiceLease.h"
@implementation MWServiceLease
- (void)dealloc { [_device release]; [super dealloc]; }
- (BOOL)updateAt:(NSTimeInterval)now device:(id<MWLeaseDevice>)device eligible:(BOOL)eligible {
    if(!device || ![device connected]) {
        [_device release]; _device=nil; _next=0; return NO;
    }
    if(_device!=device) { [_device release]; _device=[device retain]; _next=now+18; }
    // Pause on route gaps/calls without restarting the deadline on every skip.
    // No service assertion happens until this device is selected again.
    if(!eligible) return NO;
    if(now<_next) return NO;
    _next=now+18;
    unsigned services=[device connectedServices];
    if(!services || ![device connected]) return NO;
    // Reuse exactly the services the OS reports as already connected. No
    // guessed profile bitmask and no -connect/-disconnect fallback.
    [device connectWithServices:services];
    return YES;
}
@end
