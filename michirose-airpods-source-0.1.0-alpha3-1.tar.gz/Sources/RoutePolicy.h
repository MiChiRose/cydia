// MIT. Playback policy shared by the iOS service and deterministic host tests.
#include <stdbool.h>
typedef enum { MWRouteUnknown, MWRouteA2DP, MWRouteBuiltIn, MWRouteOther } MWRouteKind;
typedef struct { bool hadA2DP, interrupted, userPaused; double lastA2DP, interruptedAt; } MWRoutePolicy;
static void MWRouteInterruption(MWRoutePolicy *p,bool began,double now) { p->interrupted=began; p->interruptedAt=now; }
static bool MWRouteAllowed(MWRoutePolicy *p,double now,MWRouteKind route,bool connected,bool call,bool ownsSession) {
    (void)ownsSession;
    if(call || route==MWRouteOther) return false;
    if(!connected) { p->hadA2DP=false; p->userPaused=false; return false; }
    if(route==MWRouteA2DP) p->userPaused=false;
    if(p->userPaused) return false;
    if(p->interrupted) {
        // A connected audio device can recover a lost end notification. The
        // OS still enforces audio-session priority when activation is tried.
        if(now-p->interruptedAt<2) return false;
        p->interrupted=false;
    }
    if(route==MWRouteA2DP) { p->hadA2DP=true; p->lastA2DP=now; return true; }
    // Inactive sessions can report built-in/unknown until real PCM starts.
    // Do not turn activation into a circular prerequisite for audio playback.
    return true;
}
