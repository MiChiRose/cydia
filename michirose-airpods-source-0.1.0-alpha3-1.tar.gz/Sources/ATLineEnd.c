// ATLineEnd: lets BTServer's hands-free AT parser end a command at the end of its RFCOMM frame.
//
// AirPods (Pro 2, firmware 9A348) send every hands-free command with a closing CR except
// AT+IPHONEACCEV, their battery report, which arrives as one frame with no terminator (packet
// captures, 2026-10-27). iOS 6.1.6's parser (BTServer 0xef584, MobileBluetooth-85.10.1) holds a
// command until it sees CR, so it never answers OK. AirPods drop the hands-free channel after 10 s
// without a reply, the iPod reconnects it 10 s later, and after about three rounds they drop the
// iPod altogether, music included; a nearby Mac or iPhone set to connect automatically takes them
// in that gap.
//
// The parser takes (state, bytes, length) once per received frame; state+0xc is 3 while a command
// is half read. A command still open when its frame ends is finished with a CR, which is how the
// AirPods mean it. Every other command they send already ends its frame with CR.

#include <dlfcn.h>
#include <mach-o/dyld.h>
#include <stdint.h>
#include <syslog.h>
#include "Profile.h"
#include "AccessoryStream.h"
#include <pthread.h>
#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

enum {
    kParse = 0xef584,
    kStateOffset = 0xc,
    kInCommand = 3,
};

static int (*orig_parse)(uint8_t *, const uint8_t *, uint32_t);
static MWAccessoryStream gReports;
static pthread_mutex_t gReportsLock=PTHREAD_MUTEX_INITIALIZER;

static void MWATLog(const char *message) {
    syslog(LOG_NOTICE,"AirPodsFix AT: %s",message);
    // BTServer is privileged: log in a root-owned directory, never follow a
    // symlink in mobile's writable preferences/log directory.
    int fd=open("/var/log/AirPodsFix-AT.log",O_WRONLY|O_CREAT|O_APPEND|O_NOFOLLOW,0644);
    if(fd<0) return;
    struct stat info;
    if(fstat(fd,&info) || !S_ISREG(info.st_mode) || info.st_nlink!=1) { close(fd); return; }
    if(info.st_size>8192 && ftruncate(fd,0)) { close(fd); return; }
    FILE *file=fdopen(fd,"a");
    if(!file) { close(fd); return; }
    fprintf(file,"%lld %s\n",(long long)time(NULL),message);fclose(file);
}

static int line_end_parse(uint8_t *state, const uint8_t *bytes, uint32_t length) {
    bool continuing=state && state[kStateOffset]==kInCommand;
    int result = orig_parse(state, bytes, length);
    pthread_mutex_lock(&gReportsLock);
    bool complete=false;
    if(result==0 && state && state[kStateOffset]==kInCommand)
        complete=MWAccessoryFeed(&gReports,state,bytes,length,continuing);
    else MWAccessoryReset(&gReports,state);
    if(complete) MWAccessoryReset(&gReports,state);
    pthread_mutex_unlock(&gReportsLock);
    if (complete) {
        static const uint8_t cr = '\r';
        result = orig_parse(state, &cr, 1);
        MWATLog("completed accessory report (alpha 3)");
    }
    return result;
}

__attribute__((constructor)) static void ATLineEndInit(void) {
    if (!MWProfile()) { MWATLog("unsupported BTServer profile; AT patch disabled"); return; }
    static const uint8_t prologue[] = {
        0xf0, 0xb5, 0x03, 0xaf, 0x2d, 0xe9, 0x00, 0x0d, 0x81, 0xb0, 0x04, 0x46,
        0x00, 0x20, 0xad, 0xf8, 0x00, 0x00, 0x0e, 0x46, 0x21, 0x7b, 0x92, 0x46, 0x05, 0x29,
    };
    intptr_t slide = _dyld_get_image_vmaddr_slide(0);
    const uint8_t *parse = (const uint8_t *)(kParse + slide);
    for (unsigned i = 0; i < sizeof prologue; i++) {
        if (parse[i] == prologue[i]) continue;
        MWATLog("unknown function signature; AT patch disabled");
        return;
    }
    // Substrate loads this dylib before CydiaSubstrate itself, so MSHookFunction is not yet in RTLD_DEFAULT
    void (*hook)(void *, void *, void **) = (void (*)(void *, void *, void **))MWHookFunction();
    if (!hook) { MWATLog("Substrate hook entry unavailable"); return; }
    hook((void *)((uintptr_t)parse | 1), (void *)line_end_parse, (void **)&orig_parse);
    MWATLog(orig_parse ? "AT parser hook loaded (alpha 3)" : "AT parser hook not confirmed");
}
