// MIT. Renew only an existing connection; never reconnect a lost device.
#import <Foundation/Foundation.h>
@protocol MWLeaseDevice <NSObject>
- (BOOL)connected;
- (unsigned)connectedServices;
- (void)connectWithServices:(unsigned)services;
@end
@interface MWServiceLease : NSObject {
    id<MWLeaseDevice> _device;
    NSTimeInterval _next;
}
- (BOOL)updateAt:(NSTimeInterval)now device:(id<MWLeaseDevice>)device eligible:(BOOL)eligible;
@end
