// MIT. Device identities are used transiently for matching, never persisted/logged.
#import "DeviceSelection.h"
static NSString *MWHexIdentity(NSString *text) {
    if(![text isKindOfClass:[NSString class]]) return @"";
    NSMutableString *result=[NSMutableString string];
    for(NSUInteger i=0;i<[text length];i++) {
        unichar c=[text characterAtIndex:i];
        if(c>='a' && c<='f') c-=32;
        if((c>='0' && c<='9') || (c>='A' && c<='F')) [result appendFormat:@"%C",c];
    }
    return result;
}
NSArray *MWConnectedAudioDevices(NSArray *devices) {
    NSMutableArray *audio=[NSMutableArray array];
    for(id<MWConnectedAudioDevice> device in devices)
        if([device respondsToSelector:@selector(connected)] && [device connected] &&
            [device respondsToSelector:@selector(majorClass)] && [device majorClass]==0x400) [audio addObject:device];
    return audio;
}
id<MWConnectedAudioDevice> MWSelectAudioDevice(NSArray *devices,NSString *routeUID,NSString *routeName) {
    NSMutableArray *audio=[NSMutableArray array], *addresses=[NSMutableArray array], *names=[NSMutableArray array];
    NSString *uid=MWHexIdentity(routeUID);
    for(id<MWConnectedAudioDevice> device in MWConnectedAudioDevices(devices)) {
        // Verified iOS 6 majorClass returns the masked CoD bits, not a shifted
        // class number: BTDeviceGetDeviceClass(...) & 0x1f00, audio/video=0x400.
        [audio addObject:device];
        NSString *address=[device respondsToSelector:@selector(address)] ? MWHexIdentity([device address]) : @"";
        NSString *name=[device respondsToSelector:@selector(name)] ? [device name] : nil;
        BOOL sameAddress=[address length]==12 && [uid rangeOfString:address].location!=NSNotFound;
        BOOL sameName=[name length] && [routeName length] && [name caseInsensitiveCompare:routeName]==NSOrderedSame;
        if(sameAddress) [addresses addObject:device];
        if(sameName) [names addObject:device];
    }
    if([addresses count]) return [addresses count]==1 ? [addresses objectAtIndex:0] : nil;
    if([names count]) return [names count]==1 ? [names objectAtIndex:0] : nil;
    return [audio count]==1 ? [audio objectAtIndex:0] : nil;
}
