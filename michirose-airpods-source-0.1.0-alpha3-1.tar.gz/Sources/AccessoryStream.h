// MIT. Reassemble only bounded AT+IPHONEACCEV reports, never call commands.
#include "BatteryFrame.h"
#include <string.h>

typedef struct {
    const void *parser;
    uint8_t bytes[256];
    size_t length;
} MWAccessorySlot;
typedef struct { MWAccessorySlot slots[4]; unsigned replacement; } MWAccessoryStream;

static void MWAccessoryReset(MWAccessoryStream *stream,const void *parser) {
    for (unsigned i=0;i<4;i++) if(stream->slots[i].parser==parser) stream->slots[i].length=0;
}
static bool MWAccessoryFeed(MWAccessoryStream *stream,const void *parser,const uint8_t *bytes,size_t length,bool continuing) {
    if(!parser || !bytes || !length || length>4096) { MWAccessoryReset(stream,parser); return false; }
    MWAccessorySlot *slot=NULL;
    for(unsigned i=0;i<4;i++) if(stream->slots[i].parser==parser) slot=&stream->slots[i];
    if(!slot) { slot=&stream->slots[stream->replacement++%4]; slot->parser=parser; slot->length=0; }
    if(!continuing) slot->length=0;
    // A frame can contain a completed command followed by a new, unterminated
    // report. Only its final command belongs to the parser's open state.
    size_t tail=0;
    for(size_t i=0;i<length;i++) if(bytes[i]=='\r' || bytes[i]=='\n') { tail=i+1; slot->length=0; }
    if(tail==length || length-tail>sizeof(slot->bytes)-slot->length) { slot->length=0; return false; }
    memcpy(slot->bytes+slot->length,bytes+tail,length-tail); slot->length+=length-tail;
    static const char prefix[]="AT+IPHONEACCEV=";
    size_t check=slot->length<sizeof(prefix)-1?slot->length:sizeof(prefix)-1;
    for(size_t i=0;i<check;i++) {
        unsigned c=slot->bytes[i]; if(c>='a' && c<='z') c-=32;
        if(c!=(unsigned char)prefix[i]) { slot->length=0; return false; }
    }
    return MWCompleteBatteryFrame(slot->bytes,slot->length);
}
