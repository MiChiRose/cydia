// MIT. Match the selected route to an already-connected legacy Bluetooth object.
#import <Foundation/Foundation.h>
@protocol MWConnectedAudioDevice <NSObject>
- (BOOL)connected;
- (unsigned)majorClass;
- (NSString *)address;
- (NSString *)name;
@end
NSArray *MWConnectedAudioDevices(NSArray *devices);
id<MWConnectedAudioDevice> MWSelectAudioDevice(NSArray *devices,NSString *routeUID,NSString *routeName);
