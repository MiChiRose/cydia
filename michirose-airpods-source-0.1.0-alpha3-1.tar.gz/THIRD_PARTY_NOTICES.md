# Attribution

Based on [DaneBentley/ios6-airpods-fix](https://github.com/DaneBentley/ios6-airpods-fix),
commit `f64733f8f9b7ed1e1839e30153735d63840b35f6`.
Copyright (c) 2026 Dane Bentley, MIT license, reproduced in LICENSE.
MiChiRose changes: build compatibility, verified-build gating, Substrate path
fallback, narrower battery-command handling and packaging. Those changes are MIT.
This is an independent adaptation, not an official upstream release.


Alpha 2: KeepWarm.m, KeepWarmEngine.h/.m and the silence generation script are
new independent MIT implementations by MiChiRose. The silent-stream approach
is publicly described in:
- https://github.com/asentientbot/ios-6-pods-hack
- https://github.com/mikey820/AirPodsReconnectFix
No code or audio assets from those projects are included. Our silence.mp3 was
encoded from 60 seconds of zero PCM using lameenc 1.8.1 (build-only tool).
The former RTP clock code remains in the source history/archive but is not
part of the Alpha 2 runtime payload.

Alpha 3 adds independently implemented route/interruption recovery, bounded
accessory-report reassembly and a service lease using BluetoothManager's
connectWithServices: for an already-connected device. The 18-second
service-reassertion approach is described by mikey820/AirPodsReconnectFix.
No code from that project is copied; the additions remain MIT.

Alpha 3-1 is an independent passive-audio recovery implementation. The former
BTServer hooks and service-reassertion code are retained as historical source
only; none are compiled or installed. Native notice code uses the legacy
SBAlertItem interface rather than CFUserNotification. No third-party alert
implementation is copied.
