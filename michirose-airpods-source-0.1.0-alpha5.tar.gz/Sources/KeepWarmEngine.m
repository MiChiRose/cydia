// MIT. Do not cancel an accepted player because an asynchronous queue is not
// playing yet. Healthy streams survive track changes without any reset.
#import "KeepWarmEngine.h"
@implementation MWWarmEngine
- (id)initWithBackend:(id<MWWarmBackend>)backend {
    if((self=[super init])) { _backend=[backend retain]; _players=[[NSMutableArray alloc] init]; }
    return self;
}
- (void)dealloc { [self stop]; [_players release]; [_backend release]; [super dealloc]; }
- (void)clearPlayers {
    for(id<MWWarmPlayer> player in _players) [player stop];
    [_players removeAllObjects]; _next=0;
}
- (void)stop { _connected=NO; [self clearPlayers]; }
- (void)setConnected:(BOOL)connected at:(NSTimeInterval)now {
    if(_connected==connected) return;
    _connected=connected;
    if(!connected) { [self clearPlayers]; [_backend record:@"connection ended; silence released"]; }
    else { [_backend record:@"connection event; immediate silence start"]; [self updateAt:now]; }
}
- (void)setCallActive:(BOOL)call at:(NSTimeInterval)now {
    if(_callActive==call) return;
    _callActive=call;
    if(call) { [self clearPlayers]; [_backend record:@"phone call; silence suspended"]; }
    else { [_backend record:@"phone call ended"]; [self updateAt:now]; }
}
- (void)resetAt:(NSTimeInterval)now { [self clearPlayers]; [self updateAt:now]; }
- (void)updateAt:(NSTimeInterval)now {
    if(!_connected || _callActive || now<_next) return;
    id<MWWarmPlayer> player=[_backend startPlayer];
    if(!player) {
        // A failed renewal must not interrupt an older still-running clip.
        _next=now+5; [_backend record:@"silence start declined; bounded retry pending"]; return;
    }
    [_players addObject:player];
    while([_players count]>2) {
        [[_players objectAtIndex:0] stop]; [_players removeObjectAtIndex:0];
    }
    _next=now+50; // Our independently generated MP3 lasts over 60 seconds.
    [_backend record:@"silent clip accepted; overlapping renewal scheduled"];
}
@end
