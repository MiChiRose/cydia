// MIT. iOS 6 SpringBoard alert item; no CFUserNotification/private C ABI.
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import <dispatch/dispatch.h>
#include <syslog.h>

@protocol MWAlertItemMethods <NSObject>
- (id)alertSheet;
- (void)dismiss;
@end
@protocol MWAlertControllerMethods <NSObject>
+ (id)sharedInstance;
- (void)activateAlertItem:(id)item;
@end
static char MWNoticePayloadKey;
static id MWPresentedNotice;

static void MWNoticeClicked(id self,SEL command,id view,NSInteger button) {
    NSDictionary *payload=objc_getAssociatedObject(self,&MWNoticePayloadKey);
    if(button==[[payload objectForKey:@"copyButton"] integerValue]) {
        NSString *report=[payload objectForKey:@"report"];
        if([report length]) [UIPasteboard generalPasteboard].string=report;
    }
    if([self respondsToSelector:@selector(dismiss)]) [(id<MWAlertItemMethods>)self dismiss];
    if(MWPresentedNotice==self) { [MWPresentedNotice release]; MWPresentedNotice=nil; }
}
static void MWNoticeConfigure(id self,SEL command,BOOL configure,BOOL passcode) {
    if(![self respondsToSelector:@selector(alertSheet)]) return;
    id sheet=[(id<MWAlertItemMethods>)self alertSheet];
    if(![sheet isKindOfClass:[UIAlertView class]]) {
        syslog(LOG_NOTICE,"AirPodsFix: unsupported native alert sheet");
        if([self respondsToSelector:@selector(dismiss)]) [(id<MWAlertItemMethods>)self dismiss];
        if(MWPresentedNotice==self) { [MWPresentedNotice release]; MWPresentedNotice=nil; }
        return;
    }
    NSMutableDictionary *payload=objc_getAssociatedObject(self,&MWNoticePayloadKey);
    UIAlertView *alert=sheet;
    alert.title=[payload objectForKey:@"title"];
    alert.message=[payload objectForKey:@"message"];
    alert.delegate=(id<UIAlertViewDelegate>)self;
    alert.cancelButtonIndex=[alert addButtonWithTitle:@"OK"];
    NSInteger copy=-1;
    if([[payload objectForKey:@"report"] length]) {
        BOOL ru=[[[NSLocale preferredLanguages] objectAtIndex:0] hasPrefix:@"ru"];
        copy=[alert addButtonWithTitle:ru ? @"Скопировать отчёт" : @"Copy report"];
    }
    [payload setObject:[NSNumber numberWithInteger:copy] forKey:@"copyButton"];
}

void MWShowAirPodsNotice(NSString *title,NSString *message,NSString *report) {
    dispatch_async(dispatch_get_main_queue(), ^{
        @autoreleasepool {
            if(MWPresentedNotice) { syslog(LOG_NOTICE,"AirPodsFix: native notice already pending"); return; }
            Class base=NSClassFromString(@"SBAlertItem");
            Class controllerClass=NSClassFromString(@"SBAlertItemsController");
            if(!base || !class_getInstanceMethod(base,@selector(alertSheet)) ||
                ![controllerClass respondsToSelector:@selector(sharedInstance)]) {
                syslog(LOG_NOTICE,"AirPodsFix: native alert controller unavailable"); return;
            }
            static Class alertClass;
            if(!alertClass) {
                alertClass=objc_allocateClassPair(base,"MWAirPodsConnectionAlert",0);
                if(!alertClass) return;
                class_addMethod(alertClass,NSSelectorFromString(@"configure:requirePasscodeForActions:"),(IMP)MWNoticeConfigure,"v16@0:4c8c12");
                class_addMethod(alertClass,@selector(alertView:clickedButtonAtIndex:),(IMP)MWNoticeClicked,"v16@0:4@8i12");
                class_addMethod(alertClass,NSSelectorFromString(@"alertSheet:buttonClicked:"),(IMP)MWNoticeClicked,"v16@0:4@8i12");
                objc_registerClassPair(alertClass);
            }
            id<MWAlertControllerMethods> controller=[(id<MWAlertControllerMethods>)controllerClass sharedInstance];
            if(![controller respondsToSelector:@selector(activateAlertItem:)]) return;
            id item=[[[alertClass alloc] init] autorelease];
            NSMutableDictionary *payload=[NSMutableDictionary dictionaryWithObjectsAndKeys:
                title ?: @"AirPods Fix",@"title",message ?: @"",@"message",
                report ?: @"",@"report",@(-1),@"copyButton",nil];
            objc_setAssociatedObject(item,&MWNoticePayloadKey,payload,OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            MWPresentedNotice=[item retain];
            [controller activateAlertItem:item];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW,45*NSEC_PER_SEC),dispatch_get_main_queue(), ^{
                if(MWPresentedNotice==item) {
                    if([item respondsToSelector:@selector(dismiss)]) [(id<MWAlertItemMethods>)item dismiss];
                    [MWPresentedNotice release]; MWPresentedNotice=nil;
                }
            });
            syslog(LOG_NOTICE,"AirPodsFix: native notice submitted");
        }
    });
}
