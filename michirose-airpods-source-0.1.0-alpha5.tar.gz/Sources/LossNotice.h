// MIT. Debounce audible-session connection loss; never assert another host's identity.
#include <stdbool.h>
typedef struct {
    bool stable, armed, losing;
    double stableSince, lossSince, nextAllowed;
} MWLossNotice;
static bool MWLossNoticeUpdate(MWLossNotice *p,double now,bool selected,bool linked,bool music,bool bluetoothOn,bool call) {
    if(!bluetoothOn || call) { p->stable=p->armed=p->losing=false; return false; }
    if(selected && linked) {
        p->losing=false;
        if(!p->stable) { p->stable=true; p->stableSince=now; }
        if(!music) p->armed=false;
        else if(now-p->stableSince>=5) p->armed=true;
        return false;
    }
    p->stable=false;
    if(linked) { p->armed=p->losing=false; return false; } // another output was selected intentionally
    if(!p->armed) return false;
    if(!p->losing) { p->losing=true; p->lossSince=now; }
    if(now-p->lossSince<3) return false;
    bool notify=now>=p->nextAllowed;
    if(notify) p->nextAllowed=now+90;
    p->armed=p->losing=false;
    return notify;
}
