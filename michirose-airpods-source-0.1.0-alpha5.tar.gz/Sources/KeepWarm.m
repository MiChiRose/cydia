// MIT. Independent implementation of the event-driven silent-stream method
// described by ASentientBot's iOS 6 Pods Hack. No upstream code/audio is bundled.
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreTelephony/CTCallCenter.h>
#import <dispatch/dispatch.h>
#include <sys/sysctl.h>
#include <syslog.h>
#include <string.h>
#include <dlfcn.h>
#import "KeepWarmEngine.h"
#include "LossNotice.h"
#include "SilenceData.h"
extern void MWShowAirPodsNotice(NSString *title,NSString *message,NSString *report);

@interface NSObject (MWBluetoothReadOnly)
+ (id)sharedInstance;
- (BOOL)audioConnected;
- (BOOL)enabled;
- (NSArray *)connectedDevices;
- (BOOL)connected;
- (unsigned)majorClass;
@end
@interface AVAudioPlayer (MWContinuousPlayer) <MWWarmPlayer>
@end
@interface MWWarmService : NSObject <MWWarmBackend> {
    MWWarmEngine *_engine;
    CTCallCenter *_calls;
    id _bluetooth;
    NSData *_silence;
    NSMutableArray *_events;
    BOOL _linked, _sawLinkEvent, _bootstrapped, _categoryReady, _lastCall;
    NSTimeInterval _started;
    MWLossNotice _loss;
}
- (void)watchdog;
- (BOOL)configureCategory;
- (void)record:(NSString *)event;
- (NSString *)report;
@end
@implementation MWWarmService
- (id)init {
    if((self=[super init])) {
        _events=[[NSMutableArray alloc] init];
        _calls=[[CTCallCenter alloc] init];
        _silence=[[NSData alloc] initWithBytesNoCopy:(void *)MWQuietMP3 length:sizeof(MWQuietMP3) freeWhenDone:NO];
        _engine=[[MWWarmEngine alloc] initWithBackend:self];
        _started=[NSProcessInfo processInfo].systemUptime;
        NSNotificationCenter *center=[NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(connected:) name:@"BluetoothDeviceConnectSuccessNotification" object:nil];
        [center addObserver:self selector:@selector(disconnected:) name:@"BluetoothDeviceDisconnectSuccessNotification" object:nil];
        [center addObserver:self selector:@selector(powerChanged:) name:@"BluetoothPowerChangedNotification" object:nil];
        [center addObserver:self selector:@selector(mediaReset:) name:AVAudioSessionMediaServicesWereResetNotification object:nil];
        dlopen("/System/Library/PrivateFrameworks/BluetoothManager.framework/BluetoothManager",RTLD_LAZY);
        Class manager=NSClassFromString(@"BluetoothManager");
        if([manager respondsToSelector:@selector(sharedInstance)]) _bluetooth=[[manager sharedInstance] retain];
        [self configureCategory];
        NSTimer *timer=[NSTimer timerWithTimeInterval:2 target:self selector:@selector(watchdog) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
        [self record:@"alpha 5 loaded; event-driven embedded silence; no route commands"];
    }
    return self;
}
- (void)record:(NSString *)event {
    syslog(LOG_NOTICE,"AirPodsFix: %s",[event UTF8String]);
    [_events addObject:[NSString stringWithFormat:@"%@ %@",[NSDate date],event]];
    while([_events count]>64) [_events removeObjectAtIndex:0];
    NSString *folder=@"/var/mobile/Library/Logs";
    [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:NULL];
    [[[_events componentsJoinedByString:@"\n"] stringByAppendingString:@"\n"] writeToFile:[folder stringByAppendingPathComponent:@"AirPodsFix.log"] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}
- (NSString *)report {
    return [NSString stringWithFormat:@"AirPods Fix 0.1.0~alpha5\n%@\nNo device names, addresses or music contents.\n",[_events componentsJoinedByString:@"\n"]];
}
- (void)synchronizeCallAt:(NSTimeInterval)now {
    BOOL call=[_calls.currentCalls count]!=0;
    if(call!=_lastCall) { _lastCall=call; _categoryReady=NO; }
    [_engine setCallActive:call at:now];
}
- (void)connected:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        @try {
            _sawLinkEvent=YES; _linked=YES;
            NSTimeInterval now=[NSProcessInfo processInfo].systemUptime;
            [self synchronizeCallAt:now];
            [_engine setConnected:YES at:now];
        } @catch(NSException *exception) { [self record:@"connection handler failed; no routing action taken"]; }
    });
}
- (void)disconnected:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        _sawLinkEvent=YES; _linked=NO;
        [_engine setConnected:NO at:[NSProcessInfo processInfo].systemUptime];
    });
}
- (void)powerChanged:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        if([_bluetooth respondsToSelector:@selector(enabled)] && ![_bluetooth enabled]) {
            _sawLinkEvent=YES; _linked=NO; memset(&_loss,0,sizeof(_loss));
            [_engine setConnected:NO at:[NSProcessInfo processInfo].systemUptime];
        }
    });
}
- (void)mediaReset:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{
        _categoryReady=NO;
        [self record:@"media services reset"];
        [_engine resetAt:[NSProcessInfo processInfo].systemUptime];
    });
}
- (void)watchdog {
    @try {
        NSTimeInterval now=[NSProcessInfo processInfo].systemUptime;
        [self synchronizeCallAt:now];
        // Bootstrap only once, after observers are registered. A stale manager
        // cache must never cancel a real connection event or revive a lost link.
        if(!_bootstrapped && now-_started>=1) {
            _bootstrapped=YES;
            if(!_sawLinkEvent) {
                BOOL audio=[_bluetooth respondsToSelector:@selector(audioConnected)] && [_bluetooth audioConnected];
                if(!audio && [_bluetooth respondsToSelector:@selector(connectedDevices)])
                    for(id device in [_bluetooth connectedDevices])
                        if([device respondsToSelector:@selector(connected)] && [device connected] &&
                           [device respondsToSelector:@selector(majorClass)] && [device majorClass]==0x400) audio=YES;
                if(audio) { _linked=YES; [_engine setConnected:YES at:now]; }
            }
        }
        [_engine updateAt:now];
        // Route/session state is for a loss notice only. It never gates or
        // resets the stream when a song, player or output changes.
        AVAudioSession *session=[AVAudioSession sharedInstance]; BOOL selected=NO;
        for(AVAudioSessionPortDescription *port in session.currentRoute.outputs)
            if([port.portType isEqualToString:AVAudioSessionPortBluetoothA2DP]) selected=YES;
        BOOL on=![_bluetooth respondsToSelector:@selector(enabled)] || [_bluetooth enabled];
        if(MWLossNoticeUpdate(&_loss,now,selected,_linked,session.otherAudioPlaying,on,_lastCall)) {
            BOOL ru=[[[NSLocale preferredLanguages] objectAtIndex:0] hasPrefix:@"ru"];
            MWShowAirPodsNotice(@"AirPods Fix",ru ? @"Соединение с наушниками потеряно. Возможно, они переключились на другое устройство." : @"The headphones disconnected. They may have switched to another device.",[self report]);
        }
    } @catch(NSException *exception) { [self record:@"watchdog exception; next scheduled check retained"]; }
}
- (BOOL)configureCategory {
    if(_categoryReady) return YES;
    NSError *error=nil;
    _categoryReady=[[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionMixWithOthers error:&error];
    if(!_categoryReady) [self record:[NSString stringWithFormat:@"category setup declined (%@:%ld)",error.domain ?: @"none",(long)error.code]];
    return _categoryReady;
}
- (id<MWWarmPlayer>)startPlayer {
    if(![self configureCategory]) return nil;
    NSError *error=nil;
    AVAudioPlayer *player=[[[AVAudioPlayer alloc] initWithData:_silence error:&error] autorelease];
    if(!player) { [self record:[NSString stringWithFormat:@"embedded audio decode failed (%@:%ld)",error.domain ?: @"none",(long)error.code]]; return nil; }
    // AVAudioPlayer owns queue/session startup, as in the working method.
    // No explicit setActive, prepareToPlay, isPlaying gate or route override.
    if(![player play]) { [self record:@"audio queue declined play"]; return nil; }
    return player;
}
@end
__attribute__((constructor)) static void MWStartContinuity(void) {
    @autoreleasepool {
        if(![[[NSProcessInfo processInfo] processName] isEqualToString:@"SpringBoard"]) return;
        char machine[32]={0},build[32]={0};size_t length=sizeof(machine);
        if(sysctlbyname("hw.machine",machine,&length,NULL,0)) return;
        length=sizeof(build);
        if(sysctlbyname("kern.osversion",build,&length,NULL,0) || strcmp(build,"10B329")) return;
        if(strcmp(machine,"iPhone4,1") && strcmp(machine,"iPhone5,1") && strcmp(machine,"iPhone5,2")) return;
        dispatch_async(dispatch_get_main_queue(), ^{
            static MWWarmService *service;
            service=[[MWWarmService alloc] init]; (void)service;
        });
    }
}
