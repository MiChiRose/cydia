// MIT. Continuous silent audio lifecycle, independent of audio-session activation.
#import <Foundation/Foundation.h>
@protocol MWWarmPlayer <NSObject>
- (void)stop;
@end
@protocol MWWarmBackend <NSObject>
- (id<MWWarmPlayer>)startPlayer;
- (void)record:(NSString *)event;
@end
@interface MWWarmEngine : NSObject {
    id<MWWarmBackend> _backend;
    NSMutableArray *_players;
    BOOL _connected, _callActive;
    NSTimeInterval _next;
}
- (id)initWithBackend:(id<MWWarmBackend>)backend;
- (void)setConnected:(BOOL)connected at:(NSTimeInterval)now;
- (void)setCallActive:(BOOL)call at:(NSTimeInterval)now;
- (void)updateAt:(NSTimeInterval)now;
- (void)resetAt:(NSTimeInterval)now;
- (void)stop;
@end
