#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${MW_SDKROOT:?Use iPhoneOS6.1.sdk}"
: "${MW_LD:?Use classic ld64}"
: "${MW_LDID:?Use ldid with SHA1 signing}"
if [ -n "${MW_BUILD_DIR:-}" ]; then
    BUILD="$MW_BUILD_DIR"
    mkdir -p "$BUILD"
else
    BUILD="$(mktemp -d "${TMPDIR:-/tmp}/airpods-build.XXXXXX")"
    trap 'rm -rf "$BUILD"' EXIT
fi
python3 - "$ROOT/Resources/silence.mp3" "$BUILD/SilenceData.h" <<'EMBED'
from pathlib import Path
import sys
payload=Path(sys.argv[1]).read_bytes()
assert len(payload)>1000
Path(sys.argv[2]).write_text('static const unsigned char MWQuietMP3[] = {\n'+
    '\n'.join(','.join('0x%02x'%b for b in payload[i:i+16])+',' for i in range(0,len(payload),16))+'\n};\n')
EMBED
clang -target armv7-apple-ios6.0 -marm -isysroot "$MW_SDKROOT" -dynamiclib -O2 \
    -fno-objc-arc -fblocks -Wall -Wextra -Wno-unused-parameter -Werror=unguarded-availability \
    -fuse-ld="$MW_LD" -Wl,-no_fixup_chains,-no_adhoc_codesign -I "$BUILD" \
    -framework Foundation -framework AVFoundation -framework CoreTelephony \
    -framework CoreFoundation -framework UIKit \
    "$ROOT/Sources/KeepWarm.m" "$ROOT/Sources/KeepWarmEngine.m" \
    "$ROOT/Sources/LossNotification.m" -o "$BUILD/KeepWarm.dylib"
"$MW_LDID" -Hsha1 -S "$BUILD/KeepWarm.dylib"
python3 "$ROOT/scripts/check_binary.py" "$BUILD/KeepWarm.dylib"
MW_BUILD_DIR="$BUILD" python3 "$ROOT/scripts/package.py"
