// MIT. Test the production lifecycle with asynchronous fake audio players.
#import <Foundation/Foundation.h>
#import "KeepWarmEngine.h"
#include "LossNotice.h"
#include <assert.h>
static double clockNow;
@interface FakePlayer : NSObject <MWWarmPlayer> { @public double born,delay; BOOL stopped; }
- (BOOL)audibleQueueRunning;
@end
@implementation FakePlayer
- (void)stop { stopped=YES; }
- (BOOL)audibleQueueRunning { return !stopped && clockNow>=born+delay && clockNow<born+60; }
@end
@interface FakeBackend : NSObject <MWWarmBackend> {
@public NSMutableArray *created; unsigned attempts; BOOL decline; double startupDelay;
}
- (NSUInteger)running;
@end
@implementation FakeBackend
- (id)init { if((self=[super init])) created=[[NSMutableArray alloc] init];return self; }
- (void)dealloc { [created release];[super dealloc]; }
- (id<MWWarmPlayer>)startPlayer {
    attempts++;if(decline)return nil;
    FakePlayer *player=[[[FakePlayer alloc] init] autorelease];
    player->born=clockNow;player->delay=startupDelay;[created addObject:player];return player;
}
- (void)record:(NSString *)event { (void)event; }
- (NSUInteger)running { NSUInteger n=0;for(FakePlayer *p in created)if([p audibleQueueRunning])n++;return n; }
@end
static void Tick(MWWarmEngine *engine,double now) { clockNow=now;[engine updateAt:now]; }
static void NoticeTest(void) {
 MWLossNotice p={0};
 assert(!MWLossNoticeUpdate(&p,0,YES,YES,YES,YES,NO));
 assert(!MWLossNoticeUpdate(&p,5,YES,YES,YES,YES,NO));
 assert(!MWLossNoticeUpdate(&p,10,NO,NO,NO,YES,NO));
 assert(!MWLossNoticeUpdate(&p,12,YES,YES,YES,YES,NO)); // brief drop recovers silently
 assert(!MWLossNoticeUpdate(&p,17,YES,YES,YES,YES,NO));
 assert(!MWLossNoticeUpdate(&p,18,NO,NO,NO,YES,NO));
 assert(MWLossNoticeUpdate(&p,21,NO,NO,NO,YES,NO));
 assert(!MWLossNoticeUpdate(&p,22,NO,NO,NO,YES,NO)); // one notice per loss
 MWLossNoticeUpdate(&p,23,YES,YES,YES,YES,NO);
 MWLossNoticeUpdate(&p,28,YES,YES,YES,YES,NO);
 MWLossNoticeUpdate(&p,29,NO,NO,NO,YES,NO);
 assert(!MWLossNoticeUpdate(&p,40,NO,NO,NO,YES,NO)); // global cooldown
 assert(!MWLossNoticeUpdate(&p,111,NO,NO,NO,YES,NO)); // no delayed stale notice after cooldown
 assert(!MWLossNoticeUpdate(&p,111,NO,NO,NO,NO,NO)); // Bluetooth disabled: cancel
 MWLossNoticeUpdate(&p,120,YES,YES,YES,YES,NO);
 MWLossNoticeUpdate(&p,125,YES,YES,YES,YES,NO);
 assert(!MWLossNoticeUpdate(&p,126,NO,NO,NO,YES,YES)); // call: cancel
 MWLossNoticeUpdate(&p,130,YES,YES,NO,YES,NO);
 assert(!MWLossNoticeUpdate(&p,140,NO,NO,NO,YES,NO)); // no user music
}
int main(void) { @autoreleasepool {
 NoticeTest();
 FakeBackend *audio=[[[FakeBackend alloc] init] autorelease];audio->startupDelay=1.5;
 MWWarmEngine *loop=[[[MWWarmEngine alloc] initWithBackend:audio] autorelease];
 Tick(loop,0);assert(audio->attempts==0);
 // A connection event starts immediately, before the next watchdog tick.
 clockNow=0.2;[loop setConnected:YES at:clockNow];assert(audio->attempts==1 && !audio.running);
 FakePlayer *first=[audio->created objectAtIndex:0];assert(!first->stopped);
 Tick(loop,1);assert(audio->attempts==1 && !first->stopped);
 [loop setConnected:YES at:1];assert(audio->attempts==1); // duplicate event
 // Overlap keeps queues running through many track gaps and clip boundaries.
 for(int t=2;t<=600;t+=2) { Tick(loop,t);assert(audio.running>=1 && audio.running<=2); }
 [loop setConnected:NO at:600];assert(!audio.running);
 unsigned before=audio->attempts;
 Tick(loop,650);assert(audio->attempts==before);
 clockNow=700;[loop setConnected:YES at:clockNow];assert(audio->attempts==before+1);
 Tick(loop,702);assert(audio.running==1);
 // Renewal refusal preserves the preceding clip and retries in five seconds.
 audio->decline=YES;Tick(loop,750);assert(audio.running==1);
 before=audio->attempts;Tick(loop,752);assert(audio->attempts==before && audio.running==1);
 audio->decline=NO;Tick(loop,756);assert(audio.running==1);
 Tick(loop,758);assert(audio.running==2);
 Tick(loop,762);assert(audio.running==1);
 // A real phone call suspends just our silence; its end restarts immediately.
 clockNow=764;[loop setCallActive:YES at:clockNow];assert(!audio.running);
 before=audio->attempts;Tick(loop,900);assert(audio->attempts==before);
 clockNow=901;[loop setCallActive:NO at:clockNow];assert(audio->attempts==before+1);
 Tick(loop,903);assert(audio.running==1);
 // Connecting during a call must not start audio until the call ends.
 [loop setConnected:NO at:903];[loop setCallActive:YES at:903];
 clockNow=904;before=audio->attempts;[loop setConnected:YES at:904];assert(audio->attempts==before);
 clockNow=906;[loop setCallActive:NO at:906];assert(audio->attempts==before+1);
 Tick(loop,908);assert(audio.running==1);
 // A media-server reset creates a fresh queue, not a route-selection command.
 clockNow=910;before=audio->attempts;[loop resetAt:910];assert(audio->attempts==before+1);
 Tick(loop,912);assert(audio.running==1);
 [loop stop];assert(!audio.running);
 // A declined initial start is retried without a crash or a tight retry loop.
 audio->decline=YES;clockNow=1000;[loop setConnected:YES at:1000];before=audio->attempts;
 Tick(loop,1002);assert(audio->attempts==before);
 audio->decline=NO;Tick(loop,1006);assert(audio->attempts==before+1);
 Tick(loop,1008);assert(audio.running==1);
 [loop stop];
 puts("PASS: immediate connection start, asynchronous startup, ten-minute overlap, renewal failure, disconnect, calls, media reset and loss notice limits.");
} }
