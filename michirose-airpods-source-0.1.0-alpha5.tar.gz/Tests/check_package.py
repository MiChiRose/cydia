#!/usr/bin/env python3
"""Check the shipped audio lifecycle/packaging contract, not build arguments."""
from pathlib import Path
import hashlib, io, plistlib, subprocess, sys, tarfile
root=Path(__file__).resolve().parents[1]
data=Path(sys.argv[1]).read_bytes()
assert data[:8]==b'!<arch>\n'
pos=8; archives={}
while pos<len(data):
    header=data[pos:pos+60]; size=int(header[48:58])
    archives[header[:16].decode().strip().rstrip('/')]=data[pos+60:pos+60+size]
    pos+=60+size+size%2
with tarfile.open(fileobj=io.BytesIO(archives['control.tar.gz'])) as control:
    text=control.extractfile('./control').read().decode()
    assert 'Conflicts: com.danebentley.ios6airpodsfix, ios-6-pods-hack' in text
    assert 'Package: com.michirose.airpodsfix' in text
    assert 'finish:reboot' in control.extractfile('./postinst').read().decode()
with tarfile.open(fileobj=io.BytesIO(archives['data.tar.gz'])) as payload:
    files=[m.name for m in payload if m.isfile()]
    dylibs=[n for n in files if n.endswith('.dylib')]
    assert dylibs==['./Library/MobileSubstrate/DynamicLibraries/MiChiRoseAirPodsWarm.dylib'],dylibs
    assert not any('.app/' in n or n.endswith('.mp3') for n in files)
    binary=payload.extractfile(dylibs[0]).read()
    assert binary.count((root/'Resources/silence.mp3').read_bytes())==1
    for selector in [b'BluetoothDeviceConnectSuccessNotification',b'BluetoothDeviceDisconnectSuccessNotification',b'initWithData:error:']:
        assert selector in binary,selector
    for forbidden in [b'setActive:',b'setActive:withOptions:error:',b'setActive:error:',b'isPlaying',b'prepareToPlay',b'_pickRoute:',b'connectWithServices:',b'MSHookFunction',b'CFUserNotificationDisplayNotice',b'SBMediaNowPlayingChangedNotification']:
        assert forbidden not in binary,forbidden
    plist='./Library/MobileSubstrate/DynamicLibraries/MiChiRoseAirPodsWarm.plist'
    assert payload.extractfile(plist).read()==(root/'packaging/MiChiRoseAirPodsWarm.plist').read_bytes()
    xml=subprocess.check_output(['plutil','-convert','xml1','-o','-',str(root/'packaging/MiChiRoseAirPodsWarm.plist')])
    assert plistlib.loads(xml)['Filter']['Executables']==['SpringBoard']
    source=payload.extractfile('./usr/share/doc/com.michirose.airpodsfix/source.tar.gz').read()
    with tarfile.open(fileobj=io.BytesIO(source)) as snapshot:
        count=0
        for m in snapshot:
            if not m.isfile():continue
            p=Path(m.name)
            assert not p.is_absolute() and '..' not in p.parts
            assert snapshot.extractfile(m).read()==(root/p).read_bytes(),m.name
            count+=1
print('PASS: one SpringBoard dylib, embedded independent audio, conflict metadata, reboot finish button, no forced activation/routing, exact current source snapshot (%d files).'%count)
