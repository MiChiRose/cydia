# Attribution and provenance

The silent-stream workaround is documented by ASentientBot:
https://github.com/asentientbot/ios-6-pods-hack
Reference release v2, source commit e63b74b.
Original release DEB SHA-256:
f20aa53a27574d48877ce7251b6fbd7f269a9a105e8a9ce9895b14b548908b1b

Alpha 5 independently implements connection-event startup and overlapping
silent clips. No ASentientBot source, released binary or third-party audio is
redistributed. The original repository has no license file; this package does
not describe that project or its contents as MIT-licensed. Credit concerns the
published method, not authorship of this independent implementation.

Our 60.192-second, 8000 Hz mono MP3 is generated from zero PCM with lameenc
1.8.1 at 8 kbit/s. The encoder is a build-only tool and is not bundled.
No Anar Software blank-audio file is included. Our generated MP3 decodes to
all-zero PCM. Our implementation is MIT, see LICENSE.

Earlier package versions experimented with DaneBentley/ios6-airpods-fix (MIT),
as well as independent adaptations of methods described by
asentientbot/ios-6-pods-hack and mikey820/AirPodsReconnectFix. The earlier RTP,
AT, Bluetooth service-lease and route-refresh implementations are now retained
only in Git history. No code or audio from the latter two repositories is
included. Dane Bentley's historical copyright notice is retained in LICENSE.
