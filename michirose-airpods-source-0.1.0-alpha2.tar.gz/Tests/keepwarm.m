// MIT. Exercise the production renewal/stop/retry state machine without audio hardware.
#import <Foundation/Foundation.h>
#import "KeepWarmEngine.h"
#include <assert.h>
static double clockNow;
@interface TestPlayer : NSObject <MWWarmPlayer> { @public double started; BOOL stopped; }
@end
@implementation TestPlayer
- (BOOL)isPlaying { return !stopped && clockNow < started + 60; }
- (void)stop { stopped = YES; }
@end
@interface TestAudio : NSObject <MWWarmBackend> {
@public NSMutableArray *created; BOOL failActivation, failPlayer, active; unsigned starts, activations, deactivations;
}
@end
@implementation TestAudio
- (id)init { if ((self=[super init])) created=[[NSMutableArray alloc] init]; return self; }
- (void)dealloc { [created release]; [super dealloc]; }
- (BOOL)activate { activations++; active=!failActivation; return active; }
- (void)deactivate { deactivations++; active=NO; }
- (id<MWWarmPlayer>)startPlayer {
    starts++; if(failPlayer) return nil;
    TestPlayer *p=[[[TestPlayer alloc] init] autorelease]; p->started=clockNow; [created addObject:p]; return p;
}
- (void)record:(NSString *)event { }
- (NSUInteger)playing {
    NSUInteger n=0; for(TestPlayer *p in created) if(p.isPlaying)n++; return n;
}
@end
static void Tick(MWWarmEngine *engine,double time,BOOL allowed) { clockNow=time; [engine updateAt:time allowed:allowed]; }
int main(void) { @autoreleasepool {
    TestAudio *audio=[[[TestAudio alloc] init] autorelease];
    MWWarmEngine *engine=[[[MWWarmEngine alloc] initWithBackend:audio] autorelease];
    Tick(engine,0,NO); assert(audio->activations==0 && audio.playing==0);
    // Two-second watchdog over ten minutes, including many 60-second clip ends.
    for(unsigned t=0;t<=600;t+=2) {
        Tick(engine,t,YES);
        assert(audio->active && audio.playing>=1 && audio.playing<=2);
    }
    // Leaving A2DP, an interruption, or a call must stop all players promptly.
    Tick(engine,602,NO); assert(!audio->active && audio.playing==0);
    unsigned before=audio->starts;
    Tick(engine,604,NO); assert(audio->starts==before);
    Tick(engine,606,YES); assert(audio->active && audio.playing==1);
    // Renewal failure must preserve the older clip and recover during overlap.
    audio->failPlayer=YES;
    Tick(engine,651,YES); assert(audio.playing==1);
    before=audio->starts;
    Tick(engine,652,YES); assert(audio->starts==before);
    audio->failPlayer=NO;
    Tick(engine,656,YES); assert(audio.playing==2);
    Tick(engine,666.1,YES); assert(audio.playing==1);
    // Total player failure relinquishes the session, then retries at a bound.
    Tick(engine,668,NO); audio->failPlayer=YES;
    Tick(engine,670,YES); assert(!audio->active && audio.playing==0);
    before=audio->activations;
    Tick(engine,672,YES); assert(audio->activations==before);
    audio->failPlayer=NO;
    Tick(engine,675,YES); assert(audio->active && audio.playing==1);
    Tick(engine,676,NO); audio->failActivation=YES;
    Tick(engine,678,YES); assert(!audio->active && audio.playing==0);
    before=audio->activations;
    Tick(engine,680,YES); assert(audio->activations==before);
    audio->failActivation=NO;
    Tick(engine,688,YES); assert(audio->active && audio.playing==1);
    [engine stop]; assert(audio.playing==0 && !audio->active);
    puts("PASS: ten-minute gapless renewal, bounded players, route/call stop, recovery and retry limits.");
} }
