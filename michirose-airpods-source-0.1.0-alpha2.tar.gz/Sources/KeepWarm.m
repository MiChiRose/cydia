// MIT. Independent implementation of continuous silent A2DP playback.
// The approach is documented by asentientbot/ios-6-pods-hack and
// mikey820/AirPodsReconnectFix; no source/audio assets from them are included.
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreTelephony/CTCallCenter.h>
#import <dispatch/dispatch.h>
#include <sys/sysctl.h>
#include <syslog.h>
#include <string.h>
#import "KeepWarmEngine.h"

@interface AVAudioPlayer (MWWarmPlayer) <MWWarmPlayer>
@end

@interface MWWarmService : NSObject <MWWarmBackend> {
    MWWarmEngine *_engine;
    CTCallCenter *_calls;
    BOOL _interrupted, _evaluating, _ownsSession;
    NSString *_previousCategory;
    NSMutableArray *_events;
    AVAudioSessionCategoryOptions _previousOptions;
}
- (void)evaluate;
@end

@implementation MWWarmService
- (id)init {
    if ((self = [super init])) {
        _events = [[NSMutableArray alloc] init];
        _calls = [[CTCallCenter alloc] init];
        _engine = [[MWWarmEngine alloc] initWithBackend:self];
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(routeChanged:) name:AVAudioSessionRouteChangeNotification object:nil];
        [center addObserver:self selector:@selector(interruption:) name:AVAudioSessionInterruptionNotification object:nil];
        [center addObserver:self selector:@selector(reset:) name:AVAudioSessionMediaServicesWereResetNotification object:nil];
        // SpringBoard remains alive while locked; common modes cover UI tracking.
        NSTimer *timer = [NSTimer timerWithTimeInterval:2 target:self selector:@selector(evaluate) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
        [self record:@"route protection loaded (alpha 2)"];
        [self evaluate];
    }
    return self;
}
- (void)record:(NSString *)event {
    syslog(LOG_NOTICE, "AirPodsFix: %s", [event UTF8String]);
    [_events addObject:[NSString stringWithFormat:@"%@ %@", [NSDate date], event]];
    while ([_events count] > 64) [_events removeObjectAtIndex:0];
    NSString *folder = @"/var/mobile/Library/Logs";
    [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:NULL];
    [[[_events componentsJoinedByString:@"\n"] stringByAppendingString:@"\n"]
        writeToFile:[folder stringByAppendingPathComponent:@"AirPodsFix.log"] atomically:YES encoding:NSUTF8StringEncoding error:NULL];
}
- (void)evaluate {
    if (_evaluating) return;
    _evaluating = YES;
    @try {
        BOOL a2dp = NO;
        AVAudioSession *session = [AVAudioSession sharedInstance];
        for (AVAudioSessionPortDescription *port in session.currentRoute.outputs)
            if ([port.portType isEqualToString:AVAudioSessionPortBluetoothA2DP]) a2dp = YES;
        // Do not contend with telephony/HFP or an audio-session interruption.
        BOOL allowed = a2dp && !_interrupted && ![_calls.currentCalls count];
        [_engine updateAt:[NSProcessInfo processInfo].systemUptime allowed:allowed];
    } @catch (NSException *exception) {
        [_engine stop];
        [self record:@"route protection stopped after exception"];
    } @finally { _evaluating = NO; }
}
- (void)routeChanged:(NSNotification *)note {
    // Route callbacks may originate outside the main thread. All state and
    // player transitions are serialized on the main run loop.
    dispatch_async(dispatch_get_main_queue(), ^{ [self evaluate]; });
}
- (void)interruption:(NSNotification *)note {
    BOOL began = [[note.userInfo objectForKey:AVAudioSessionInterruptionTypeKey] unsignedIntegerValue] == AVAudioSessionInterruptionTypeBegan;
    dispatch_async(dispatch_get_main_queue(), ^{
        _interrupted = began;
        if (began) [_engine stop];
        else [self evaluate];
    });
}
- (void)reset:(NSNotification *)note {
    dispatch_async(dispatch_get_main_queue(), ^{ [_engine stop]; _interrupted = NO; [self evaluate]; });
}
- (BOOL)activate {
    AVAudioSession *session = [AVAudioSession sharedInstance];
    [_previousCategory release]; _previousCategory = [session.category copy];
    _previousOptions = session.categoryOptions;
    NSError *error = nil;
    if (![session setCategory:AVAudioSessionCategoryPlayback withOptions:AVAudioSessionCategoryOptionMixWithOthers error:&error]) {
        [self record:[NSString stringWithFormat:@"session category failed (%@:%ld)", error.domain, (long)error.code]];
        return NO;
    }
    if (![session setActive:YES error:&error]) {
        if (_previousCategory) [session setCategory:_previousCategory withOptions:_previousOptions error:NULL];
        [self record:[NSString stringWithFormat:@"session activation failed (%@:%ld)", error.domain, (long)error.code]];
        return NO;
    }
    _ownsSession = YES;
    return YES;
}
- (void)deactivate {
    if (!_ownsSession) return;
    _ownsSession = NO;
    AVAudioSession *session = [AVAudioSession sharedInstance];
    // Restore only a category we still own, respecting a change made elsewhere.
    if ([session.category isEqualToString:AVAudioSessionCategoryPlayback] &&
        session.categoryOptions == AVAudioSessionCategoryOptionMixWithOthers) {
        [session setActive:NO withOptions:AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation error:NULL];
        if (_previousCategory) [session setCategory:_previousCategory withOptions:_previousOptions error:NULL];
    }
}
- (id<MWWarmPlayer>)startPlayer {
    NSError *error = nil;
    NSURL *url = [NSURL fileURLWithPath:@"/Library/Application Support/AirPodsFix/silence.mp3"];
    AVAudioPlayer *player = [[[AVAudioPlayer alloc] initWithContentsOfURL:url error:&error] autorelease];
    if (!player || player.duration < 59 || ![player prepareToPlay] || ![player play]) {
        [player stop];
        [self record:[NSString stringWithFormat:@"silent audio failed (%@:%ld)", error.domain, (long)error.code]];
        return nil;
    }
    return player;
}
@end

__attribute__((constructor)) static void MWWarmInit(void) {
    @autoreleasepool {
        if (![[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@"com.apple.springboard"]) return;
        char machine[32] = {0}, build[32] = {0}; size_t size = sizeof machine;
        if (sysctlbyname("hw.machine", machine, &size, NULL, 0)) return;
        size = sizeof build;
        if (sysctlbyname("kern.osversion", build, &size, NULL, 0) || strcmp(build, "10B329")) return;
        if (strcmp(machine,"iPhone4,1") && strcmp(machine,"iPhone5,1") && strcmp(machine,"iPhone5,2")) return;
        dispatch_async(dispatch_get_main_queue(), ^{
            static MWWarmService *service;
            service = [[MWWarmService alloc] init]; // process-lifetime service
            (void)service;
        });
    }
}
