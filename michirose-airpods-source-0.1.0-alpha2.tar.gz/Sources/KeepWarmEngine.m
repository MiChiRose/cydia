// MIT. MiChiRose AirPods Fix. No Bluetooth addresses, device names or audio
// belonging to the user are inspected or recorded.
#import "KeepWarmEngine.h"

@implementation MWWarmEngine
- (id)initWithBackend:(id<MWWarmBackend>)backend {
    if ((self = [super init])) { _backend = [backend retain]; _players = [[NSMutableArray alloc] init]; }
    return self;
}
- (void)dealloc { [self stop]; [_players release]; [_backend release]; [super dealloc]; }
- (void)stop {
    for (id<MWWarmPlayer> player in _players) [player stop];
    [_players removeAllObjects];
    if (_active) { [_backend deactivate]; [_backend record:@"warm stopped"]; }
    _active = NO;
    _renewAt = _retryAt = 0;
}
- (void)updateAt:(NSTimeInterval)now allowed:(BOOL)allowed {
    if (!allowed) { [self stop]; return; }
    if (now < _retryAt) return;
    if (!_active) {
        if (![_backend activate]) { _retryAt = now + 10; return; }
        _active = YES;
    }
    for (id<MWWarmPlayer> player in [[_players copy] autorelease])
        if (![player isPlaying]) [_players removeObjectIdenticalTo:player];
    if ([_players count] && now < _renewAt) return;
    id<MWWarmPlayer> player = [_backend startPlayer];
    if (!player || ![player isPlaying]) {
        [player stop];
        // Preserve an older, still-playing clip if renewal fails. Retry well
        // before its end; never claim that silence is playing when it isn't.
        if (![_players count]) [self stop];
        _retryAt = now + 5;
        [_backend record:@"warm player failed; retry pending"];
        return;
    }
    [_players addObject:player];
    while ([_players count] > 2) {
        [(id<MWWarmPlayer>)[_players objectAtIndex:0] stop];
        [_players removeObjectAtIndex:0];
    }
    _renewAt = now + 45; // 60-second clips overlap by at least 15 seconds.
    _retryAt = 0;
    [_backend record:@"warm player started"];
}
@end
