// MIT. MiChiRose additions to Dane Bentley's iOS 6 AirPods fix.
#include <mach-o/loader.h>
#include <mach-o/dyld.h>
#include <mach/vm_prot.h>
#include <sys/sysctl.h>
#include <string.h>
#include <stdbool.h>

static bool MWProfile(void) {
    char machine[32]={0},build[32]={0}; size_t size=sizeof machine;
    if (sysctlbyname("hw.machine",machine,&size,NULL,0)) return false;
    size=sizeof build;
    if (sysctlbyname("kern.osversion",build,&size,NULL,0) || strcmp(build,"10B329")) return false;
    if (strcmp(machine,"iPhone4,1") && strcmp(machine,"iPhone5,1") && strcmp(machine,"iPhone5,2")) return false;
    const struct mach_header *header=_dyld_get_image_header(0);
    if (!header || header->magic!=MH_MAGIC || header->cputype!=CPU_TYPE_ARM || header->filetype!=MH_EXECUTE || header->ncmds>128 || header->sizeofcmds>65536) return false;
    const char *name=_dyld_get_image_name(0),*leaf=name?strrchr(name,'/'):NULL;
    if (!leaf || strcmp(leaf+1,"BTServer")) return false;
    static const unsigned char uuid[16]={0xaf,0x01,0x50,0xd5,0x08,0x5e,0x32,0x65,0x98,0xed,0xff,0x07,0x2a,0x23,0xd1,0x46};
    const unsigned char *cursor=(const unsigned char *)(header+1),*end=cursor+header->sizeofcmds;
    bool identity=false,data=false;
    for (uint32_t i=0;i<header->ncmds;i++) {
        if ((size_t)(end-cursor)<sizeof(struct load_command)) return false;
        const struct load_command *command=(const struct load_command *)cursor;
        if (command->cmdsize<sizeof(*command) || command->cmdsize>(size_t)(end-cursor)) return false;
        if (command->cmd==LC_UUID && command->cmdsize==sizeof(struct uuid_command)) identity=!memcmp(((const struct uuid_command *)command)->uuid,uuid,16);
        if (command->cmd==LC_SEGMENT && command->cmdsize>=sizeof(struct segment_command)) {
            const struct segment_command *segment=(const struct segment_command *)command;
            if (!strncmp(segment->segname,"__DATA",16) && (segment->initprot&VM_PROT_WRITE) && segment->vmaddr<=0x15c7c4 && (uint64_t)segment->vmaddr+segment->vmsize>=0x15c7c8) data=true;
        }
        cursor+=command->cmdsize;
    }
    return cursor==end && identity && data;
}

static void *MWHookFunction(void) {
    void *hook=dlsym(RTLD_DEFAULT,"MSHookFunction");
    const char *paths[]={"/Library/Frameworks/CydiaSubstrate.framework/CydiaSubstrate","/Library/MobileSubstrate/MobileSubstrate.dylib"};
    for (unsigned i=0;!hook && i<2;i++) {
        void *handle=dlopen(paths[i],RTLD_NOW|RTLD_GLOBAL);
        if (handle) hook=dlsym(handle,"MSHookFunction");
    }
    return hook;
}
