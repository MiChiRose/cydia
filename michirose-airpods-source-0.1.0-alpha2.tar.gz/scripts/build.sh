#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${MW_SDKROOT:?Use iPhoneOS6.1.sdk}"
: "${MW_LD:?Use classic ld64}"
: "${MW_LDID:?Use ldid with SHA1 signing}"
mkdir -p "$ROOT/build"
for name in ATLineEnd; do
    clang -target armv7-apple-ios6.0 -marm -isysroot "$MW_SDKROOT" -dynamiclib -O2 \
        -Wall -Wextra -Wno-unused-parameter -Werror=unguarded-availability \
        -fuse-ld="$MW_LD" -Wl,-no_fixup_chains,-no_adhoc_codesign \
        "$ROOT/Sources/$name.c" -o "$ROOT/build/$name.dylib"
    "$MW_LDID" -Hsha1 -S "$ROOT/build/$name.dylib"
done
clang -target armv7-apple-ios6.0 -marm -isysroot "$MW_SDKROOT" -dynamiclib -O2 \
    -fno-objc-arc -fblocks -Wall -Wextra -Wno-unused-parameter -Werror=unguarded-availability \
    -fuse-ld="$MW_LD" -Wl,-no_fixup_chains,-no_adhoc_codesign \
    -framework Foundation -framework AVFoundation -framework CoreTelephony \
    "$ROOT/Sources/KeepWarm.m" "$ROOT/Sources/KeepWarmEngine.m" -o "$ROOT/build/KeepWarm.dylib"
"$MW_LDID" -Hsha1 -S "$ROOT/build/KeepWarm.dylib"
python3 "$ROOT/scripts/check_binary.py" "$ROOT/build/KeepWarm.dylib" "$ROOT/build/ATLineEnd.dylib"
python3 "$ROOT/scripts/package.py"
