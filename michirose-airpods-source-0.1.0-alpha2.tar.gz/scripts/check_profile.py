#!/usr/bin/env python3
"""Inspect a locally supplied BTServer. Apple binaries are never redistributed."""
import hashlib,struct,sys,uuid
from pathlib import Path
d=Path(sys.argv[1]).read_bytes()
magic,cpu,subtype,kind,count,size,_=struct.unpack_from('<7I',d)
assert magic==0xfeedface and cpu==12 and kind==2
cursor=28;segments=[];identity=None
for _ in range(count):
    command,length=struct.unpack_from('<II',d,cursor)
    assert length>=8 and cursor+length<=28+size
    if command==0x1b:identity=str(uuid.UUID(bytes=d[cursor+8:cursor+24])).upper()
    if command==1:
        name=d[cursor+8:cursor+24].split(b'\0')[0].decode()
        vm,vs,off,fs,maximum,initial=struct.unpack_from('<6I',d,cursor+24)
        segments.append((name,vm,vs,off,fs,initial))
    cursor+=length
assert cursor==28+size and identity=='AF0150D5-085E-3265-98ED-FF072A23D146'
def code(address,length):
    for name,vm,vs,off,fs,initial in segments:
        if vm<=address and address+length<=vm+fs:return d[off+address-vm:off+address-vm+length]
    raise AssertionError('address not backed by executable file')
assert code(0x11560,10)==bytes.fromhex('f0b503af89b047f2e875')
assert code(0xef584,26)==bytes.fromhex('f0b503af2de9000d81b004460020adf800000e46217b92460529')
assert any(name=='__DATA' and initial&2 and vm<=0x15c7c4 and vm+vs>=0x15c7c8 for name,vm,vs,off,fs,initial in segments)
# The verified packet builder loads its timestamp through this Thumb sequence:
# movw r4,#0xb234; movt r4,#0x14; add r4,pc at 0x1158c.
assert code(0x1157c,4)==bytes.fromhex('4bf23424')
assert code(0x11582,4)==bytes.fromhex('c0f21404')
assert code(0x1158c,2)==bytes.fromhex('7c44')
assert 0x11590+0x14b234==0x15c7c4
print('PASS: UUID, both hook signatures, timestamp instruction reference and writable segment.')
print('BTServer SHA256:',hashlib.sha256(d).hexdigest())
