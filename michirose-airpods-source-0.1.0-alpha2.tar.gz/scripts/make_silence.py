#!/usr/bin/env python3
"""Create our own silence asset; build-only dependency: lameenc==1.8.1."""
from pathlib import Path
import lameenc

encoder = lameenc.Encoder()
encoder.set_bit_rate(32)
encoder.set_in_sample_rate(44100)
encoder.set_channels(1)
encoder.set_quality(2)
payload = encoder.encode(bytes(60 * 44100 * 2)) + encoder.flush()
target = Path(__file__).resolve().parents[1] / 'Resources/silence.mp3'
target.parent.mkdir(exist_ok=True)
target.write_bytes(payload)
print(f'Generated {target.name}: {len(payload)} bytes of independently encoded silence.')
